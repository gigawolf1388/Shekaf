import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "ir.masoud.lalesaga",
  appName: "افسانهٔ گل لاله",
  webDir: "dist",
  bundledWebRuntime: false,
  backgroundColor: "#07070d",
  android: {
    backgroundColor: "#07070d",
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  ios: {
    backgroundColor: "#07070d",
    contentInset: "automatic",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: "#07070d",
      showSpinner: false,
    },
    StatusBar: {
      style: "DARK",
      backgroundColor: "#07070d",
      overlaysWebView: false,
    },
    Keyboard: {
      resize: "none",
      style: "DARK",
    },
  },
};

export default config;
