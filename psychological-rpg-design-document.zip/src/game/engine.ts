import type { EnemyDef, LocationDef, Mob, PlayerState, RegionId } from "./types";
import { locKey } from "./types";
import { ENEMY_POOLS, REGIONS, WORLD } from "./world";

export const COLS = 13;
export const ROWS = 13;
export const TILE = 32;
export const CX = Math.floor(COLS / 2); // 6
export const CY = Math.floor(ROWS / 2); // 4

export type PropKind =
  | "house" | "shop" | "stall" | "forge" | "temple" | "tower" | "garden"
  | "graveyard" | "well" | "cave" | "lair" | "ruins" | "beach" | "gate" | "none";

/** Visual landmark for a location, taken from its name. */
export function propFor(name: string): PropKind {
  if (name.includes("میدان روستای")) return "well";
  if (name.includes("میدان مرکزی")) return "garden";
  if (name.includes("خانه") || name.includes("کلبه")) return "house";
  if (name.includes("فروشگاه") || name.includes("دکه")) return "shop";
  if (name.includes("بازارچه") || name.includes("انجمن")) return "stall";
  if (name.includes("آهنگری") || name.includes("کوره")) return "forge";
  if (name.includes("معبد")) return "temple";
  if (name.includes("برج")) return "tower";
  if (name.includes("باغ")) return "garden";
  if (name.includes("گورستان")) return "graveyard";
  if (name.includes("چاه")) return "well";
  if (name.includes("غار")) return "cave";
  if (name.includes("لانه")) return "lair";
  if (name.includes("آرامگاه") || name.includes("دره اسکلت")) return "ruins";
  if (name.includes("ساحل") || name.includes("جزیره") || name.includes("آب‌های")) return "beach";
  if (name.includes("دروازه") || name.includes("پل") || name.includes("سکوی")) return "gate";
  return "none";
}

// ------------------------------------------------- seeded rng
export function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ------------------------------------------------- layout
export interface Layout {
  solid: boolean[][]; // [ty][tx]
  deco: number[][]; // decoration variant per tile (0 = none)
  exits: { up: boolean; down: boolean; left: boolean; right: boolean };
  prop: PropKind;
  propRect: { x: number; y: number; w: number; h: number } | null;
}

const layoutCache = new Map<string, Layout>();

export function neighborKey(x: number, y: number, dir: "up" | "down" | "left" | "right") {
  switch (dir) {
    case "up": return locKey(x, y + 1);
    case "down": return locKey(x, y - 1);
    case "left": return locKey(x - 1, y);
    case "right": return locKey(x + 1, y);
  }
}

export function getLayout(loc: LocationDef): Layout {
  const key = locKey(loc.x, loc.y);
  const cached = layoutCache.get(key);
  if (cached) return cached;

  const rng = mulberry32(hashStr(key + loc.region));
  const exits = {
    up: WORLD.has(neighborKey(loc.x, loc.y, "up")),
    down: WORLD.has(neighborKey(loc.x, loc.y, "down")),
    left: WORLD.has(neighborKey(loc.x, loc.y, "left")),
    right: WORLD.has(neighborKey(loc.x, loc.y, "right")),
  };

  const solid: boolean[][] = Array.from({ length: ROWS }, () => Array(COLS).fill(false));
  const deco: number[][] = Array.from({ length: ROWS }, () => Array(COLS).fill(0));

  // borders
  for (let tx = 0; tx < COLS; tx++) {
    solid[0][tx] = true;
    solid[ROWS - 1][tx] = true;
  }
  for (let ty = 0; ty < ROWS; ty++) {
    solid[ty][0] = true;
    solid[ty][COLS - 1] = true;
  }
  // exit gaps (3 tiles wide)
  if (exits.up) for (let tx = CX - 1; tx <= CX + 1; tx++) solid[0][tx] = false;
  if (exits.down) for (let tx = CX - 1; tx <= CX + 1; tx++) solid[ROWS - 1][tx] = false;
  if (exits.left) for (let ty = CY - 1; ty <= CY + 1; ty++) solid[ty][0] = false;
  if (exits.right) for (let ty = CY - 1; ty <= CY + 1; ty++) solid[ty][COLS - 1] = false;

  // interior obstacles — keep central cross clear so exits always connect
  const reserved = new Set<string>();
  (loc.npcs ?? []).forEach((n) => {
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++) reserved.add(`${n.tx + dx},${n.ty + dy}`);
  });
  if (loc.chest) {
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++) reserved.add(`${loc.chest.tx + dx},${loc.chest.ty + dy}`);
  }
  if (loc.bossId) {
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++) reserved.add(`${CX + dx},${CY - 1 + dy}`);
  }

  for (let ty = 1; ty < ROWS - 1; ty++) {
    for (let tx = 1; tx < COLS - 1; tx++) {
      const onCross = ty === CY || tx === CX;
      const r = rng();
      if (!onCross && !reserved.has(`${tx},${ty}`) && r < 0.13) {
        solid[ty][tx] = true;
      } else if (r > 0.82) {
        deco[ty][tx] = 1 + Math.floor(rng() * 3); // grass tuft / flower / pebble
      }
    }
  }

  // landmark building (top-left inside the walls) — blocks walking, adds depth
  const prop = propFor(loc.name);
  let propRect: Layout["propRect"] = null;
  if (prop !== "none") {
    propRect = { x: 1, y: 1, w: 3, h: 2 };
    for (let ty = 1; ty <= 2; ty++) {
      for (let tx = 1; tx <= 3; tx++) {
        solid[ty][tx] = true;
        deco[ty][tx] = 0;
      }
    }
  }

  const layout: Layout = { solid, deco, exits, prop, propRect };
  layoutCache.set(key, layout);
  return layout;
}

// ------------------------------------------------- roaming mobs
export function mobTargetCount(region: RegionId): number {
  const danger = REGIONS[region].danger;
  if (danger === 0) return 0;
  return danger >= 0.11 ? 4 : 3;
}

/** Spawn a fresh set of roaming monsters for a location. */
export function spawnMobs(loc: LocationDef, count: number, seedBase = Date.now()): Mob[] {
  const layout = getLayout(loc);
  const rng = mulberry32(hashStr(locKey(loc.x, loc.y)) ^ seedBase);
  const taken = new Set<string>();
  (loc.npcs ?? []).forEach((n) => taken.add(`${n.tx},${n.ty}`));
  if (loc.chest) taken.add(`${loc.chest.tx},${loc.chest.ty}`);
  taken.add(`${CX},${CY + 2}`);
  taken.add(`${CX},${CY}`);
  // never block the tiles the player lands on when entering this screen
  taken.add(`${CX},1`);
  taken.add(`${CX},${ROWS - 2}`);
  taken.add(`1,${CY}`);
  taken.add(`${COLS - 2},${CY}`);
  if (loc.bossId) {
    for (let dx = -1; dx <= 1; dx++)
      for (let dy = -1; dy <= 0; dy++) taken.add(`${CX + dx},${CY - 1 + dy}`);
  }
  const mobs: Mob[] = [];
  let guard = 0;
  while (mobs.length < count && guard < 300) {
    guard++;
    const tx = 1 + Math.floor(rng() * (COLS - 2));
    const ty = 1 + Math.floor(rng() * (ROWS - 2));
    const k = `${tx},${ty}`;
    if (layout.solid[ty][tx] || taken.has(k)) continue;
    const base = rollEnemy(loc.region);
    if (!base) break;
    taken.add(k);
    mobs.push({ ...base, id: `${locKey(loc.x, loc.y)}#${mobs.length}-${Math.floor(rng() * 99999)}`, tx, ty, level: REGIONS[loc.region].level });
  }
  return mobs;
}

// ------------------------------------------------- player math
export function maxHp(lvl: number) { return 60 + lvl * 14; }
export function maxMp(lvl: number) { return 20 + lvl * 4; }
export function playerAtk(p: PlayerState) { return 8 + p.lvl * 3 + p.atkBonus; }
export function playerDef(p: PlayerState) { return 2 + Math.floor(p.lvl * 1.5); }
export function xpForLevel(lvl: number) { return lvl * 45 + (lvl - 1) * 25; }

export function initialPlayer(): PlayerState {
  return {
    loc: "0,0", tx: CX, ty: CY + 2, dir: "up",
    hp: maxHp(1), mp: maxMp(1), xp: 0, lvl: 1, gold: 40, potions: 2,
    atkBonus: 0, defeated: [], memories: [], visited: ["0,0"], smithDone: [], riftsEntered: [],
    chests: [],
  };
}

// ------------------------------------------------- enemies
export function rollEnemy(region: RegionId): EnemyDef | null {
  const pool = ENEMY_POOLS[region];
  if (!pool || pool.length === 0) return null;
  const r = REGIONS[region];
  const pick = pool[Math.floor(Math.random() * pool.length)];
  const lv = r.level + Math.floor(Math.random() * 2);
  return {
    name: pick.name,
    color: pick.color,
    hp: 18 + lv * 11,
    atk: 5 + lv * 3,
    def: 1 + lv,
    xp: 10 + lv * 9,
    gold: 6 + Math.floor(Math.random() * 6) + lv * 4,
  };
}

export function damage(atk: number, def: number): number {
  const base = atk + Math.floor(Math.random() * 5) - def;
  return Math.max(1, base);
}
