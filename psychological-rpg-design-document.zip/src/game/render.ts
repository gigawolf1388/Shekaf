import type { LocationDef, Mob, NpcDef, PlayerState, Region } from "./types";
import { COLS, CX, CY, ROWS, TILE, hashStr, type Layout, type PropKind } from "./engine";

// ------------------------------------------------------------------ helpers
export function shade(hex: string, amt: number): string {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.max(0, (n >> 16) + amt));
  const g = Math.min(255, Math.max(0, ((n >> 8) & 0xff) + amt));
  const b = Math.min(255, Math.max(0, (n & 0xff) + amt));
  return `rgb(${r},${g},${b})`;
}

function alpha(hex: string, a: number): string {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${n >> 16},${(n >> 8) & 0xff},${n & 0xff},${a})`;
}

/** Public helper for tinted colors used by UI canvases. */
export const alphaColor = alpha;

function r(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, c: string) {
  ctx.fillStyle = c;
  ctx.fillRect(x, y, w, h);
}

const h2 = (s: string) => hashStr(s);

// ------------------------------------------------------------------ ground
export function drawGround(
  ctx: CanvasRenderingContext2D, loc: LocationDef, region: Region,
  layout: Layout, time: number,
) {
  const seed = `${loc.x},${loc.y}`;
  const base = region.ground;
  for (let ty = 0; ty < ROWS; ty++) {
    for (let tx = 0; tx < COLS; tx++) {
      const n = h2(seed + tx + ":" + ty);
      const col = base[n % base.length];
      r(ctx, tx * TILE, ty * TILE, TILE, TILE, col);
      const x = tx * TILE, y = ty * TILE;
      const solid = layout.solid[ty][tx];

      // subtle checker + edge darkening for depth
      r(ctx, x, y, TILE, 1, alpha("#ffffff", 0.035));
      r(ctx, x, y, 1, TILE, alpha("#ffffff", 0.02));
      r(ctx, x, y + TILE - 1, TILE, 1, alpha("#000000", 0.06));

      switch (loc.region) {
        case "city":
        case "bridge":
        case "tunnel": {
          const brick = shade(col, n % 2 ? 8 : -8);
          const off = (ty % 2) * 8;
          for (let by = 0; by < TILE; by += 10) {
            r(ctx, x, y + by, TILE, 1, alpha("#1c1a22", 0.3));
            for (let bx = 0; bx < TILE; bx += 16) {
              r(ctx, x + ((bx + off) % TILE), y + by + 1, 15, 9, alpha(brick.startsWith("rgb") ? col : brick, 0.35));
            }
          }
          if (loc.region === "city" && (n >> 4) % 5 === 0) {
            r(ctx, x + 6, y + 8, 1, 7, alpha("#000000", 0.16));
            r(ctx, x + 7, y + 15, 6, 1, alpha("#000000", 0.13));
            r(ctx, x + 3, y + 22, 5, 1, alpha("#000000", 0.1));
          }
          if (loc.region === "tunnel" && (n >> 4) % 6 === 0) {
            r(ctx, x + (n % 20) + 5, y + ((n * 3) % 20) + 5, 3, 2, alpha("#5a6a8a", 0.25));
          }
          break;
        }
        case "farm": {
          for (let fx = 3; fx < TILE; fx += 7) r(ctx, x + fx, y + 2, 1, TILE - 4, alpha("#3f3a1e", 0.28));
          for (let fx = 6; fx < TILE; fx += 7) r(ctx, x + fx, y + 2, 1, TILE - 4, alpha("#5a5a20", 0.2));
          const cn = (n >> 3) % 4;
          for (let i = 0; i < cn; i++) {
            const cx = x + 4 + ((n >> (i + 2)) % 24), cy = y + 8 + ((n >> (i + 4)) % 18);
            r(ctx, cx, cy, 2, 3, "#6f8a34");
            r(ctx, cx - 1, cy - 2, 1, 2, "#a8bf58");
            r(ctx, cx + 2, cy - 1, 1, 2, "#a8bf58");
          }
          if ((n >> 4) % 9 === 0) {
            r(ctx, x + 10, y + 9, 4, 12, "#c8a848");
            r(ctx, x + 11, y + 7, 2, 3, "#d8bc5a");
            r(ctx, x + 12, y + 12, 1, 6, "#a8883a");
            r(ctx, x + 8, y + 19, 8, 2, "#8a7430");
          }
          break;
        }
        case "mountain": {
          if (n % 5 === 0) r(ctx, x + (n % 20) + 3, y + ((n * 3) % 18) + 4, 2, 2, alpha("#4a443d", 0.55));
          if (n % 11 === 0) r(ctx, x + ((n * 7) % 24) + 2, y + ((n * 5) % 22) + 4, 3, 2, alpha("#8f887e", 0.5));
          if ((n >> 3) % 7 === 0) {
            r(ctx, x + 5, y + 20, 4, 2, "#5f7a3a");
            r(ctx, x + 8, y + 21, 2, 1, "#7a9450");
          }
          if ((n >> 5) % 6 === 0) {
            ctx.strokeStyle = alpha("#4a443d", 0.5);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(x + 8, y + 6);
            ctx.lineTo(x + 14, y + 14);
            ctx.lineTo(x + 12, y + 20);
            ctx.stroke();
          }
          break;
        }
        case "desert": {
          const d = Math.sin((x + y * 2) / 26 + 1.2);
          if (d > 0.55) r(ctx, x, y, TILE, TILE, alpha("#eed7a8", 0.14));
          else if (d < -0.6) r(ctx, x, y, TILE, TILE, alpha("#8a6f48", 0.1));
          const wave = Math.floor((n % 9) + Math.sin((x + y) / 28) * 4);
          for (let i = 0; i < 14; i++)
            r(ctx, x + i * 2, y + 6 + wave + Math.floor(Math.sin(i / 2) * 2), 2, 1, alpha("#8a6f48", 0.22));
          if (n % 7 === 0) r(ctx, x + (n % 26), y + (n % 24), 3, 1, "#7a6240");
          if (n % 13 === 0) r(ctx, x + (n % 20) + 4, y + ((n * 3) % 20) + 5, 2, 2, "#5a4630");
          break;
        }
        case "lava": {
          if ((n >> 2) % 5 === 0) {
            const gl = 0.5 + Math.sin(time / 400 + tx * 2) * 0.3;
            r(ctx, x + 4, y + 12, 24, 3, alpha("#ff7b3d", gl * 0.8));
            r(ctx, x + 10, y + 13, 12, 2, alpha("#ffd27a", gl));
            r(ctx, x + 2, y + 10, 8, 2, alpha("#ff9a4d", gl * 0.6));
            r(ctx, x + 20, y + 9, 8, 2, alpha("#ff9a4d", gl * 0.5));
            r(ctx, x + 14, y + 8, 2, 4, alpha("#ff7b3d", gl * 0.45));
            r(ctx, x + 8, y + 15, 2, 3, alpha("#ff5a1a", gl * 0.5));
            const em = (time / 26 + tx * 31) % 200;
            if (em < 60) r(ctx, x + 12 + Math.sin(em / 4) * 4, y + 12 - em * 0.3, 1, 1, alpha("#ffd27a", 0.8 * (1 - em / 60)));
          }
          if ((n >> 4) % 4 === 0) r(ctx, x + (n % 16) + 4, y + ((n * 3) % 16) + 5, 3, 1, alpha("#2a1210", 0.5));
          break;
        }
        case "lake": {
          const s1 = (time * 0.018 + tx * 13 + ty * 7) % (TILE + 18) - 9;
          const s2 = (time * 0.013 + tx * 5 + 22) % (TILE + 22) - 11;
          r(ctx, x + s1, y + 9, 14, 2, alpha("#ff9aac", 0.24));
          r(ctx, x + s1 + 4, y + 8, 6, 1, alpha("#ffd0d8", 0.3));
          r(ctx, x + s2, y + 21, 10, 2, alpha("#ffd0d8", 0.18));
          if ((n >> 3) % 8 === 0) r(ctx, x + (n % 12) + 6, y + 15, 2, 2, alpha("#ffb0b8", 0.5));
          break;
        }
        case "swamp": {
          if ((n >> 3) % 4 === 0) {
            ctx.fillStyle = alpha("#131f1a", 0.42);
            ctx.beginPath();
            ctx.ellipse(x + 16, y + 17, 12, 5, 0, 0, Math.PI * 2);
            ctx.fill();
            const rw = Math.sin(time / 900 + tx * 2 + ty) * 2;
            r(ctx, x + 7 + rw, y + 14, 8, 1, alpha("#7aa890", 0.35));
            r(ctx, x + 14 - rw, y + 19, 10, 1, alpha("#7aa890", 0.25));
            if ((n & 3) === 0) {
              r(ctx, x + 8, y + 11, 6, 3, "#3f6b32");
              r(ctx, x + 9, y + 10, 2, 2, "#5f9646");
              r(ctx, x + 12, y + 12, 1, 1, "#8aa34e");
            }
          } else if ((n >> 3) % 3 === 0) {
            const sw = Math.sin(time / 1000 + tx * 3) * 1;
            r(ctx, x + 9 + sw, y + 11, 1, 5, "#5b7a3c");
            r(ctx, x + 22 - sw, y + 8, 1, 7, "#5b7a3c");
            r(ctx, x + 22 - sw, y + 7, 2, 1, "#8aa34e");
            r(ctx, x + 15 + sw, y + 14, 1, 4, "#4a6a30");
          }
          break;
        }
        case "maple":
        case "village": {
          const m = (n >> 4) % 5;
          for (let i = 0; i < 3; i++) {
            const gx = x + 4 + ((n >> (i + 1)) % 24), gy = y + 6 + ((n >> (i + 3)) % 20);
            r(ctx, gx, gy, 1, 3, alpha("#2f5a24", 0.5));
            r(ctx, gx - 1, gy + 1, 1, 2, alpha("#2f5a24", 0.35));
            r(ctx, gx + 1, gy, 1, 2, alpha("#2f5a24", 0.35));
          }
          if (m === 0) {
            r(ctx, x + 18, y + 12, 2, 2, region.accent);
            r(ctx, x + 17, y + 13, 4, 1, alpha(region.accent, 0.6));
            r(ctx, x + 19, y + 13, 1, 1, "#ffe9a0");
          }
          if (loc.region === "maple" && (n >> 3) % 7 === 0) r(ctx, x + 8, y + 20, 4, 2, "#c96a2a");
          break;
        }
        case "scream": {
          if ((n >> 5) % 6 === 0) {
            r(ctx, x + 12, y + 14, 2, 1, alpha(region.accent, 0.95));
            r(ctx, x + 19, y + 14, 2, 1, alpha(region.accent, 0.95));
          }
          for (let i = 0; i < 2; i++)
            r(ctx, x + 6 + ((n >> i) % 20), y + 8 + ((n >> (i + 2)) % 16), 1, 3, alpha("#6a5f8a", 0.45));
          break;
        }
        default: break;
      }

      if (!solid && n % 23 === 0) {
        r(ctx, x + 22, y + 24, 3, 2, alpha("#4a4438", 0.6));
        r(ctx, x + 24, y + 22, 2, 2, alpha("#fff2d0", 0.45));
      }
    }
  }

  // sandy path on the traversable cross lanes
  ctx.fillStyle = alpha("#e8d8b0", 0.075);
  if (layout.exits.up || layout.exits.down) r(ctx, CX * TILE, TILE, TILE, TILE * (ROWS - 2), ctx.fillStyle as string);
  if (layout.exits.left || layout.exits.right) r(ctx, TILE, CY * TILE, TILE * (COLS - 2), TILE, ctx.fillStyle as string);

  // ambient occlusion — soft grounding shadow cast by every solid tile
  for (let ty = 0; ty < ROWS; ty++) {
    for (let tx = 0; tx < COLS; tx++) {
      if (!layout.solid[ty][tx]) continue;
      r(ctx, tx * TILE, ty * TILE + TILE, TILE, 4, "rgba(0,0,0,0.13)");
      r(ctx, tx * TILE + TILE, ty * TILE, 4, TILE, "rgba(0,0,0,0.09)");
      r(ctx, tx * TILE, ty * TILE, 3, TILE, "rgba(0,0,0,0.05)");
    }
  }
}

// ------------------------------------------------------------------ obstacles
export function drawObstacles(
  ctx: CanvasRenderingContext2D, layout: Layout, region: Region, time: number, seed = 0,
) {
  const pr = layout.propRect;
  for (let ty = 0; ty < ROWS; ty++) {
    for (let tx = 0; tx < COLS; tx++) {
      if (!layout.solid[ty][tx]) continue;
      if (pr && tx >= pr.x && tx < pr.x + pr.w && ty >= pr.y && ty < pr.y + pr.h) continue;
      const x = tx * TILE, y = ty * TILE, n = h2(seed + tx + ":" + ty);
      const kind = region.obstacleKind;

      // ground shadow
      ctx.fillStyle = alpha("#000000", 0.22);
      ctx.beginPath();
      ctx.ellipse(x + 16, y + 28, 13, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      if (kind === "tree") {
        const sw = Math.sin(time / 900 + tx * 1.7 + ty * 0.6) * 1.4;
        r(ctx, x + 13, y + 16, 6, 13, "#4a3018");
        r(ctx, x + 12, y + 24, 9, 3, "#573a1e");
        r(ctx, x + 13, y + 18, 2, 10, "#6b4626");
        const c = region.obstacle;
        r(ctx, x + 5, y + 4, 22, 14, shade(c, -12));
        r(ctx, x + 3, y + 8, 26, 9, c);
        r(ctx, x + 8 + sw * 0.8, y + 1, 16, 6, shade(c, 14));
        r(ctx, x + 17 + sw, y + 7, 10, 7, shade(c, -26));
        r(ctx, x + 7 + sw * 0.5, y + 9, 4, 3, shade(c, 34));
        r(ctx, x + 11 + sw, y + 3, 3, 2, shade(c, 22));
        r(ctx, x + 6, y + 5, 3, 2, alpha("#ffe9a0", 0.5));
        if (loc_has_bloom(n, region.id)) {
          r(ctx, x + 20 + sw, y + 5, 3, 3, region.accent);
          r(ctx, x + 22 + sw, y + 4, 2, 2, shade(region.accent, 30));
        }
      } else if (kind === "deadtree") {
        const c = region.obstacle;
        ctx.strokeStyle = c;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(x + 16, y + 29);
        ctx.lineTo(x + 16, y + 9);
        ctx.moveTo(x + 16, y + 18);
        ctx.lineTo(x + 7, y + 10);
        ctx.moveTo(x + 16, y + 14);
        ctx.lineTo(x + 25, y + 6);
        ctx.moveTo(x + 12, y + 13);
        ctx.lineTo(x + 9, y + 5);
        ctx.stroke();
        ctx.strokeStyle = shade(c, 30);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + 15, y + 28);
        ctx.lineTo(x + 15, y + 11);
        ctx.stroke();
        r(ctx, x + 24, y + 5, 2, 2, alpha(region.accent, 0.8));
      } else if (kind === "rock") {
        const c = region.obstacle;
        ctx.fillStyle = c;
        ctx.beginPath();
        ctx.moveTo(x + 4, y + 28);
        ctx.lineTo(x + 8, y + 14);
        ctx.lineTo(x + 17, y + 7);
        ctx.lineTo(x + 27, y + 15);
        ctx.lineTo(x + 29, y + 28);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = shade(c, 26);
        ctx.beginPath();
        ctx.moveTo(x + 8, y + 14);
        ctx.lineTo(x + 17, y + 7);
        ctx.lineTo(x + 20, y + 18);
        ctx.lineTo(x + 11, y + 22);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = shade(c, -28);
        ctx.beginPath();
        ctx.moveTo(x + 20, y + 18);
        ctx.lineTo(x + 27, y + 15);
        ctx.lineTo(x + 29, y + 28);
        ctx.lineTo(x + 16, y + 28);
        ctx.closePath();
        ctx.fill();
        r(ctx, x + 13, y + 19, 1, 7, shade(c, -34));
        r(ctx, x + 23, y + 21, 1, 5, shade(c, -34));
        r(ctx, x + 10, y + 25, 4, 2, "#4a6a34");
      } else if (kind === "wall") {
        const c = region.obstacle;
        r(ctx, x, y, TILE, TILE, c);
        for (let row = 0; row < 4; row++) {
          r(ctx, x, y + row * 8, TILE, 1, shade(c, -22));
          for (let b = 0; b < 2; b++)
            r(ctx, x + (row % 2) * 8 + b * 16, y + row * 8 + 1, 15, 7, shade(c, n % 2 ? 10 : 4));
        }
        r(ctx, x, y, TILE, 2, shade(c, 30));
        r(ctx, x + 4, y + 18, 2, 6, "#4a6a34");
      } else if (kind === "cactus") {
        const c = "#3e6b32";
        r(ctx, x + 13, y + 7, 7, 21, c);
        r(ctx, x + 14, y + 7, 2, 21, "#518236");
        r(ctx, x + 5, y + 15, 4, 3, c);
        r(ctx, x + 5, y + 10, 3, 8, c);
        r(ctx, x + 24, y + 18, 4, 3, c);
        r(ctx, x + 25, y + 13, 3, 8, c);
        for (let i = 0; i < 6; i++) r(ctx, x + 12 + (i % 2) * 8, y + 9 + i * 3, 1, 1, "#d8e8b0");
        r(ctx, x + 14, y + 4, 4, 3, "#e87a9a");
      } else {
        const c = region.obstacle;
        r(ctx, x + 9, y + 1, 14, 3, shade(c, 34));
        r(ctx, x + 11, y + 4, 10, 22, c);
        r(ctx, x + 13, y + 4, 3, 22, shade(c, 22));
        r(ctx, x + 8, y + 26, 16, 4, shade(c, 18));
        r(ctx, x + 12, y + 12, 1, 9, shade(c, -30));
        if (region.id === "bridge") {
          const gl = 0.5 + Math.sin(time / 500 + tx) * 0.3;
          r(ctx, x + 15, y + 8, 2, 2, alpha("#d8d4ff", gl));
        }
      }
    }
  }
}

function loc_has_bloom(n: number, id: string) {
  return (id === "village" || id === "maple") && n % 3 !== 0;
}

// ------------------------------------------------------------------ landmark props
export function drawProp(
  ctx: CanvasRenderingContext2D, kind: PropKind,
  x: number, y: number, w: number, h: number, time: number, accent: string,
) {
  if (kind === "none") return;
  const u = w / 96, v = h / 64;
  const X = (n: number) => x + n * u;
  const Y = (n: number) => y + n * v;
  const P = (px: number, py: number, pw: number, ph: number, c: string) => r(ctx, X(px), Y(py), pw * u, ph * v, c);

  // shared base shadow
  ctx.fillStyle = "rgba(0,0,0,0.28)";
  ctx.beginPath();
  ctx.ellipse(X(48), Y(61), 44 * u, 5 * v, 0, 0, Math.PI * 2);
  ctx.fill();

  switch (kind) {
    case "house": {
      P(10, 58, 78, 4, "#4a4038");
      P(11, 27, 74, 32, "#cdb992");
      P(11, 27, 74, 2, "#a8926a");
      for (const bx of [11, 44, 83]) P(bx, 27, 2, 32, "#6b4b2c");
      P(11, 43, 74, 2, "#6b4b2c");
      P(11, 58, 74, 2, "#8a7858");
      // glowing windows
      for (const wx of [18, 62]) {
        P(wx - 1, 33, 17, 14, "#3a2b1c");
        P(wx, 34, 15, 12, "#f2d06b");
        P(wx, 34, 15, 3, "#fff0b0");
        P(wx + 7, 34, 1, 12, "#3a2b1c");
        P(wx, 39, 15, 1, "#3a2b1c");
        const gl = 0.05 + Math.sin(time / 700) * 0.04;
        r(ctx, X(wx), Y(34), 15 * u, 12 * v, alpha("#fff6c0", gl));
      }
      // door
      P(39, 39, 18, 21, "#3a2414");
      P(41, 41, 14, 19, "#5a3a22");
      P(43, 43, 3, 17, "#6b4626");
      P(52, 49, 2, 2, "#e8c44a");
      P(37, 59, 22, 2, "#8a7a5a");
      // tiled roof
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(X(3), Y(29));
      ctx.lineTo(X(48), Y(3));
      ctx.lineTo(X(93), Y(29));
      ctx.closePath();
      ctx.fillStyle = "#6b2f30";
      ctx.fill();
      ctx.clip();
      for (let i = 0; i < 7; i++) {
        const yy = Y(6 + i * 3.6);
        r(ctx, X(0), yy, 96 * u, 1.2 * v, alpha("#2a1414", 0.45));
        for (let j = 0; j < 9; j++) r(ctx, X(6 + j * 11 + (i % 2) * 5), yy - 1, 7 * u, 1 * v, "#8d4440");
      }
      ctx.restore();
      P(3, 28, 90, 2, "#4a1f20");
      P(46, 2, 4, 4, "#c8a44a");
      // chimney + smoke
      P(70, 5, 11, 18, "#7a6a5a");
      P(68, 4, 15, 4, "#5a4a3e");
      for (let i = 0; i < 3; i++) {
        const sy = (time / 40 + i * 9) % 26;
        ctx.fillStyle = alpha("#d8d8e0", 0.22 * (1 - sy / 26));
        ctx.beginPath();
        ctx.ellipse(X(76) + Math.sin(time / 500 + i) * 5, Y(2) - sy * v, (3 + i) * u, (2.5 + i) * v, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case "shop": {
      P(12, 27, 72, 33, "#c2a882");
      P(12, 27, 72, 2, "#8f7a58");
      for (let row = 0; row < 4; row++) for (let bx = 0; bx < 5; bx++)
        P(14 + bx * 14, 30 + row * 7, 12, 5, row % 2 === bx % 2 ? "#cbb48e" : "#bda680");
      // awning
      for (let i = 0; i < 7; i++) P(8 + i * 12.5, 17, 12, 12, i % 2 ? "#eee0c8" : "#b84a3a");
      for (let i = 0; i < 7; i++) {
        P(8 + i * 12.5, 28, 12, 2, "#7a2a24");
        ctx.fillStyle = i % 2 ? "#eee0c8" : "#b84a3a";
        ctx.beginPath();
        ctx.arc(X(14 + i * 12.5), Y(30), 3 * u, 0, Math.PI);
        ctx.fill();
      }
      P(32, 33, 34, 9, "#4a3018");
      P(34, 34, 30, 7, "#6b4626");
      P(48, 36, 2, 3, "#efe0c8");
      P(16, 45, 64, 4, "#8a6236");
      P(20, 49, 14, 12, "#6b4626"); P(21, 50, 12, 10, "#8a6236");
      P(70, 50, 14, 11, "#5a3a20"); P(71, 51, 12, 3, "#7a5228");
      // glowing bottles
      for (const [bx, col] of [[40, "#7af0a0"], [46, "#f08a7a"], [52, "#8ab8f0"]] as const) {
        P(bx, 43, 4, 5, col);
        P(bx + 1, 41, 2, 2, "#d8e8f0");
        const gl = 0.25 + Math.sin(time / 500 + bx) * 0.15;
        ctx.fillStyle = alpha(col, gl);
        ctx.beginPath();
        ctx.arc(X(bx + 2), Y(45), 5 * u, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case "stall": {
      P(14, 22, 4, 38, "#5a3a20");
      P(78, 22, 4, 38, "#5a3a20");
      for (let i = 0; i < 6; i++) P(10 + i * 13, 10, 13, 14, i % 2 ? accent : "#efe0c8");
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = i % 2 ? accent : "#efe0c8";
        ctx.beginPath();
        ctx.arc(X(16 + i * 13), Y(24), 6 * u, 0, Math.PI);
        ctx.fill();
      }
      P(10, 9, 76, 2, "#6b4b2c");
      P(16, 44, 64, 5, "#8a6236");
      // fruit boxes
      for (const [bx, col] of [[20, "#e8a83a"], [36, "#c84a4a"], [58, "#7ab84a"], [72, "#b87ad8"]] as const) {
        P(bx, 36, 12, 8, "#6b4626");
        for (let i = 0; i < 3; i++) P(bx + 2 + i * 3, 34, 3, 3, col);
      }
      // hanging lanterns
      for (const lx of [22, 74]) {
        P(lx, 26, 1, 4, "#3a2a1a");
        P(lx - 2, 30, 5, 6, "#e8b84a");
        const gl = 0.3 + Math.sin(time / 400 + lx) * 0.2;
        ctx.fillStyle = alpha("#ffd882", gl);
        ctx.beginPath();
        ctx.arc(X(lx), Y(33), 7 * u, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case "forge": {
      P(12, 26, 72, 34, "#5a524c");
      for (let row = 0; row < 3; row++) for (let bx = 0; bx < 6; bx++)
        P(14 + bx * 12, 29 + row * 10, 10, 8, (row + bx) % 2 ? "#665e56" : "#4e4742");
      P(58, 2, 17, 24, "#3e3a36"); P(56, 1, 21, 3, "#2a2622");
      for (let i = 0; i < 3; i++) {
        const sy = (time / 40 + i * 10) % 30;
        ctx.fillStyle = alpha("#9a9aa4", 0.18 * (1 - sy / 30));
        ctx.beginPath();
        ctx.ellipse(X(66) + Math.sin(i + time / 600) * 4, Y(0) - sy * v, (3 + i) * u, (2 + i) * v, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      // furnace
      const glow = 0.65 + Math.sin(time / 220) * 0.25;
      P(18, 36, 26, 20, "#2a2220");
      r(ctx, X(21), Y(40), 20 * u, 14 * v, alpha("#ff7a2a", glow));
      r(ctx, X(25), Y(44), 12 * u, 10 * v, alpha("#ffd27a", glow * 0.9));
      ctx.fillStyle = alpha("#ff8a3a", glow * 0.25);
      ctx.beginPath(); ctx.arc(X(31), Y(46), 18 * u, 0, Math.PI * 2); ctx.fill();
      // anvil
      P(56, 50, 24, 6, "#2a2a30");
      P(60, 46, 15, 5, "#3a3a42");
      P(56, 56, 20, 4, "#222228");
      P(78, 48, 6, 3, "#3a3a42");
      // sparks
      for (let i = 0; i < 5; i++) {
        const t2 = (time / 300 + i * 0.3) % 1;
        r(ctx, X(66 + Math.sin(i * 2 + time / 200) * 8), Y(46 - t2 * 14), 1.5 * u, 1.5 * v, alpha("#ffd27a", 1 - t2));
      }
      break;
    }
    case "temple": {
      P(6, 54, 84, 6, "#cbbfa0");
      P(10, 48, 76, 6, "#ddd2b4");
      P(14, 44, 68, 4, "#b8ac90");
      for (const cx of [20, 34, 50, 64, 78]) {
        P(cx - 3, 22, 7, 22, "#e2d8bc");
        P(cx - 2, 23, 2, 20, "#f4ecd4");
        P(cx - 4, 20, 9, 3, "#c4b898");
        P(cx - 4, 43, 9, 2, "#c4b898");
      }
      P(14, 15, 68, 6, "#d8ccae");
      P(18, 12, 60, 3, "#b8ac90");
      ctx.fillStyle = "#7a6a4a";
      ctx.beginPath();
      ctx.moveTo(X(10), Y(15)); ctx.lineTo(X(48), Y(2)); ctx.lineTo(X(86), Y(15));
      ctx.closePath(); ctx.fill();
      // sun disc
      const glow = 0.55 + Math.sin(time / 500) * 0.2;
      ctx.fillStyle = alpha("#ffd25a", 0.18);
      ctx.beginPath(); ctx.arc(X(48), Y(24), 20 * u, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#ffcf4a";
      ctx.beginPath(); ctx.arc(X(48), Y(25), 9 * u, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff0b0";
      ctx.beginPath(); ctx.arc(X(48), Y(25), 5 * u, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = alpha("#ffe08a", glow);
      ctx.lineWidth = Math.max(1, u);
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(X(48) + Math.cos(a) * 12 * u, Y(25) + Math.sin(a) * 12 * v);
        ctx.lineTo(X(48) + Math.cos(a) * 16 * u, Y(25) + Math.sin(a) * 16 * v);
        ctx.stroke();
      }
      break;
    }
    case "tower": {
      P(30, 52, 36, 9, "#6a6258");
      P(35, 10, 26, 44, "#8a8074");
      P(35, 10, 26, 2, "#a89e90");
      for (let row = 0; row < 8; row++) for (let bx = 0; bx < 2; bx++)
        P(37 + bx * 12, 14 + row * 5, 10, 4, (row + bx) % 2 ? "#948a7c" : "#817867");
      ctx.fillStyle = "#4a4238";
      ctx.beginPath(); ctx.moveTo(X(30), Y(10)); ctx.lineTo(X(48), Y(0)); ctx.lineTo(X(66), Y(10)); ctx.closePath(); ctx.fill();
      P(47, -4, 2, 6, "#4a3a2a"); P(49, -4, 7, 4, accent);
      // clock face frozen at 3:17
      ctx.fillStyle = "#2a2620";
      ctx.beginPath(); ctx.arc(X(48), Y(24), 12 * u, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#e8c86a"; ctx.lineWidth = Math.max(1, 1.4 * u);
      ctx.beginPath(); ctx.arc(X(48), Y(24), 11 * u, 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        ctx.fillStyle = "#c8b07a";
        ctx.fillRect(X(48) + Math.cos(a) * 8.6 * u - 0.5 * u, Y(24) + Math.sin(a) * 8.6 * v - 0.5 * v, 1.2 * u, 1.2 * v);
      }
      ctx.strokeStyle = "#f6e6a8"; ctx.lineWidth = Math.max(1, 1.6 * u);
      ctx.beginPath();
      ctx.moveTo(X(48), Y(24));
      ctx.lineTo(X(48) + Math.cos(Math.PI / 2 - (3 / 12) * Math.PI * 2) * 5.5 * u, Y(24) + Math.sin(Math.PI / 2 - (3 / 12) * Math.PI * 2) * 5.5 * v);
      ctx.moveTo(X(48), Y(24));
      ctx.lineTo(X(48) + Math.cos(Math.PI / 2 - (17 / 60) * Math.PI * 2) * 7.5 * u, Y(24) + Math.sin(Math.PI / 2 - (17 / 60) * Math.PI * 2) * 7.5 * v);
      ctx.stroke();
      P(43, 40, 10, 8, "#3a322a"); P(44, 41, 8, 6, alpha("#ffd27a", 0.55 + Math.sin(time / 600) * 0.2));
      break;
    }
    case "garden": {
      // hedge border
      for (let i = 0; i < 10; i++) {
        P(4 + i * 9, 46, 9, 15, i % 2 ? "#3f6b32" : "#4c7d3a");
        P(5 + i * 9, 44, 7, 3, "#5f9646");
      }
      P(4, 20, 6, 27, "#3f6b32"); P(86, 20, 6, 27, "#3f6b32");
      P(4, 20, 6, 3, "#5f9646"); P(86, 20, 6, 3, "#5f9646");
      P(10, 16, 76, 5, "#3f6b32");
      for (let i = 0; i < 12; i++) P(10 + i * 6.5, 13, 5, 5, i % 2 ? "#4c7d3a" : "#5f9646");
      // fountain
      P(34, 48, 30, 6, "#b8b0a0"); P(36, 46, 26, 3, "#d8d0c0");
      const w = Math.sin(time / 500) * 1.5;
      P(38, 47 + w, 22, 2, "#7ab8d8");
      P(45, 36, 8, 12, "#cfc8b8"); P(42, 34, 14, 4, "#b8b0a0");
      ctx.fillStyle = alpha("#9ad8f0", 0.6);
      ctx.beginPath(); ctx.ellipse(X(49), Y(34), 6 * u, 2 * v, 0, 0, Math.PI * 2); ctx.fill();
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 + time / 900;
        r(ctx, X(49) + Math.cos(a) * 14 * u, Y(37) - Math.abs(Math.sin(a)) * 8 * v, 1.5 * u, 1.5 * v, alpha("#c8f0ff", 0.6));
      }
      for (let i = 0; i < 6; i++) P(14 + i * 13, 54, 2, 4, i % 2 ? accent : "#e8d46a");
      break;
    }
    case "graveyard": {
      ctx.fillStyle = "rgba(180,200,190,0.08)";
      ctx.beginPath(); ctx.ellipse(X(48), Y(54), 44 * u, 8 * v, 0, 0, Math.PI * 2); ctx.fill();
      const stones: Array<[number, number, number, number]> = [[14, 40, 14, 20], [40, 34, 16, 26], [68, 42, 13, 18]];
      for (const [gx, gy, gw, gh] of stones) {
        P(gx - 1, gy - 1, gw + 2, gh + 2, "#4a4a44");
        P(gx, gy, gw, gh, "#8a8a80");
        P(gx + 1, gy + 1, gw - 2, 4, "#a8a89c");
        P(gx + gw / 2 - 0.5, gy + 4, 1, 7, "#5a5a52");
        P(gx + gw / 2 - 2.5, gy + 6, 5, 1, "#5a5a52");
        P(gx + 1, gy + gh - 2, gw - 2, 2, "#6a6a60");
        P(gx + gw + 2, gy + gh - 6, 3, 6, "#5a5a48");
        const gl = 0.4 + Math.sin(time / 300 + gx) * 0.3;
        P(gx + gw + 3, gy + gh - 8, 1.5, 2, alpha("#ffd27a", gl));
      }
      ctx.strokeStyle = "#3a342c"; ctx.lineWidth = 3 * u;
      ctx.beginPath();
      ctx.moveTo(X(88), Y(52)); ctx.lineTo(X(84), Y(30));
      ctx.moveTo(X(84), Y(38)); ctx.lineTo(X(76), Y(30));
      ctx.moveTo(X(84), Y(34)); ctx.lineTo(X(91), Y(26));
      ctx.stroke();
      break;
    }
    case "well": {
      P(26, 40, 44, 18, "#7a7268");
      for (let row = 0; row < 3; row++) for (let bx = 0; bx < 6; bx++)
        P(28 + bx * 7, 42 + row * 5, 6, 4, (row + bx) % 2 ? "#8e867a" : "#6b645a");
      ctx.fillStyle = "#1a2428";
      ctx.beginPath(); ctx.ellipse(X(48), Y(45), 18 * u, 5 * v, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = alpha("#6ab8d8", 0.35 + Math.sin(time / 600) * 0.1);
      ctx.beginPath(); ctx.ellipse(X(48), Y(46), 15 * u, 3.5 * v, 0, 0, Math.PI * 2); ctx.fill();
      P(30, 46, 4, 12, "#8e867a"); P(62, 46, 4, 12, "#8e867a");
      P(28, 22, 40, 3, "#6b4b2c"); P(31, 24, 34, 2, "#8a6236");
      P(40, 6, 3, 18, "#5a3a20"); P(56, 6, 3, 18, "#5a3a20");
      ctx.fillStyle = "#7a4a30";
      ctx.beginPath(); ctx.moveTo(X(36), Y(8)); ctx.lineTo(X(48), Y(0)); ctx.lineTo(X(62), Y(8)); ctx.closePath(); ctx.fill();
      P(47, 24, 1, 10, "#d8c8a0"); P(43, 24, 10, 2, "#5a3a20");
      P(43, 33, 10, 7, "#6b4b2c"); P(44, 34, 8, 5, "#8a6236");
      break;
    }
    case "cave": {
      ctx.fillStyle = "#5a5560";
      ctx.beginPath();
      ctx.moveTo(X(2), Y(62)); ctx.lineTo(X(10), Y(22)); ctx.lineTo(X(26), Y(4));
      ctx.lineTo(X(48), Y(0)); ctx.lineTo(X(74), Y(6)); ctx.lineTo(X(90), Y(28));
      ctx.lineTo(X(94), Y(62));
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#6e6874";
      ctx.beginPath();
      ctx.moveTo(X(8), Y(62)); ctx.lineTo(X(18), Y(24)); ctx.lineTo(X(34), Y(10));
      ctx.lineTo(X(58), Y(8)); ctx.lineTo(X(76), Y(20)); ctx.lineTo(X(86), Y(62));
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#0a0810";
      ctx.beginPath();
      ctx.moveTo(X(22), Y(62)); ctx.lineTo(X(26), Y(30)); ctx.lineTo(X(38), Y(20));
      ctx.lineTo(X(56), Y(20)); ctx.lineTo(X(68), Y(32)); ctx.lineTo(X(72), Y(62));
      ctx.closePath(); ctx.fill();
      // crystals
      for (const [cx, cy, col] of [[26, 52, "#7ad8f0"], [66, 48, "#b88af0"], [46, 58, "#8af0d8"]] as const) {
        const gl = 0.4 + Math.sin(time / 400 + cx) * 0.3;
        P(cx, cy, 3, 7, col); P(cx + 3, cy + 2, 2, 5, col); P(cx - 2, cy + 3, 2, 4, col);
        ctx.fillStyle = alpha(col, gl * 0.35);
        ctx.beginPath(); ctx.arc(X(cx + 1), Y(cy + 3), 8 * u, 0, Math.PI * 2); ctx.fill();
      }
      for (let i = 0; i < 4; i++) P(24 + i * 12, 8 + (i % 2) * 5, 3, 9, "#5a5560");
      break;
    }
    case "lair": {
      P(10, 48, 76, 13, "#4a3a2a");
      for (let i = 0; i < 12; i++) P(8 + i * 7, 44 + (i % 3), 6, 4, i % 2 ? "#6b5236" : "#5a442e");
      // eggs
      for (const [ex, ey, col] of [[26, 38, "#c8b48a"], [46, 30, "#b8a47a"]] as const) {
        ctx.fillStyle = col;
        ctx.beginPath(); ctx.ellipse(X(ex), Y(ey), 8 * u, 11 * v, 0, 0, Math.PI * 2); ctx.fill();
        P(ex - 3, ey - 4, 3, 2, "#8a7a5a"); P(ex + 1, ey, 2, 2, "#8a7a5a");
      }
      // bones
      ctx.strokeStyle = "#e8e4d4"; ctx.lineWidth = 2 * u;
      ctx.beginPath();
      ctx.moveTo(X(64), Y(50)); ctx.lineTo(X(80), Y(42));
      ctx.moveTo(X(70), Y(36)); ctx.lineTo(X(84), Y(48));
      ctx.stroke();
      // skull
      P(66, 34, 12, 9, "#cfcbb8"); P(68, 40, 8, 4, "#b8b4a0");
      P(68, 37, 2, 2, "#2a2420"); P(74, 37, 2, 2, "#2a2420"); P(70, 41, 4, 1, "#2a2420");
      P(62, 44, 20, 2, "#8a7a5a");
      P(56, 20, 2, 20, "#5a3a20"); P(52, 18, 18, 5, "#7a2a34");
      break;
    }
    case "ruins": {
      for (const [cx, hh, col] of [[16, 30, "#a8a090"], [48, 12, "#c0b8a8"], [80, 22, "#948c7c"]] as const) {
        P(cx - 5, 56 - hh, 10, hh, col);
        P(cx - 7, 54, 14, 4, shade("#a8a090", -20));
        P(cx - 6, 56 - hh - 3, 12, 4, "#cfc7b8");
        for (let i = 0; i < 3; i++) P(cx - 3 + i * 3, 56 - hh + 4, 1, hh - 6, shade("#a8a090", -14));
        P(cx - 5, 56 - hh + 2, 10, 1, "#8a8274");
      }
      ctx.fillStyle = "#c8c0b0";
      ctx.beginPath(); ctx.ellipse(X(48), Y(48), 16 * u, 8 * v, 0, 0, Math.PI * 2); ctx.fill();
      P(33, 46, 30, 6, "#a8a090");
      P(36, 44, 24, 4, "#d8d0c0");
      P(44, 42, 8, 3, "#8a8274");
      // broken pieces
      P(10, 54, 8, 5, "#b8b0a0"); P(70, 55, 9, 4, "#a8a090");
      for (let i = 0; i < 3; i++) P(20 + i * 20, 58, 2, 3, "#5a6a44");
      break;
    }
    case "beach": {
      const w = Math.sin(time / 600) * 2;
      P(0, 14, 96, 20, alpha("#7a2f40", 0.55));
      for (let i = 0; i < 4; i++) {
        const yy = 16 + i * 4;
        r(ctx, X(0), Y(yy) + w, 96 * u, 1.2 * v, alpha("#ffb0b8", 0.3 - i * 0.05));
      }
      // wrecked boat
      ctx.fillStyle = "#5a3a22";
      ctx.beginPath();
      ctx.moveTo(X(26), Y(36)); ctx.lineTo(X(76), Y(36));
      ctx.lineTo(X(68), Y(48)); ctx.lineTo(X(34), Y(48));
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#8a6236"; ctx.lineWidth = 1.5 * u;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath(); ctx.moveTo(X(31 + i * 15), Y(38)); ctx.lineTo(X(34 + i * 12), Y(46)); ctx.stroke();
      }
      P(49, 6, 3, 30, "#4a3018");
      ctx.fillStyle = alpha("#e8dcc0", 0.85);
      ctx.beginPath(); ctx.moveTo(X(52), Y(10)); ctx.lineTo(X(74), Y(20)); ctx.lineTo(X(52), Y(30)); ctx.closePath(); ctx.fill();
      P(50, 5, 9, 4, "#b84a4a");
      P(42, 52, 22, 2, "#8a6a4a");
      P(18, 56, 10, 3, "#a8865a"); P(72, 57, 12, 3, "#a8865a");
      break;
    }
    case "gate": {
      for (const gx of [8, 74]) {
        P(gx, 18, 16, 42, "#8a8274");
        for (let row = 0; row < 5; row++) for (let bx = 0; bx < 2; bx++)
          P(gx + 1 + bx * 7, 20 + row * 8, 6, 6, (row + bx) % 2 ? "#9a9282" : "#7a7264");
        P(gx - 2, 14, 20, 5, "#a8a090");
        for (let i = 0; i < 3; i++) P(gx - 1 + i * 7, 9, 5, 6, "#a8a090");
        P(gx + 6, 58, 4, 4, "#6a6254");
        const col = accent;
        P(gx + 1, 24, 14, 3, col);
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(X(gx + 1), Y(27)); ctx.lineTo(X(gx + 8), Y(36)); ctx.lineTo(X(gx + 15), Y(27));
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = alpha("#ffd27a", 0.35 + Math.sin(time / 400 + gx) * 0.2);
        ctx.beginPath(); ctx.arc(X(gx + 8), Y(30), 7 * u, 0, Math.PI * 2); ctx.fill();
      }
      ctx.strokeStyle = "#8a8274"; ctx.lineWidth = 4 * u;
      ctx.beginPath(); ctx.moveTo(X(22), Y(20)); ctx.lineTo(X(22), Y(34)); ctx.lineTo(X(74), Y(34)); ctx.lineTo(X(74), Y(20)); ctx.stroke();
      ctx.fillStyle = "#6a6254";
      ctx.beginPath(); ctx.moveTo(X(18), Y(34)); ctx.lineTo(X(30), Y(34)); ctx.lineTo(X(30), Y(46)); ctx.lineTo(X(18), Y(46)); ctx.fill();
      ctx.beginPath(); ctx.moveTo(X(66), Y(34)); ctx.lineTo(X(78), Y(34)); ctx.lineTo(X(78), Y(46)); ctx.lineTo(X(66), Y(46)); ctx.fill();
      P(26, 54, 44, 3, "#9a9282");
      break;
    }
    default:
      break;
  }
}

// ------------------------------------------------------------------ chest
export function drawChest(ctx: CanvasRenderingContext2D, tx: number, ty: number, time: number) {
  const x = tx * TILE, y = ty * TILE;
  const bob = Math.sin(time / 520) * 1.2;
  ctx.fillStyle = alpha("#000000", 0.28);
  ctx.beginPath();
  ctx.ellipse(x + 16, y + 28, 11, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  // body
  r(ctx, x + 5, y + 14, 22, 13, "#6b4626");
  r(ctx, x + 5, y + 14, 22, 2, "#8a6236");
  r(ctx, x + 6, y + 17, 20, 9, "#5a3a20");
  // lid
  r(ctx, x + 4, y + 7 + bob, 24, 8, "#7a5228");
  r(ctx, x + 4, y + 7 + bob, 24, 2, "#9a6c3a");
  // iron bands
  for (const bx of [8, 22]) {
    r(ctx, x + bx, y + 7 + bob, 3, 8, "#3a3a44");
    r(ctx, x + bx, y + 14, 3, 13, "#3a3a44");
  }
  r(ctx, x + 4, y + 15, 24, 2, "#2e2e38");
  // lock + glint
  r(ctx, x + 14, y + 13 + bob, 5, 6, "#d8b44a");
  r(ctx, x + 15, y + 15 + bob, 2, 2, "#4a3a18");
  const gl = 0.35 + Math.sin(time / 300) * 0.3;
  ctx.fillStyle = alpha("#ffe9a0", gl * 0.5);
  ctx.beginPath();
  ctx.arc(x + 16, y + 16, 13, 0, Math.PI * 2);
  ctx.fill();
  // sparkle
  const sp = (time / 420) % 3;
  if (sp < 1) r(ctx, x + 24, y + 6 + bob, 2, 2, "#fff6c0");
}

// ------------------------------------------------------------------ NPC
export function drawNpc(ctx: CanvasRenderingContext2D, n: NpcDef, time: number) {
  const x = n.tx * TILE, y = n.ty * TILE;
  const bob = Math.sin(time / 480 + n.tx) > 0 ? 0 : 1;
  ctx.fillStyle = alpha("#000000", 0.25);
  ctx.beginPath();
  ctx.ellipse(x + 16, y + 29, 9, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  // legs / robe
  r(ctx, x + 9, y + 24 + bob, 14, 5, shade(n.body, -46));
  r(ctx, x + 8, y + 13 + bob, 16, 13, n.body);
  r(ctx, x + 10, y + 13 + bob, 4, 12, shade(n.body, 24));
  r(ctx, x + 8, y + 21 + bob, 16, 2, shade(n.body, -34));
  // arms
  r(ctx, x + 5, y + 15 + bob, 3, 8, n.body);
  r(ctx, x + 24, y + 15 + bob, 3, 8, shade(n.body, -18));
  // head
  r(ctx, x + 10, y + 3 + bob, 12, 11, n.head);
  r(ctx, x + 11, y + 2 + bob, 10, 3, "#3a2b22");
  const blink = Math.sin(time / 950 + n.tx * 5.1 + n.ty * 2.3) > 0.93;
  if (blink) {
    r(ctx, x + 12, y + 7 + bob, 3, 1, "#5a3a2a");
    r(ctx, x + 17, y + 7 + bob, 3, 1, "#5a3a2a");
  } else {
    r(ctx, x + 12, y + 5 + bob, 3, 3, "#efe0c8");
    r(ctx, x + 17, y + 5 + bob, 3, 3, "#efe0c8");
    r(ctx, x + 13, y + 6 + bob, 1, 2, "#2a2a2a");
    r(ctx, x + 18, y + 6 + bob, 1, 2, "#2a2a2a");
  }
  r(ctx, x + 15, y + 10 + bob, 3, 1, "#8a5a4a");
  // marker
  const mb = Math.sin(time / 300) * 1.5;
  r(ctx, x + 14, y - 8 + mb, 3, 5, "#f2d06b");
  r(ctx, x + 15, y - 4 + mb, 1, 1, "#8a6a20");
}

// ------------------------------------------------------------------ player
export function drawPlayer(ctx: CanvasRenderingContext2D, p: PlayerState, time: number) {
  const x = p.tx * TILE, y = p.ty * TILE;
  const step = Math.sin(time / 190) > 0 ? 1 : 0;
  ctx.fillStyle = alpha("#000000", 0.3);
  ctx.beginPath();
  ctx.ellipse(x + 16, y + 30, 9, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  const back = p.dir === "up";
  // cape (flutters)
  const flut = Math.sin(time / 150) * 1.6;
  r(ctx, x + 8, y + 14, 16, 12, "#8a2438");
  r(ctx, x + 10, y + 25, 12, 3 + step, "#6a1a2a");
  r(ctx, x + 10, y + 27 + step, 9 + flut * 0.5, 2, "#5a1420");

  // legs & boots
  r(ctx, x + 11, y + 23, 4, 6 + step, "#2f3a5a");
  r(ctx, x + 18, y + 23, 4, 6 - step, "#2f3a5a");
  r(ctx, x + 10, y + 28 + step, 5, 3, "#4a3524");
  r(ctx, x + 18, y + 28 - step, 5, 3, "#4a3524");

  // tunic
  r(ctx, x + 9, y + 13, 14, 12, "#3d5fb8");
  r(ctx, x + 11, y + 13, 5, 11, "#5478d4");
  r(ctx, x + 9, y + 22, 14, 2, "#2a3f80");
  r(ctx, x + 14, y + 19, 4, 3, "#d8b44a"); // belt buckle

  // arms
  r(ctx, x + 6, y + 15, 4, 8, "#3d5fb8");
  r(ctx, x + 22, y + 15, 4, 8, "#33509c");
  // sword
  if (p.dir === "left") {
    r(ctx, x + 1, y + 17, 2, 11, "#cfd6e8");
    r(ctx, x + 1, y + 27, 2, 2, "#8a6a2a");
  } else {
    r(ctx, x + 27, y + 16, 2, 12, "#cfd6e8");
    r(ctx, x + 25, y + 15, 6, 2, "#c8a44a");
  }
  // shield on back
  r(ctx, x + 20, y + 12, 9, 11, "#8a6a3a");
  r(ctx, x + 21, y + 13, 7, 9, "#b8975a");
  r(ctx, x + 24, y + 15, 1, 5, "#e8d8a8");

  // head
  r(ctx, x + 11, y + 3, 12, 11, "#e8c49a");
  r(ctx, x + 11, y + 2, 12, 4, "#33241a");
  r(ctx, x + 10, y + 4, 3, 5, "#33241a");
  if (!back) {
    r(ctx, x + 13, y + 7, 2, 2, "#203040");
    r(ctx, x + 19, y + 7, 2, 2, "#203040");
    r(ctx, x + 13, y + 8, 1, 1, alpha("#ffffff", 0.5));
    r(ctx, x + 19, y + 8, 1, 1, alpha("#ffffff", 0.5));
  }
  // scarf
  r(ctx, x + 10, y + 12, 14, 2, "#b83a3a");
}

// ------------------------------------------------------------------ monsters
export type CreatureKind = "slime" | "ghost" | "skeleton" | "beast" | "bat" | "spider" | "worm" | "brute" | "boss";

export function creatureKind(name: string): CreatureKind {
  if (name.includes("باس") || name.includes("اربا") || name.includes("وایورن") || name.includes("گریفیث") || name.includes("کاسپالوس") || name.includes("مادر") || name.includes("نگهبان") || name.includes("سایه شن")) return "boss";
  if (name.includes("اسکلت")) return "skeleton";
  if (name.includes("شبح") || name.includes("روح") || name.includes("سایه") || name.includes("مه")) return "ghost";
  if (name.includes("گرگ") || name.includes("کفتار") || name.includes("روباه") || name.includes("سگ")) return "beast";
  if (name.includes("خفاش")) return "bat";
  if (name.includes("عنکبوت") || name.includes("خرچنگ")) return "spider";
  if (name.includes("کرم") || name.includes("مار") || name.includes("لجن")) return "worm";
  if (name.includes("گولم") || name.includes("دیو") || name.includes("مترسک") || name.includes("نگهبان")) return "brute";
  return "slime";
}

/**
 * Draws a creature with 1 internal pixel = `s` screen pixels.
 * (cx, by) is bottom-center.
 */
export function drawCreature(
  ctx: CanvasRenderingContext2D, cx: number, by: number, s: number,
  color: string, name: string, time: number,
) {
  const kind = creatureKind(name);
  const bounce = Math.sin(time / 340) * (kind === "ghost" || kind === "bat" ? 2.5 : 1.2);
  const dark = shade(color, -60), light = shade(color, 40);
  ctx.save();
  ctx.translate(cx, by + bounce);
  const P = (x: number, y: number, w: number, h: number, c: string) => r(ctx, x * s, y * s, w * s, h * s, c);

  // shadow
  ctx.fillStyle = alpha("#000000", 0.3);
  ctx.beginPath();
  ctx.ellipse(0, 0, (kind === "boss" ? 17 : 9) * s, 2.5 * s, 0, 0, Math.PI * 2);
  ctx.fill();

  if (kind === "boss") {
    // pulsing battle aura under the boss
    const pulse = (Math.sin(time / 300) + 1) / 2;
    ctx.strokeStyle = `rgba(255,74,106,${0.28 + pulse * 0.25})`;
    ctx.lineWidth = 2 * s;
    ctx.beginPath();
    ctx.ellipse(0, -1 * s, (13 + pulse * 5) * s, (5 + pulse * 2) * s, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,170,120,${0.12 + pulse * 0.12})`;
    ctx.beginPath();
    ctx.ellipse(0, -1 * s, (17 + pulse * 5) * s, (7 + pulse * 2) * s, 0, 0, Math.PI * 2);
    ctx.stroke();
    // rising threat motes
    for (let i = 0; i < 6; i++) {
      const em = (time / 24 + i * 37) % 240;
      ctx.fillStyle = `rgba(255,120,80,${0.5 * (1 - em / 240)})`;
      ctx.fillRect((Math.sin(i * 2.2) * 10 - 1.5) * s, (-4 - em * 0.09) * s, 2 * s, 2 * s);
    }
  }

  if (kind === "slime") {
    P(-9, -7, 18, 7, dark);
    P(-10, -10, 20, 7, color);
    P(-8, -12, 16, 5, color);
    P(-6, -13, 12, 3, color);
    P(-6, -11, 5, 2, light);
    P(-4, -8, 2, 3, "#1a1420"); P(3, -8, 2, 3, "#1a1420");
    P(-3, -7, 1, 1, "#ff5a6a"); P(4, -7, 1, 1, "#ff5a6a");
  } else if (kind === "ghost") {
    ctx.globalAlpha = 0.92;
    P(-8, -16, 16, 11, color);
    P(-9, -11, 18, 6, color);
    P(-7, -19, 14, 4, color);
    for (let i = 0; i < 4; i++) P(-9 + i * 5, -5 + (i % 2) * 2, 4, 4 + (i % 2), alpha(color, 0.8));
    P(-6, -14, 4, 4, "#1a1024"); P(2, -14, 4, 4, "#1a1024");
    P(-4, -11, 8, 3, alpha("#ffffff", 0.12));
    P(3, -19, 2, 2, alpha("#ff5a6a", 0.8));
  } else if (kind === "skeleton") {
    P(-4, -18, 8, 6, "#e8e4d4"); P(-5, -13, 10, 3, "#cfcbb8");
    P(-4, -12, 2, 2, "#1a1420"); P(2, -12, 2, 2, "#1a1420");
    P(-1, -18, 2, 2, "#8a8478");
    P(-2, -10, 4, 10, "#e8e4d4");
    for (let i = 0; i < 4; i++) P(-6, -10 + i * 2, 12, 1, "#cfcbb8");
    P(-8, -10, 2, 7, "#e8e4d4"); P(6, -10, 2, 7, "#e8e4d4");
    P(-5, 0, 4, 1, "#cfcbb8"); P(1, 0, 4, 1, "#cfcbb8");
    P(8, -18, 1, 11, "#b8c4d8");
  } else if (kind === "beast") {
    P(-10, -9, 17, 8, color);
    P(-10, -11, 12, 4, light);
    P(4, -14, 8, 8, color);
    P(4, -17, 3, 4, color); P(9, -17, 3, 4, color);
    P(5, -12, 2, 2, "#ff5a5a"); P(9, -12, 2, 2, "#ff5a5a");
    P(11, -10, 3, 2, dark);
    P(-12, -12, 3, 5, dark);
    P(-7, -2, 3, 4, color); P(-2, -2, 3, 4, color);
    P(3, -2, 3, 4, color); P(-13, -13, 2, 4, color);
    P(-4, -13, 7, 2, dark);
  } else if (kind === "bat") {
    const flap = Math.sin(time / 160) > 0 ? 1 : 0;
    P(-3, -12, 6, 8, color);
    P(-11, -14 + flap * 3, 8, 5, light); P(3, -14 + flap * 3, 8, 5, light);
    P(-4, -17, 2, 4, dark); P(2, -17, 2, 4, dark);
    P(-2, -10, 1, 2, "#ff4a4a"); P(2, -10, 1, 2, "#ff4a4a");
    P(-9, -11 + flap * 3, 6, 2, color); P(3, -11 + flap * 3, 6, 2, color);
  } else if (kind === "spider") {
    P(-6, -10, 12, 8, color);
    P(-4, -12, 8, 4, light);
    P(-3, -11, 1, 2, "#ff3a3a"); P(2, -11, 1, 2, "#ff3a3a");
    P(-8, -8, 3, 1, dark); P(5, -8, 3, 1, dark);
    P(-9, -9, 2, 1, dark); P(7, -9, 2, 1, dark);
    P(-8, -5, 3, 1, dark); P(5, -5, 3, 1, dark);
    P(-4, -2, 2, 2, "#1a1420"); P(2, -2, 2, 2, "#1a1420");
  } else if (kind === "worm") {
    for (let i = 0; i < 5; i++)
      P(-9 + i * 3, -6 - i * 2 + Math.sin(time / 200 + i) * s, 6, 7, i % 2 ? color : light);
    P(-10, -10, 7, 6, color);
    P(-9, -8, 2, 2, "#ffe86a"); P(-5, -8, 2, 2, "#ffe86a");
    P(-8, -6, 5, 1, "#5a2030");
  } else if (kind === "brute") {
    P(-10, -16, 20, 12, color);
    P(-8, -18, 16, 5, light);
    P(-11, -14, 4, 9, color); P(7, -14, 4, 9, color);
    P(-6, -6, 5, 6, dark); P(1, -6, 5, 6, dark);
    P(-5, -16, 4, 3, "#ff6a5a"); P(1, -16, 4, 3, "#ff6a5a");
    P(-12, -21, 3, 5, "#d8c8a8"); P(9, -21, 3, 5, "#d8c8a8");
    P(10, -20, 2, 13, "#6a4a2a"); P(9, -22, 5, 3, "#8a6a3a");
    P(-3, -12, 6, 2, dark);
  } else {
    // boss — horned winged demon
    const glow = 0.5 + Math.sin(time / 300) * 0.3;
    ctx.fillStyle = alpha("#ff4a6a", glow * 0.25);
    ctx.beginPath();
    ctx.ellipse(0, -10 * s, 16 * s, 13 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    P(-13, -22, 9, 12, shade(color, -20)); P(4, -22, 9, 12, shade(color, -20));
    P(-15, -24, 5, 7, shade(color, -40)); P(10, -24, 5, 7, shade(color, -40));
    P(-9, -22, 18, 15, color);
    P(-6, -24, 12, 5, light);
    P(-6, -9, 5, 9, shade(color, -22)); P(1, -9, 5, 9, shade(color, -22));
    P(-4, -19, 3, 3, "#ffe86a"); P(3, -19, 3, 3, "#ffe86a");
    P(-3, -13, 6, 2, "#2a0a12");
    P(-8, -25, 3, 5, "#d8c8a8"); P(5, -25, 3, 5, "#d8c8a8");
    P(-2, -20, 4, 4, alpha("#ff8aa8", glow));
  }
  ctx.restore();
}

export function drawMob(ctx: CanvasRenderingContext2D, mob: Mob, time: number) {
  const cx = mob.tx * TILE + TILE / 2;
  const by = mob.ty * TILE + TILE - 3;
  drawCreature(ctx, cx, by, 1.5, mob.color, mob.name, time);
}

export function drawBoss(
  ctx: CanvasRenderingContext2D, name: string, color: string, tx: number, ty: number, time: number,
) {
  const cx = tx * TILE + TILE / 2;
  const by = ty * TILE + TILE + 6;
  drawCreature(ctx, cx, by, 2.6, color, "باس " + name, time);
}

// ------------------------------------------------------------------ ambient FX
export function drawAmbient(ctx: CanvasRenderingContext2D, region: Region, time: number, W: number, H: number) {
  const id = region.id;
  const count = id === "lava" ? 26 : id === "swamp" || id === "maple" ? 18 : id === "desert" ? 30 : 12;
  for (let i = 0; i < count; i++) {
    const sx = (h2(id + i) % 1000) / 1000;
    const sy = (h2(id + "y" + i) % 1000) / 1000;
    const sp = 0.4 + (h2(id + "s" + i) % 100) / 150;
    const y = ((sy * H + time * sp * (id === "lava" ? -0.05 : 0.03)) % H + H) % H;
    const x = (sx * W + Math.sin(time / 900 + i) * 12 + W) % W;
    if (id === "swamp" || id === "maple") {
      const gl = 0.35 + Math.sin(time / 360 + i) * 0.3;
      r(ctx, x, y, 2, 2, id === "maple" ? alpha("#f0a04a", 0.55) : alpha("#c8f08a", gl));
    } else if (id === "lava") {
      r(ctx, x, y, 2, 2, alpha(i % 3 ? "#ff8a3a" : "#ffd27a", 0.6));
    } else if (id === "desert") {
      r(ctx, x, y, 6, 1, alpha("#fff0c8", 0.25));
    } else if (id === "scream" || id === "lake") {
      const gl = 0.2 + Math.sin(time / 500 + i) * 0.15;
      r(ctx, x, y, 2, 2, alpha(id === "lake" ? "#ff8a9a" : "#b88ae8", gl));
    } else if (id === "tunnel" || id === "bridge") {
      r(ctx, x, y, 1, 1, alpha("#c8d0ff", 0.4));
    } else {
      r(ctx, x, y, 2, 1, alpha("#fff4d0", 0.25));
    }
  }
  if (id === "swamp" || id === "scream") {
    ctx.fillStyle = "rgba(180,200,190,0.05)";
    ctx.fillRect(0, H * 0.6, W, H * 0.4);
  }
  if (id === "desert") {
    ctx.fillStyle = alpha("#fff0c0", 0.05);
    ctx.fillRect(0, 0, W, H);
  }
}
