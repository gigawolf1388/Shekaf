import type { Mob, PlayerState } from "./types";

const KEY = "lale_saga_save_v1";
const SETTINGS_KEY = "lale_saga_settings_v1";

export interface SaveData {
  version: 1;
  player: PlayerState;
  mobs: Record<string, Mob[]>;
  chests: string[];
  playtime: number; // seconds
  savedAt: number; // epoch ms
  locName: string;
}

export interface SaveMeta {
  lvl: number;
  locName: string;
  savedAt: number;
  playtime: number;
  defeated: number;
  gold: number;
}

export function readSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as SaveData;
    if (!data || data.version !== 1 || !data.player) return null;
    return data;
  } catch {
    return null;
  }
}

export function saveMeta(): SaveMeta | null {
  const d = readSave();
  if (!d) return null;
  return {
    lvl: d.player.lvl,
    locName: d.locName,
    savedAt: d.savedAt,
    playtime: d.playtime,
    defeated: d.player.defeated.length,
    gold: d.player.gold,
  };
}

export function writeSave(data: Omit<SaveData, "version" | "savedAt">): boolean {
  try {
    const payload: SaveData = { ...data, version: 1, savedAt: Date.now() };
    localStorage.setItem(KEY, JSON.stringify(payload));
    return true;
  } catch {
    return false;
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

export function loadSettings(): { sound: boolean } {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { sound: true, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { sound: true };
}

export function saveSettings(s: { sound: boolean }) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

/** "۲ ساعت و ۱۴ دقیقه" style playtime. */
export function fmtPlaytime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0) return `${h} ساعت و ${m} دقیقه`;
  if (m > 0) return `${m} دقیقه`;
  return `${Math.floor(sec)} ثانیه`;
}

export function fmtDate(ms: number): string {
  try {
    return new Intl.DateTimeFormat("fa-IR", {
      month: "long", day: "numeric", hour: "2-digit", minute: "2-digit",
    }).format(new Date(ms));
  } catch {
    return "";
  }
}
