export type RegionId =
  | "village"
  | "farm"
  | "mountain"
  | "swamp"
  | "valley"
  | "tunnel"
  | "city"
  | "bridge"
  | "lava"
  | "desert"
  | "maple"
  | "lake"
  | "scream";

export interface Region {
  id: RegionId;
  name: string;
  ground: string[];
  obstacle: string;
  obstacleKind: "tree" | "rock" | "wall" | "cactus" | "deadtree" | "pillar";
  accent: string;
  danger: number; // 0..1 chance of encounter per step
  level: number; // enemy level
}

export interface EnemyDef {
  name: string;
  hp: number;
  atk: number;
  def: number;
  xp: number;
  gold: number;
  color: string;
  isBoss?: boolean;
}

export interface MemoryDef {
  id: string;
  title: string;
  lines: string[];
}

export interface BossDef {
  id: string;
  name: string;
  enemy: EnemyDef;
  memoryId: string;
  isFinal?: boolean;
}

export type NpcEffect =
  | { kind: "heal" }
  | { kind: "buyPotion"; price: number }
  | { kind: "smith"; id: string; price: number; atk: number }
  | { kind: "battle"; locKey: string; mobId: string }
  | { kind: "none" };

export interface NpcChoice {
  label: string;
  effect: NpcEffect;
  reply: string;
}

export interface NpcDef {
  id: string;
  name: string;
  tx: number;
  ty: number;
  body: string;
  head: string;
  lines: string[];
  choices?: NpcChoice[];
}

export interface ChestDef {
  id: string;
  tx: number;
  ty: number;
  gold?: number;
  potions?: number;
  atk?: number;
  text: string;
}

export interface LocationDef {
  x: number;
  y: number;
  name: string;
  region: RegionId;
  npcs?: NpcDef[];
  bossId?: string;
  chest?: ChestDef;
  /** Innocent atmospheric line, shown before the first rift. */
  flavor?: string;
  /** Reality-leak line, only shown once the player has seen a rift. */
  glitch?: string;
}

export interface PlayerState {
  loc: string; // "x,y"
  tx: number;
  ty: number;
  dir: "up" | "down" | "left" | "right";
  hp: number;
  mp: number;
  xp: number;
  lvl: number;
  gold: number;
  potions: number;
  atkBonus: number;
  defeated: string[];
  memories: string[];
  visited: string[];
  smithDone: string[];
  riftsEntered: string[];
  chests: string[];
}

export interface BattleState {
  enemy: EnemyDef;
  enemyHp: number;
  bossId?: string;
  mobLoc?: string;
  mobId?: string;
  log: string[];
  phase: "player" | "enemy" | "won" | "lost" | "fled";
  shake: number;
}

/** A creature roaming freely inside a location screen. */
export interface Mob extends EnemyDef {
  id: string;
  tx: number;
  ty: number;
  level: number;
}

export interface DialogueState {
  name: string;
  lines: string[];
  idx: number;
  choices?: NpcChoice[];
  reply?: string;
}

export type GameMode =
  | "world"
  | "dialogue"
  | "battle"
  | "memory"
  | "finalChoice"
  | "ending"
  | "map"
  | "status"
  | "settings"
  | "gameover";

export type EndingId = "accept" | "escape" | "absorb";

export const locKey = (x: number, y: number) => `${x},${y}`;
