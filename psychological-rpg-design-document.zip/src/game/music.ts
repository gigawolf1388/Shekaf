// Procedural soundtrack — ambient loops per region. No audio files needed.
import type { RegionId } from "./types";

type Osc = OscillatorNode;
type Gain = GainNode;

const NOTE = (name: string) => {
  const notes: Record<string, number> = {
    C: 261.63, D: 293.66, E: 329.63, F: 349.23, G: 392.0, A: 440.0, B: 493.88,
    "C#": 277.18, "D#": 311.13, "F#": 369.99, "G#": 415.3, "A#": 466.16,
  };
  const m = name.match(/^([A-G]#?)(\d)$/);
  if (!m) return 440;
  return notes[m[1]] * Math.pow(2, parseInt(m[2]) - 4);
};

interface RegionTheme {
  bpm: number;
  chord: number[]; // frequencies (Hz)
  melody: number[]; // indices into scale (+ scale.length for octave up)
  scale: number[]; // semitone offsets from root
  bass: number;
  pad: number[];
  drone: number;
  type: "sine" | "triangle" | "square" | "sawtooth";
  reverb?: number;
}

const THEMES: Record<RegionId, RegionTheme> = {
  village: {
    bpm: 72, chord: [NOTE("C3"), NOTE("E3"), NOTE("G3"), NOTE("C4")],
    melody: [0, 2, 4, 2, 3, 2, 1, 0], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("C2"), pad: [NOTE("C3"), NOTE("E3"), NOTE("G3")], drone: NOTE("C2"),
    type: "triangle", reverb: 0.3,
  },
  farm: {
    bpm: 80, chord: [NOTE("G3"), NOTE("B3"), NOTE("D4"), NOTE("G4")],
    melody: [2, 0, 3, 1, 2, 4, 3, 2], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("G2"), pad: [NOTE("G3"), NOTE("B3"), NOTE("D4")], drone: NOTE("G2"),
    type: "triangle",
  },
  mountain: {
    bpm: 64, chord: [NOTE("D3"), NOTE("F3"), NOTE("A3"), NOTE("D4")],
    melody: [0, 3, 2, 0, 1, 3, 2, 1], scale: [0, 2, 3, 5, 7, 8, 10],
    bass: NOTE("D2"), pad: [NOTE("D3"), NOTE("F3"), NOTE("A3")], drone: NOTE("D2"),
    type: "sine", reverb: 0.45,
  },
  swamp: {
    bpm: 56, chord: [NOTE("E3"), NOTE("G3"), NOTE("A#3"), NOTE("E4")],
    melody: [0, 1, 3, 2, 0, 2, 1, 0], scale: [0, 2, 3, 5, 7, 8, 10],
    bass: NOTE("E2"), pad: [NOTE("E3"), NOTE("G3"), NOTE("A#3")], drone: NOTE("E2"),
    type: "sawtooth", reverb: 0.6,
  },
  valley: {
    bpm: 76, chord: [NOTE("A3"), NOTE("C4"), NOTE("E4"), NOTE("A4")],
    melody: [0, 2, 4, 3, 2, 1, 2, 3], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("A2"), pad: [NOTE("A3"), NOTE("C4"), NOTE("E4")], drone: NOTE("A2"),
    type: "triangle",
  },
  tunnel: {
    bpm: 60, chord: [NOTE("G#2"), NOTE("B2"), NOTE("D#3"), NOTE("G#3")],
    melody: [0, 2, 1, 3, 0, 1, 2, 1], scale: [0, 2, 3, 5, 7, 8, 10],
    bass: NOTE("G#1"), pad: [NOTE("G#2"), NOTE("B2"), NOTE("D#3")], drone: NOTE("G#1"),
    type: "sine", reverb: 0.7,
  },
  city: {
    bpm: 88, chord: [NOTE("F3"), NOTE("A3"), NOTE("C4"), NOTE("F4")],
    melody: [2, 4, 3, 2, 1, 3, 2, 1], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("F2"), pad: [NOTE("F3"), NOTE("A3"), NOTE("C4")], drone: NOTE("F2"),
    type: "triangle", reverb: 0.25,
  },
  bridge: {
    bpm: 52, chord: [NOTE("C#3"), NOTE("E3"), NOTE("G#3"), NOTE("C#4")],
    melody: [0, 3, 2, 1, 0, 2, 3, 1], scale: [0, 2, 3, 5, 7, 8, 10],
    bass: NOTE("C#2"), pad: [NOTE("C#3"), NOTE("E3"), NOTE("G#3")], drone: NOTE("C#2"),
    type: "sine", reverb: 0.5,
  },
  lava: {
    bpm: 68, chord: [NOTE("B2"), NOTE("D3"), NOTE("F#3"), NOTE("B3")],
    melody: [0, 2, 3, 1, 2, 3, 2, 0], scale: [0, 2, 3, 5, 7, 8, 10],
    bass: NOTE("B1"), pad: [NOTE("B2"), NOTE("D3"), NOTE("F#3")], drone: NOTE("B1"),
    type: "sawtooth", reverb: 0.4,
  },
  desert: {
    bpm: 62, chord: [NOTE("E3"), NOTE("G#3"), NOTE("B3"), NOTE("E4")],
    melody: [0, 4, 3, 2, 1, 0, 2, 1], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("E2"), pad: [NOTE("E3"), NOTE("G#3"), NOTE("B3")], drone: NOTE("E2"),
    type: "sine", reverb: 0.55,
  },
  maple: {
    bpm: 70, chord: [NOTE("A3"), NOTE("C#4"), NOTE("E4"), NOTE("A4")],
    melody: [0, 2, 4, 3, 2, 0, 1, 2], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("A2"), pad: [NOTE("A3"), NOTE("C#4"), NOTE("E4")], drone: NOTE("A2"),
    type: "triangle", reverb: 0.35,
  },
  lake: {
    bpm: 48, chord: [NOTE("D3"), NOTE("F#3"), NOTE("A3"), NOTE("D4")],
    melody: [0, 3, 2, 3, 1, 2, 3, 2], scale: [0, 2, 4, 5, 7, 9, 11],
    bass: NOTE("D2"), pad: [NOTE("D3"), NOTE("F#3"), NOTE("A3")], drone: NOTE("D2"),
    type: "sine", reverb: 0.65,
  },
  scream: {
    bpm: 54, chord: [NOTE("G#2"), NOTE("B2"), NOTE("D3"), NOTE("G#3")],
    melody: [0, 1, 3, 2, 0, 3, 1, 0], scale: [0, 1, 3, 5, 6, 8, 10],
    bass: NOTE("G#1"), pad: [NOTE("G#2"), NOTE("B2"), NOTE("D3")], drone: NOTE("G#1"),
    type: "sawtooth", reverb: 0.7,
  },
};

export class MusicEngine {
  private ctx: AudioContext | null = null;
  private master: Gain | null = null;
  private convolver: ConvolverNode | null = null;
  private themeNodes: { oscs: Osc[]; gains: Gain[] } = { oscs: [], gains: [] };
  private timer: number | null = null;
  private step = 0;
  private currentTheme: RegionId | null = null;
  private enabled = true;
  private volume = 0.4;

  private ensure() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ctx.destination);
      // simple impulse response for reverb
      const ir = this.ctx.createBuffer(2, this.ctx.sampleRate * 1.5, this.ctx.sampleRate);
      for (let c = 0; c < 2; c++) {
        const data = ir.getChannelData(c);
        for (let i = 0; i < data.length; i++) {
          data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2.5);
        }
      }
      this.convolver = this.ctx.createConvolver();
      this.convolver.buffer = ir;
      this.convolver.connect(this.master);
    } catch {
      /* noop */
    }
  }

  private clearTheme() {
    this.themeNodes.oscs.forEach((o) => {
      try { o.stop(); } catch { /* noop */ }
    });
    this.themeNodes = { oscs: [], gains: [] };
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.step = 0;
  }

  private tone(freq: number, dur: number, vol: number, type: OscillatorType, detune = 0, pan = 0) {
    if (!this.ctx || !this.master) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    const p = this.ctx.createStereoPanner();
    o.type = type;
    o.frequency.value = freq;
    o.detune.value = detune;
    const start = this.ctx.currentTime;
    g.gain.setValueAtTime(0, start);
    g.gain.linearRampToValueAtTime(vol, start + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    p.pan.value = pan;
    o.connect(g).connect(p).connect(this.master);
    o.start(start);
    o.stop(start + dur + 0.05);
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.master) this.master.gain.value = this.volume;
  }

  setEnabled(e: boolean) {
    this.enabled = e;
    if (!e) this.stop();
  }

  stop() {
    this.clearTheme();
    this.currentTheme = null;
  }

  play(region: RegionId) {
    if (!this.enabled) return;
    this.ensure();
    if (!this.ctx || !this.master) return;
    if (this.ctx.state === "suspended") this.ctx.resume();
    if (this.currentTheme === region) return;
    this.currentTheme = region;
    this.clearTheme();

    const theme = THEMES[region];
    const beat = 60 / theme.bpm;

    // pad
    theme.pad.forEach((f, i) => {
      const o = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      o.type = theme.type;
      o.frequency.value = f;
      o.detune.value = (i - 1) * 6;
      g.gain.value = 0.04;
      o.connect(g).connect(this.master!);
      o.start();
      this.themeNodes.oscs.push(o);
      this.themeNodes.gains.push(g);
    });

    // drone
    {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "sine";
      o.frequency.value = theme.drone;
      g.gain.value = 0.055;
      o.connect(g).connect(this.master);
      o.start();
      this.themeNodes.oscs.push(o);
      this.themeNodes.gains.push(g);
    }

    // melodic loop
    const tick = () => {
      if (!this.enabled) return;
      const idx = theme.melody[this.step % theme.melody.length];
      const base = theme.chord[0];
      const oct = idx >= theme.scale.length ? 1 : 0;
      const semis = theme.scale[idx % theme.scale.length] + oct * 12;
      const freq = base * Math.pow(2, semis / 12);
      this.tone(freq, beat * 0.9, 0.055, theme.type, 0, 0);
      // harmony
      const harmFreq = freq * Math.pow(2, 4 / 12);
      if (this.step % 4 === 0) this.tone(harmFreq, beat * 1.8, 0.03, "triangle", 3, -0.3);
      // bass every 4 steps
      if (this.step % 4 === 0) {
        this.tone(theme.bass, beat * 2, 0.06, "triangle", 0, 0);
      }
      // occasional bell
      if (this.step % 8 === 2 && Math.random() < 0.5) {
        this.tone(freq * 2, beat * 1.5, 0.025, "sine", 0, 0.4);
      }
      this.step++;
    };
    tick();
    this.timer = window.setInterval(tick, beat * 1000) as unknown as number;
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }
}

export const music = new MusicEngine();
