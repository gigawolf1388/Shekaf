// Minimal WebAudio helper — monitor beeps, hits, blips. No assets needed.
let ctx: AudioContext | null = null;

function ac(): AudioContext | null {
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, dur: number, type: OscillatorType, vol: number, when = 0) {
  const a = ac();
  if (!a) return;
  const o = a.createOscillator();
  const g = a.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0, a.currentTime + when);
  g.gain.linearRampToValueAtTime(vol, a.currentTime + when + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + when + dur);
  o.connect(g).connect(a.destination);
  o.start(a.currentTime + when);
  o.stop(a.currentTime + when + dur + 0.05);
}

export const sfx = {
  blip() {
    tone(620, 0.07, "square", 0.05);
  },
  confirm() {
    tone(520, 0.08, "square", 0.06);
    tone(780, 0.1, "square", 0.05, 0.07);
  },
  hit() {
    tone(160, 0.12, "sawtooth", 0.08);
    tone(90, 0.16, "square", 0.06, 0.03);
  },
  hurt() {
    tone(220, 0.18, "sawtooth", 0.08);
    tone(110, 0.22, "triangle", 0.07, 0.05);
  },
  heal() {
    tone(440, 0.1, "sine", 0.07);
    tone(660, 0.12, "sine", 0.06, 0.09);
    tone(880, 0.16, "sine", 0.05, 0.18);
  },
  levelUp() {
    [392, 523, 659, 784].forEach((f, i) => tone(f, 0.14, "square", 0.05, i * 0.1));
  },
  monitorBeep() {
    tone(880, 0.12, "sine", 0.045);
  },
  flatline() {
    tone(880, 2.6, "sine", 0.05);
  },
  rift() {
    tone(180, 0.7, "sine", 0.06);
    tone(186, 0.7, "sine", 0.06, 0.05);
    tone(540, 0.5, "sine", 0.03, 0.2);
  },
  glitch() {
    tone(1200, 0.05, "square", 0.03);
    tone(300, 0.08, "sawtooth", 0.04, 0.05);
    tone(880, 0.1, "sine", 0.03, 0.12);
  },
  victory() {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.16, "square", 0.05, i * 0.12));
  },
};
