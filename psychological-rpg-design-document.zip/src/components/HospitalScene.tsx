import { useEffect, useState } from "react";
import type { MemoryDef } from "../game/types";
import { sfx } from "../game/audio";

interface Props {
  memory: MemoryDef;
  onDone: () => void;
}

export default function HospitalScene({ memory, onDone }: Props) {
  const [lineIdx, setLineIdx] = useState(0);
  const [shown, setShown] = useState(0);

  const line = memory.lines[lineIdx] ?? "";

  // monitor beep loop
  useEffect(() => {
    sfx.rift();
    const iv = setInterval(() => sfx.monitorBeep(), 1400);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    setShown(0);
    const iv = setInterval(() => {
      setShown((s) => (s >= line.length ? s : s + 1));
    }, 34);
    return () => clearInterval(iv);
  }, [lineIdx, line]);

  const done = shown >= line.length;
  const last = lineIdx >= memory.lines.length - 1;

  const advance = () => {
    if (!done) {
      setShown(line.length);
      return;
    }
    if (!last) {
      sfx.blip();
      setLineIdx((i) => i + 1);
    } else {
      sfx.glitch();
      onDone();
    }
  };

  return (
    <div
      className="scanlines fade-in-slow absolute inset-0 z-40 flex cursor-pointer flex-col items-center justify-between overflow-hidden bg-[#06080c] p-5"
      onClick={advance}
      dir="rtl"
    >
      {/* flickering fluorescent light */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-cyan-100/8 to-transparent" />

      <div className="w-full">
        <div className="monitor-line mb-1 flex items-center justify-between font-mono text-[11px] text-emerald-400/90" dir="ltr">
          <span>❤ 92 bpm</span>
          <span>ROOM 317</span>
          <span>03:17</span>
        </div>
        {/* ECG line */}
        <svg viewBox="0 0 300 30" className="monitor-line w-full opacity-70">
          <polyline
            points="0,15 40,15 50,15 55,5 60,25 65,15 110,15 120,15 125,5 130,25 135,15 180,15 190,15 195,5 200,25 205,15 250,15 260,15 265,5 270,25 275,15 300,15"
            fill="none"
            stroke="#34d399"
            strokeWidth="1.5"
          />
        </svg>
      </div>

      <div className="max-w-md text-center">
        <div className="rift-glow mb-5 text-sm font-bold tracking-wider text-fuchsia-300">
          ⟡ {memory.title} ⟡
        </div>
        <p className="min-h-24 text-[15px] leading-8 text-zinc-200" style={{ textShadow: "0 0 12px rgba(180,160,255,0.25)" }}>
          {line.slice(0, shown)}
          {!done && <span className="animate-pulse text-fuchsia-400">▌</span>}
        </p>
      </div>

      <div className="pb-2 text-xs text-zinc-500">
        {done ? (last ? "لمس کن تا به رؤیا برگردی..." : "▼ لمس کن") : ""}
      </div>
    </div>
  );
}
