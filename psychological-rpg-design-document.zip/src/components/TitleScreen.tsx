import { useEffect, useRef, useState } from "react";
import { sfx } from "../game/audio";
import { clearSave, fmtDate, fmtPlaytime, saveMeta, type SaveMeta } from "../game/save";

interface Props {
  onContinue: () => void;
  onNewGame: () => void;
}

export default function TitleScreen({ onContinue, onNewGame }: Props) {
  const [meta, setMeta] = useState<SaveMeta | null>(null);
  const [confirmNew, setConfirmNew] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => setMeta(saveMeta()), []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    let raf = 0;
    const rnd = (s: string) => {
      let h = 2166136261;
      for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
      return (h >>> 0) / 4294967296;
    };
    const px = (x: number, y: number, w: number, h: number, c: string) => {
      ctx.fillStyle = c;
      ctx.fillRect(Math.round(x), Math.round(y), w, h);
    };
    const draw = (t: number) => {
      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, "#141a33");
      sky.addColorStop(0.5, "#39304f");
      sky.addColorStop(0.8, "#8a5a4a");
      sky.addColorStop(1, "#c98b5e");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);
      for (let i = 0; i < 70; i++) {
        const sx = rnd("s" + i) * W, sy = rnd("sy" + i) * H * 0.55;
        px(sx, sy, 1, 1, `rgba(240,240,255,${0.25 + Math.sin(t / 800 + i) * 0.22})`);
      }
      // hills
      ctx.fillStyle = "#2a2440";
      ctx.beginPath();
      ctx.moveTo(0, H * 0.72);
      for (let x = 0; x <= W; x += 28) ctx.lineTo(x, H * 0.72 - Math.abs(Math.sin(x / 95)) * 46);
      ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
      ctx.fillStyle = "#1b1830";
      ctx.beginPath();
      ctx.moveTo(0, H * 0.8);
      for (let x = 0; x <= W; x += 22) ctx.lineTo(x, H * 0.8 - Math.abs(Math.cos(x / 70)) * 26);
      ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
      // lone tree silhouette with sleeping figure
      const tx = W * 0.68, ty = H * 0.88;
      px(tx - 7, ty - 70, 14, 70, "#0d0b14");
      [[-30, -92, 24], [0, -108, 30], [26, -94, 25], [-14, -78, 20], [16, -76, 21]].forEach(([bx, by, br]) => {
        ctx.fillStyle = "#0d0b14";
        ctx.beginPath();
        ctx.arc(tx + bx + Math.sin(t / 1300) * 2, ty + by, br, 0, Math.PI * 2);
        ctx.fill();
      });
      px(tx - 44, ty - 10, 30, 10, "#0d0b14");
      px(tx - 50, ty - 14, 10, 10, "#0d0b14");
      // fireflies
      for (let i = 0; i < 14; i++) {
        const fx = (rnd("f" + i) * W + Math.sin(t / 1100 + i) * 20 + W) % W;
        const fy = H * 0.45 + rnd("fy" + i) * H * 0.4;
        px(fx, fy, 2, 2, `rgba(230,240,160,${0.25 + Math.sin(t / 420 + i) * 0.22})`);
      }
      const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, W * 0.8);
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(0,0,0,0.75)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="absolute inset-0 z-[70] overflow-hidden bg-black" dir="rtl">
      <canvas ref={canvasRef} width={340} height={600} className="pixel absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/90" />

      <div className="relative flex h-full flex-col items-center justify-between px-7 py-10 text-center">
        <div className="mt-6 space-y-2">
          <h1 className="text-[34px] font-extrabold leading-tight tracking-[0.12em] text-amber-100" style={{ textShadow: "0 4px 24px rgba(0,0,0,0.95)" }}>
            افسانهٔ گل لاله
          </h1>
          <div className="mx-auto h-px w-32 bg-gradient-to-l from-transparent via-amber-300/70 to-transparent" />
          <p className="text-[11px] text-amber-50/60">یک نقش‌آفرینی نوبتی · شمشیر، روستا، و چیزی که در کوه بیدار شده</p>
        </div>

        <div className="w-full max-w-xs space-y-3 pb-6">
          {meta && !confirmNew && (
            <button
              onClick={() => {
                sfx.confirm();
                onContinue();
              }}
              className="w-full rounded-xl border-2 border-amber-300/70 bg-amber-400/20 px-5 py-3 text-right shadow-lg shadow-black/50 active:scale-[0.98]"
            >
              <div className="text-sm font-extrabold text-amber-50">▶ ادامهٔ سفر</div>
              <div className="mt-1 text-[10px] leading-5 text-amber-100/70">
                {meta.locName} · سطح {meta.lvl} · {meta.gold} سکه
                <br />
                {fmtPlaytime(meta.playtime)} بازی · {fmtDate(meta.savedAt)}
              </div>
            </button>
          )}

          {!confirmNew ? (
            <button
              onClick={() => {
                sfx.blip();
                if (meta) setConfirmNew(true);
                else onNewGame();
              }}
              className="w-full rounded-xl border border-zinc-500/60 bg-zinc-900/70 px-5 py-3 text-sm font-bold text-zinc-100 active:scale-[0.98]"
            >
              ✦ بازی جدید
            </button>
          ) : (
            <div className="space-y-2 rounded-xl border border-red-400/40 bg-red-950/60 p-3">
              <p className="text-[11px] leading-6 text-red-100">
                با شروع بازی جدید، ذخیرهٔ فعلی (سطح {meta?.lvl}) برای همیشه پاک می‌شود. مطمئنی؟
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    clearSave();
                    sfx.confirm();
                    onNewGame();
                  }}
                  className="flex-1 rounded-lg bg-red-500/90 py-2 text-xs font-bold text-white active:scale-95"
                >
                  بله، از نو شروع کن
                </button>
                <button
                  onClick={() => setConfirmNew(false)}
                  className="flex-1 rounded-lg border border-zinc-500 py-2 text-xs text-zinc-200 active:scale-95"
                >
                  انصراف
                </button>
              </div>
            </div>
          )}

          <p className="pt-1 text-[9px] leading-5 text-zinc-500">
            پیشرفت بازی به‌صورت خودکار روی همین دستگاه ذخیره می‌شود.
            <br />
            کلیدها: جهت‌نما = حرکت · Enter = تعامل · M = نقشه · Q = وضعیت
          </p>
        </div>
      </div>
    </div>
  );
}
