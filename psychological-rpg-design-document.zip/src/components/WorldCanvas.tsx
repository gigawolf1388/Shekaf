import { useEffect, useRef } from "react";
import { COLS, ROWS, TILE, CX, CY, getLayout, hashStr } from "../game/engine";
import type { LocationDef, Mob, PlayerState } from "../game/types";
import { BOSSES, REGIONS } from "../game/world";
import {
  drawAmbient, drawBoss, drawChest, drawGround, drawMob, drawNpc, drawObstacles, drawPlayer, drawProp,
} from "../game/render";

interface Props {
  loc: LocationDef;
  player: PlayerState;
  mobs: Mob[];
  bossState: "alive" | "rift" | "none";
}

export default function WorldCanvas({ loc, player, mobs, bossState }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef({ loc, player, mobs, bossState });
  stateRef.current = { loc, player, mobs, bossState };

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;

    const draw = (t: number) => {
      const { loc, player, mobs, bossState } = stateRef.current;
      const region = REGIONS[loc.region];
      const layout = getLayout(loc);
      const seed = hashStr(loc.x + "," + loc.y);
      const W = COLS * TILE, H = ROWS * TILE;

      ctx.clearRect(0, 0, W, H);
      drawGround(ctx, loc, region, layout, t);
      if (layout.propRect) {
        drawProp(ctx, layout.prop, layout.propRect.x * TILE, layout.propRect.y * TILE,
          layout.propRect.w * TILE, layout.propRect.h * TILE, t, region.accent);
      }
      drawObstacles(ctx, layout, region, t, seed);

      // boss or open rift
      if (loc.bossId) {
        const bx = CX, by = CY - 1;
        if (bossState === "alive") {
          drawBoss(ctx, BOSSES[loc.bossId].name, BOSSES[loc.bossId].enemy.color, bx, by, t);
        } else {
          const pulse = (Math.sin(t / 260) + 1) / 2;
          const cx = bx * TILE + TILE / 2, cy = by * TILE + TILE / 2;
          const outer = ctx.createRadialGradient(cx, cy, 2, cx, cy, 30 + pulse * 8);
          outer.addColorStop(0, "rgba(240,200,255,0.95)");
          outer.addColorStop(0.35, "rgba(168,85,247,0.75)");
          outer.addColorStop(1, "rgba(88,28,135,0)");
          ctx.fillStyle = outer;
          ctx.beginPath();
          ctx.ellipse(cx, cy, 22 + pulse * 8, 27 + pulse * 8, 0, 0, Math.PI * 2);
          ctx.fill();
          // spinning shards
          for (let i = 0; i < 7; i++) {
            const a = (i / 7) * Math.PI * 2 + t / 500;
            ctx.fillStyle = i % 2 ? "#f5d0fe" : "#c084fc";
            ctx.fillRect(cx + Math.cos(a) * (17 + pulse * 4) - 1.5, cy + Math.sin(a) * (22 + pulse * 4) - 1.5, 3, 3);
          }
          ctx.fillStyle = "#fdf4ff";
          ctx.beginPath();
          ctx.ellipse(cx, cy, 4 + pulse * 1.5, (22 + pulse * 3) * 0.45, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (loc.chest && !player.chests.includes(loc.chest.id)) {
        drawChest(ctx, loc.chest.tx, loc.chest.ty, t);
      }
      mobs.forEach((m) => drawMob(ctx, m, t));
      (loc.npcs ?? []).forEach((n) => drawNpc(ctx, n, t));
      drawPlayer(ctx, player, t);
      drawAmbient(ctx, region, t, W, H);

      const rid = region.id;

      // drifting fog banks (swamp / scream forest / lake)
      if (["swamp", "scream", "lake"].includes(rid)) {
        const fogCol = rid === "scream" ? "150,120,200" : rid === "lake" ? "220,130,150" : "185,205,190";
        for (let i = 0; i < 5; i++) {
          const speed = 0.012 + (i % 3) * 0.007;
          const fx = ((i * 190 + t * speed) % (W + 260)) - 130;
          const fy = H * (0.22 + (i % 3) * 0.23);
          const fr = 92 + i * 14;
          const fg = ctx.createRadialGradient(fx, fy, 6, fx, fy, fr);
          fg.addColorStop(0, `rgba(${fogCol},${0.11 + (i % 2) * 0.05})`);
          fg.addColorStop(1, `rgba(${fogCol},0)`);
          ctx.fillStyle = fg;
          ctx.beginPath();
          ctx.ellipse(fx, fy, fr, 34 + i * 7, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // birds crossing the sky (meadows & forests)
      if (["village", "farm", "maple"].includes(rid)) {
        for (let i = 0; i < 3; i++) {
          const bx = ((t * 0.018 + i * 157) % (W + 60)) - 30;
          const by = 24 + i * 26 + Math.sin(t / 420 + i * 2) * 5;
          const flap = Math.sin(t / 150 + i) > 0 ? 2 : 0;
          ctx.fillStyle = "rgba(28,28,40,0.5)";
          ctx.fillRect(bx, by, 4, 1);
          ctx.fillRect(bx + 4, by, 4, 1);
          ctx.fillRect(bx + 1, by - flap, 2, 1);
          ctx.fillRect(bx + 5, by - flap, 2, 1);
        }
      }

      // butterflies (village & maple)
      if (["village", "maple"].includes(rid)) {
        for (let i = 0; i < 4; i++) {
          const phase = t / 950 + i * 1.7;
          const bx = W * (0.15 + 0.7 * (0.5 + 0.5 * Math.sin(phase * 0.7 + i * 2.1)));
          const by = H * (0.3 + 0.35 * (0.5 + 0.5 * Math.sin(phase * 1.3 + i)));
          ctx.fillStyle = i % 2 ? "rgba(240,205,120,0.85)" : "rgba(240,150,190,0.85)";
          ctx.fillRect(bx, by, 1, 3);
          ctx.fillRect(bx - 2, by - 1 + (i % 2), 2, 2);
          if (Math.sin(t / 80 + i) > 0) ctx.fillRect(bx + 2, by - 2, 2, 2);
        }
      }

      // foreground grass silhouettes for depth
      if (["village", "farm", "maple", "swamp"].includes(rid)) {
        ctx.fillStyle = rid === "maple" ? "rgba(115,72,26,0.9)" : "rgba(16,34,16,0.88)";
        for (let x = 0; x < W; x += 8) {
          const h = 9 + ((x * 7) % 11);
          const sway = Math.sin(t / 720 + x * 0.8) * 2.2;
          ctx.beginPath();
          ctx.moveTo(x, H);
          ctx.quadraticCurveTo(x + sway, H - h * 0.6, x + 3 + sway, H - h);
          ctx.quadraticCurveTo(x + 5 + sway, H - h * 0.55, x + 7, H);
          ctx.closePath();
          ctx.fill();
        }
        ctx.fillStyle = rid === "maple" ? "rgba(80,50,18,0.5)" : "rgba(10,24,10,0.5)";
        for (let x = 4; x < W; x += 11) {
          const h = 5 + ((x * 13) % 7);
          ctx.fillRect(x, H - h, 2, h);
        }
      }

      // per-region color grade
      const TINTS: Record<string, string> = {
        village: "rgba(255,190,110,0.05)", farm: "rgba(255,210,120,0.05)",
        mountain: "rgba(170,195,255,0.05)", swamp: "rgba(90,190,140,0.055)",
        valley: "rgba(255,220,150,0.045)", tunnel: "rgba(110,130,255,0.08)",
        city: "rgba(255,230,180,0.055)", bridge: "rgba(140,160,255,0.07)",
        lava: "rgba(255,110,40,0.08)", desert: "rgba(255,215,140,0.07)",
        maple: "rgba(255,160,80,0.06)", lake: "rgba(255,90,110,0.06)",
        scream: "rgba(170,110,255,0.08)",
      };
      ctx.fillStyle = TINTS[rid] ?? "rgba(0,0,0,0)";
      ctx.fillRect(0, 0, W, H);

      // soft directional light + vignette
      const light = ctx.createLinearGradient(0, 0, 0, H);
      light.addColorStop(0, "rgba(255,240,200,0.05)");
      light.addColorStop(1, "rgba(0,0,20,0.22)");
      ctx.fillStyle = light;
      ctx.fillRect(0, 0, W, H);

      if (["swamp", "scream", "tunnel", "lake", "bridge"].includes(loc.region)) {
        const g = ctx.createRadialGradient(W / 2, H / 2, 70, W / 2, H / 2, 260);
        g.addColorStop(0, "rgba(0,0,0,0)");
        g.addColorStop(1, "rgba(0,0,8,0.52)");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      }

      // faint CRT scanlines
      ctx.fillStyle = "rgba(0,0,0,0.055)";
      for (let sy = 0; sy < H; sy += 4) ctx.fillRect(0, sy, W, 1);

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="relative">
      <canvas
        ref={ref}
        width={COLS * TILE}
        height={ROWS * TILE}
        className="pixel h-auto w-full rounded-lg border-2 border-zinc-700/60 shadow-[0_0_40px_rgba(0,0,0,0.65)]"
      />
      {/* NPC nameplates */}
      {(loc.npcs ?? []).map((n) => (
        <div
          key={n.id}
          className="pointer-events-none absolute -translate-x-1/2 whitespace-nowrap rounded bg-black/55 px-1 py-px text-[8px] font-bold text-amber-100/90"
          style={{ left: `${((n.tx + 0.5) / COLS) * 100}%`, top: `${((n.ty + 0.9) / ROWS) * 100}%` }}
        >
          {n.name.split("،")[0]}
        </div>
      ))}
      {/* roaming monster markers */}
      {mobs.map((m) => (
        <div
          key={m.id}
          className="pointer-events-none absolute -translate-x-1/2 text-[7px] font-bold text-red-200/90"
          style={{ left: `${((m.tx + 0.5) / COLS) * 100}%`, top: `${((m.ty - 0.2) / ROWS) * 100}%` }}
        >
          <span className="rounded bg-red-950/70 px-1">⚔</span>
        </div>
      ))}
    </div>
  );
}
