import { useEffect, useRef } from "react";
import type { BattleState, EnemyDef, PlayerState } from "../game/types";
import { maxHp, maxMp, playerAtk } from "../game/engine";
import { alphaColor, drawCreature } from "../game/render";

interface Props {
  battle: BattleState;
  player: PlayerState;
  onAction: (a: "attack" | "skill" | "potion" | "flee" | "continue") => void;
}

function Bar({ val, max, color }: { val: number; max: number; color: string }) {
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-sm border border-zinc-700 bg-zinc-900">
      <div
        className="h-full transition-all duration-300"
        style={{ width: `${Math.max(0, (val / max) * 100)}%`, background: color }}
      />
    </div>
  );
}

function EnemyArena({ enemy }: { enemy: EnemyDef }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    let raf = 0;
    const draw = (t: number) => {
      ctx.clearRect(0, 0, W, H);
      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, "#0c0a16");
      sky.addColorStop(0.55, "#191330");
      sky.addColorStop(1, "#0a0a12");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);

      // distant arches / spikes
      ctx.fillStyle = alphaColor(enemy.color, 0.12);
      for (let i = 0; i < 7; i++) {
        const x = 8 + i * 32;
        const h = 22 + ((i * 37) % 34);
        ctx.beginPath();
        ctx.moveTo(x, H * 0.62);
        ctx.lineTo(x + 12, H * 0.62 - h);
        ctx.lineTo(x + 24, H * 0.62);
        ctx.closePath();
        ctx.fill();
      }
      // arena floor
      const floor = ctx.createRadialGradient(W / 2, H * 0.82, 8, W / 2, H * 0.82, W * 0.55);
      floor.addColorStop(0, alphaColor(enemy.color, 0.3));
      floor.addColorStop(0.5, alphaColor(enemy.color, 0.08));
      floor.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = floor;
      ctx.beginPath();
      ctx.ellipse(W / 2, H * 0.82, W * 0.46, H * 0.16, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = alphaColor(enemy.color, 0.4);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(W / 2, H * 0.82, W * 0.34, H * 0.1, 0, 0, Math.PI * 2);
      ctx.stroke();

      // particles
      for (let i = 0; i < 22; i++) {
        const px = (i * 71) % W;
        const py = (H - ((t / 26 + i * 41) % H)) | 0;
        ctx.fillStyle = alphaColor(i % 3 ? enemy.color : "#ffffff", 0.25);
        ctx.fillRect(px, py, 2, 2);
      }

      const scale = enemy.isBoss ? 4.1 : 4.4;
      drawCreature(ctx, W / 2, H * 0.86, scale, enemy.color, enemy.name, t);

      // vignette
      const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, W * 0.65);
      v.addColorStop(0, "rgba(0,0,0,0)");
      v.addColorStop(1, "rgba(0,0,0,0.7)");
      ctx.fillStyle = v;
      ctx.fillRect(0, 0, W, H);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [enemy.name, enemy.color, enemy.isBoss]);
  return <canvas ref={ref} width={260} height={170} className="pixel h-full w-full object-cover" />;
}

export default function BattleView({ battle, player, onAction }: Props) {
  const logRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [battle.log]);

  const over = battle.phase === "won" || battle.phase === "lost" || battle.phase === "fled";
  const e = battle.enemy;

  return (
    <div className="battle-in absolute inset-0 z-30 flex flex-col bg-[#08070f]" dir="rtl">
      {/* enemy name plate */}
      <div className="z-10 flex items-center justify-between gap-2 border-b border-zinc-800/70 bg-black/50 px-3 py-2">
        <div className="min-w-0">
          <div className="truncate text-[13px] font-extrabold" style={{ color: e.color }}>
            {e.name}
          </div>
          <div className="text-[9px] text-zinc-500">
            {e.isBoss ? "هیولای بزرگ" : "هیولای آزاد"} — {battle.phase === "player" ? "نوبت تو" : battle.phase === "enemy" ? "حملهٔ دشمن..." : " "}
          </div>
        </div>
        <div className="w-32">
          <Bar val={battle.enemyHp} max={e.hp} color="#e85a5a" />
          <div className="mt-0.5 text-left text-[9px] text-zinc-400">
            {Math.max(0, battle.enemyHp)} / {e.hp}
          </div>
        </div>
      </div>

      {/* arena */}
      <div className={`relative min-h-0 flex-1 overflow-hidden ${battle.shake % 2 === 1 ? "screen-shake" : ""}`}>
        <EnemyArena enemy={e} />
        {battle.phase === "won" && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/55">
            <div className="text-center">
              <div className="text-3xl">✦</div>
              <div className="mt-1 text-sm font-extrabold text-amber-200">پیروزی!</div>
            </div>
          </div>
        )}
        {battle.phase === "lost" && (
          <div className="absolute inset-0 flex items-center justify-center bg-red-950/60">
            <div className="text-sm font-extrabold text-red-200">سقوط...</div>
          </div>
        )}
      </div>

      {/* log */}
      <div
        ref={logRef}
        className="mx-2 mb-2 h-20 overflow-y-auto rounded-lg border border-zinc-700/50 bg-black/55 p-2 text-[11px] leading-5 text-zinc-300"
      >
        {battle.log.map((l, i) => (
          <div key={i} className={i === battle.log.length - 1 ? "text-amber-100" : ""}>{l}</div>
        ))}
      </div>

      {/* player panel */}
      <div className="border-t border-zinc-800 bg-zinc-950/95 p-3">
        <div className="mb-1.5 flex items-center justify-between text-[11px]">
          <span className="font-bold text-sky-300">قهرمان — سطح {player.lvl}</span>
          <span className="text-zinc-400">حمله {playerAtk(player)}</span>
        </div>
        <div className="mb-1 flex items-center gap-2">
          <span className="w-6 text-[10px] text-red-300">HP</span>
          <Bar val={player.hp} max={maxHp(player.lvl)} color="#4ade80" />
          <span className="w-14 text-left text-[10px] text-zinc-400">
            {player.hp}/{maxHp(player.lvl)}
          </span>
        </div>
        <div className="mb-2 flex items-center gap-2">
          <span className="w-6 text-[10px] text-sky-300">MP</span>
          <Bar val={player.mp} max={maxMp(player.lvl)} color="#60a5fa" />
          <span className="w-14 text-left text-[10px] text-zinc-400">
            {player.mp}/{maxMp(player.lvl)}
          </span>
        </div>

        {over ? (
          <button
            className="w-full rounded-lg bg-amber-400 py-2.5 text-sm font-extrabold text-zinc-900 active:scale-[0.98]"
            onClick={() => onAction("continue")}
          >
            {battle.phase === "lost" ? "تاریکی..." : battle.phase === "fled" ? "بازگشت به منطقه" : "ادامه"}
          </button>
        ) : (
          <div className="grid grid-cols-2 gap-1.5">
            <button
              className="rounded-lg border border-red-300/20 bg-red-500/85 py-2 text-xs font-bold text-white active:scale-[0.98] disabled:opacity-40"
              disabled={battle.phase !== "player"}
              onClick={() => onAction("attack")}
            >
              ⚔️ حمله
            </button>
            <button
              className="rounded-lg border border-indigo-300/20 bg-indigo-500/85 py-2 text-xs font-bold text-white active:scale-[0.98] disabled:opacity-40"
              disabled={battle.phase !== "player" || player.mp < 8}
              onClick={() => onAction("skill")}
            >
              💥 ضربهٔ ذهنی (۸ MP)
            </button>
            <button
              className="rounded-lg border border-emerald-300/20 bg-emerald-600/85 py-2 text-xs font-bold text-white active:scale-[0.98] disabled:opacity-40"
              disabled={battle.phase !== "player" || player.potions <= 0}
              onClick={() => onAction("potion")}
            >
              🧪 معجون ({player.potions})
            </button>
            <button
              className="rounded-lg border border-zinc-500/20 bg-zinc-600/85 py-2 text-xs font-bold text-white active:scale-[0.98] disabled:opacity-40"
              disabled={battle.phase !== "player" || !!e.isBoss}
              onClick={() => onAction("flee")}
            >
              🏃 فرار
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
