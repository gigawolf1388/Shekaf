import { useEffect, useRef, useState } from "react";
import { sfx } from "../game/audio";

interface Props {
  onStart: () => void;
}

type Beat = {
  speaker?: string;
  text: string;
  sub?: string;
  wake: number; // 0 = eyes closed / blurry, 1 = fully awake
  shake?: boolean;
};

const BEATS: Beat[] = [
  { text: "...", sub: "برگ‌ها آرام تکان می‌خورند. آفتاب از لای شاخه‌ها می‌تابد.", wake: 0 },
  { speaker: "کدخدا", text: "آهای! پسر! تویِ زیر درخت!", wake: 0.15 },
  { speaker: "کدخدا", text: "باز هم اینجا خوابت برده؟ از صبح دنبالت می‌گردم.", wake: 0.35 },
  { text: "پلک‌هایت سنگین است. چشم که باز می‌کنی، پیرمردی با عصا بالای سرت ایستاده.", wake: 0.6 },
  { speaker: "کدخدا", text: "بلند شو جوون. سرت ضربه خورده بوده، دو روز تمام تب داشتی.", wake: 0.85 },
  { speaker: "کدخدا", text: "گفتم شاید حافظه‌ت برنگرده... اسمت هم یادت نیست، نه؟", wake: 1 },
  { speaker: "کدخدا", text: "عیبی نداره. روستای گل لاله به هر غریبه‌ای جا می‌ده.", wake: 1 },
  { speaker: "کدخدا", text: "اما یه چیزی رو بدون: از دیشب، صدایی از کوه ایکجا میاد. چیزی بیدار شده.", wake: 1, shake: true },
  { speaker: "کدخدا", text: "اون شمشیر کنار دستت مال خودته. برش دار و بیا میدون روستا.", wake: 1 },
  { text: "دستت را روی قبضهٔ شمشیر می‌گذاری. سرد است... و عجیب آشنا.", sub: "انگار سال‌هاست منتظرت بوده.", wake: 1 },
];

export default function IntroCutscene({ onStart }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [beat, setBeat] = useState(0);
  const [shown, setShown] = useState(0);
  const [done, setDone] = useState(false);
  const wakeRef = useRef(0);
  const shakeRef = useRef(0);

  const current = BEATS[beat];
  wakeRef.current = current.wake;

  // typewriter
  useEffect(() => {
    setShown(0);
    const iv = setInterval(() => {
      setShown((s) => (s >= current.text.length ? s : s + 1));
    }, 32);
    return () => clearInterval(iv);
  }, [beat, current.text]);

  useEffect(() => {
    if (current.speaker) sfx.blip();
    if (current.shake) {
      shakeRef.current = performance.now();
      sfx.rift();
    }
  }, [beat]);

  const advance = () => {
    if (shown < current.text.length) {
      setShown(current.text.length);
      return;
    }
    if (beat < BEATS.length - 1) setBeat((b) => b + 1);
    else setDone(true);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onStart();
      else if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        if (done) onStart();
        else advance();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  // ---------------------------------------------------- pixel scene
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    let raf = 0;

    const rnd = (s: string) => {
      let h = 2166136261;
      for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619);
      }
      return (h >>> 0) / 4294967296;
    };
    const px = (x: number, y: number, w: number, h: number, c: string) => {
      ctx.fillStyle = c;
      ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
    };

    const draw = (t: number) => {
      const wake = wakeRef.current;
      ctx.clearRect(0, 0, W, H);

      // ---- warm morning sky
      const sky = ctx.createLinearGradient(0, 0, 0, H * 0.75);
      sky.addColorStop(0, "#2a3d6b");
      sky.addColorStop(0.35, "#6a6ea0");
      sky.addColorStop(0.68, "#d99a6c");
      sky.addColorStop(1, "#f3c98b");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);

      // sun
      const sunY = H * 0.46;
      const halo = ctx.createRadialGradient(W * 0.3, sunY, 4, W * 0.3, sunY, 120);
      halo.addColorStop(0, "rgba(255,230,160,0.55)");
      halo.addColorStop(1, "rgba(255,210,140,0)");
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(W * 0.3, sunY, 120, 0, Math.PI * 2);
      ctx.fill();
      px(W * 0.3 - 16, sunY - 16, 32, 32, "#ffeec0");
      px(W * 0.3 - 20, sunY - 10, 40, 20, "#ffeec0");

      // clouds
      for (let i = 0; i < 6; i++) {
        const cy = 28 + rnd("c" + i) * 90;
        const cx = ((rnd("cx" + i) * W + t / 140) % (W + 140)) - 70;
        px(cx, cy, 52, 6, "rgba(255,230,210,0.22)");
        px(cx + 12, cy - 6, 30, 6, "rgba(255,230,210,0.18)");
        px(cx + 6, cy + 6, 40, 4, "rgba(220,180,170,0.14)");
      }

      // distant hills
      ctx.fillStyle = "#6b7f5a";
      ctx.beginPath();
      ctx.moveTo(0, H * 0.66);
      for (let x = 0; x <= W; x += 26) ctx.lineTo(x, H * 0.66 - Math.abs(Math.sin(x / 110)) * 34);
      ctx.lineTo(W, H);
      ctx.lineTo(0, H);
      ctx.fill();
      ctx.fillStyle = "#546b46";
      ctx.beginPath();
      ctx.moveTo(0, H * 0.72);
      for (let x = 0; x <= W; x += 22) ctx.lineTo(x, H * 0.72 - Math.abs(Math.cos(x / 80)) * 22);
      ctx.lineTo(W, H);
      ctx.lineTo(0, H);
      ctx.fill();

      // village rooftops far away
      for (let i = 0; i < 5; i++) {
        const vx = 26 + i * 62;
        const vy = H * 0.7 + (i % 2) * 5;
        px(vx, vy, 26, 16, "#7a5a3e");
        ctx.fillStyle = "#8c3f34";
        ctx.beginPath();
        ctx.moveTo(vx - 4, vy);
        ctx.lineTo(vx + 13, vy - 11);
        ctx.lineTo(vx + 30, vy);
        ctx.closePath();
        ctx.fill();
        px(vx + 9, vy + 6, 7, 10, "#4a3424");
        const sm = (t / 60 + i * 9) % 26;
        ctx.fillStyle = `rgba(220,215,205,${0.2 * (1 - sm / 26)})`;
        ctx.beginPath();
        ctx.arc(vx + 22, vy - 12 - sm, 3 + sm / 8, 0, Math.PI * 2);
        ctx.fill();
      }

      // ---- meadow ground
      const grd = ctx.createLinearGradient(0, H * 0.74, 0, H);
      grd.addColorStop(0, "#5e8a42");
      grd.addColorStop(1, "#2e4a24");
      ctx.fillStyle = grd;
      ctx.fillRect(0, H * 0.74, W, H * 0.26);
      for (let i = 0; i < 160; i++) {
        const gx = rnd("g" + i) * W;
        const gy = H * 0.74 + rnd("gy" + i) * H * 0.26;
        const sway = Math.sin(t / 700 + i) * 1.6;
        px(gx + sway, gy, 1, 4 + (i % 3), `rgba(${60 + (i % 30)},${110 + (i % 40)},${50},0.8)`);
        if (i % 11 === 0) px(gx + sway - 1, gy - 3, 3, 3, i % 22 === 0 ? "#e8619a" : "#f0d055");
      }

      // ---- the great tree (right side)
      const tx = W * 0.72, ty = H * 0.8;
      // roots
      ctx.fillStyle = "#4a3521";
      for (const [rx, rw] of [[-34, 20], [-12, 14], [14, 18], [30, 14]] as const) {
        ctx.beginPath();
        ctx.moveTo(tx + rx, ty);
        ctx.quadraticCurveTo(tx + rx * 1.4, ty + 10, tx + rx * 1.8, ty + 16);
        ctx.lineTo(tx + rx * 1.8 + rw * 0.5, ty + 16);
        ctx.quadraticCurveTo(tx + rx * 1.2, ty + 8, tx + rx + rw, ty);
        ctx.closePath();
        ctx.fill();
      }
      // trunk
      px(tx - 26, ty - 150, 52, 152, "#5a3f26");
      px(tx - 26, ty - 150, 16, 152, "#6d4d2e");
      px(tx + 12, ty - 150, 14, 152, "#45301c");
      for (let i = 0; i < 16; i++) {
        const by = ty - 146 + i * 9;
        px(tx - 20 + (i % 3) * 9, by, 2, 7, "rgba(40,26,14,0.55)");
        px(tx + 2 + (i % 2) * 6, by + 3, 2, 6, "rgba(40,26,14,0.4)");
      }
      // branches
      ctx.strokeStyle = "#5a3f26";
      ctx.lineWidth = 9;
      ctx.beginPath();
      ctx.moveTo(tx - 8, ty - 128); ctx.lineTo(tx - 58, ty - 168);
      ctx.moveTo(tx + 10, ty - 140); ctx.lineTo(tx + 56, ty - 176);
      ctx.moveTo(tx, ty - 150); ctx.lineTo(tx - 20, ty - 196);
      ctx.stroke();
      // canopy (layered blobs)
      const sway = Math.sin(t / 1100) * 4;
      const blobs: Array<[number, number, number, string]> = [
        [-72, -186, 48, "#2f5a28"], [-20, -214, 58, "#3b6c31"], [38, -192, 52, "#2f5a28"],
        [-44, -168, 44, "#447d38"], [26, -160, 46, "#447d38"], [-4, -238, 42, "#51913f"],
        [-66, -220, 34, "#3b6c31"], [62, -214, 36, "#3b6c31"],
      ];
      blobs.forEach(([bx, by, br, col], i) => {
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(tx + bx + sway * (i % 3 ? 1 : 0.5), ty + by, br, 0, Math.PI * 2);
        ctx.fill();
      });
      // highlight leaves
      for (let i = 0; i < 70; i++) {
        const a = rnd("l" + i) * Math.PI * 2;
        const rr = 40 + rnd("lr" + i) * 110;
        const lx = tx + Math.cos(a) * rr * 0.95 + sway;
        const ly = ty - 196 + Math.sin(a) * rr * 0.52;
        if (ly > ty - 120) continue;
        px(lx, ly, 4, 4, i % 4 === 0 ? "#79b254" : i % 3 === 0 ? "#2b4f23" : "#5c9843");
      }
      // falling leaves
      for (let i = 0; i < 12; i++) {
        const fall = (t / 22 + i * 60) % 260;
        const lx = tx - 60 + rnd("fl" + i) * 140 + Math.sin(t / 420 + i) * 14;
        const ly = ty - 200 + fall;
        if (ly > ty + 4) continue;
        px(lx, ly, 3, 3, i % 2 ? "#6f9c3f" : "#b4883a");
      }

      // ---- hero lying at the base of the tree
      const hx = tx - 86, hy = ty - 4;
      const liftRaw = wake;
      const lift = liftRaw * liftRaw * (3 - 2 * liftRaw); // smoothstep
      const breathe = Math.sin(t / 620) * 1.2;
      ctx.fillStyle = "rgba(20,30,14,0.3)";
      ctx.beginPath();
      ctx.ellipse(hx + 2, hy + 4, 40 - lift * 16, 7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.save();
      ctx.translate(hx, hy);
      ctx.rotate((-Math.PI / 2) * (1 - lift) * 0.92);
      // cloak
      px(-22, -26 + breathe * (1 - lift), 30, 26, "#8a2438");
      px(-20, -24, 10, 24, "#a12e44");
      // body
      px(-14, -30 + breathe * (1 - lift), 26, 30, "#3d5fb8");
      px(-10, -30, 8, 28, "#5478d4");
      px(-14, -10, 26, 4, "#2a3f80");
      px(-4, -14, 8, 5, "#d8b44a");
      // legs
      px(-12, 0, 10, 14, "#2f3a5a");
      px(2, 0, 10, 14, "#2f3a5a");
      px(-13, 12, 12, 6, "#4a3524");
      px(1, 12, 12, 6, "#4a3524");
      // arms
      px(-22, -26, 8, 16, "#3d5fb8");
      px(12, -26, 8, 16, "#33509c");
      // head
      px(-10, -52, 22, 22, "#e8c49a");
      px(-10, -54, 22, 8, "#33241a");
      px(-12, -50, 4, 10, "#33241a");
      // eyes: closed → open
      if (wake < 0.3) {
        px(-5, -42, 5, 2, "#5a4030");
        px(4, -42, 5, 2, "#5a4030");
      } else {
        px(-5, -44, 5, 5, "#f6ece0");
        px(4, -44, 5, 5, "#f6ece0");
        px(-3, -43, 3, 3, "#243a52");
        px(6, -43, 3, 3, "#243a52");
      }
      px(-2, -34, 5, 2, "#a8655a");
      px(-12, -30, 24, 4, "#b83a3a");
      ctx.restore();

      // sword lying beside him (glints)
      const sgx = hx + 34, sgy = ty - 6;
      px(sgx, sgy - 2, 44, 5, "#cfd6e8");
      px(sgx, sgy - 2, 44, 2, "#f2f6ff");
      px(sgx + 44, sgy - 6, 5, 13, "#c8a44a");
      px(sgx + 49, sgy - 3, 14, 7, "#6b4626");
      px(sgx + 62, sgy - 4, 5, 9, "#c8a44a");
      const glint = (t / 9) % 420;
      if (glint < 44) px(sgx + glint, sgy - 3, 6, 6, "rgba(255,255,255,0.85)");

      // ---- kadkhoda (village elder) silhouette approaching from the left
      const kAppear = Math.min(1, Math.max(0, (wake - 0.05) * 2));
      if (kAppear > 0) {
        const kx = 86 + (1 - kAppear) * -50, ky = ty + 6;
        const step = Math.sin(t / 420) > 0 ? 1 : 0;
        ctx.globalAlpha = kAppear;
        ctx.fillStyle = "rgba(20,30,14,0.3)";
        ctx.beginPath();
        ctx.ellipse(kx + 8, ky + 2, 18, 5, 0, 0, Math.PI * 2);
        ctx.fill();
        // robe
        px(kx - 4, ky - 44, 26, 46, "#6b5a46");
        px(kx - 4, ky - 44, 9, 46, "#7d6a52");
        px(kx - 6, ky - 20, 30, 5, "#4f412f");
        px(kx - 2, ky - 2 + step, 10, 5, "#3a2f22");
        px(kx + 10, ky - 2 - step, 10, 5, "#3a2f22");
        // arms
        px(kx - 12, ky - 40, 9, 22, "#6b5a46");
        px(kx + 20, ky - 40, 9, 20, "#5f5040");
        // head + hat + white beard
        px(kx + 1, ky - 64, 18, 20, "#d8b48a");
        px(kx - 4, ky - 68, 28, 7, "#5a4a36");
        px(kx + 2, ky - 72, 16, 6, "#5a4a36");
        px(kx + 4, ky - 48, 13, 14, "#e8e4da");
        px(kx + 2, ky - 50, 17, 5, "#efeae0");
        px(kx + 4, ky - 58, 4, 4, "#2a2420");
        px(kx + 12, ky - 58, 4, 4, "#2a2420");
        // staff
        px(kx - 16, ky - 56, 4, 58, "#5a3f26");
        px(kx - 19, ky - 60, 10, 6, "#7a5a3a");
        ctx.globalAlpha = 1;
      }

      // god rays through the canopy
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < 5; i++) {
        const rx = W * 0.22 + i * 56;
        const g = ctx.createLinearGradient(rx, H * 0.2, rx - 50, H);
        g.addColorStop(0, `rgba(255,236,186,${0.1 + Math.sin(t / 1400 + i) * 0.03})`);
        g.addColorStop(1, "rgba(255,236,186,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(rx, H * 0.18);
        ctx.lineTo(rx + 26, H * 0.18);
        ctx.lineTo(rx - 36, H);
        ctx.lineTo(rx - 86, H);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      // pollen motes
      for (let i = 0; i < 26; i++) {
        const mx = (rnd("m" + i) * W + Math.sin(t / 1600 + i) * 24 + W) % W;
        const my = H * 0.3 + ((rnd("my" + i) * H * 0.6 + t / 50) % (H * 0.6));
        px(mx, my, 2, 2, `rgba(255,244,205,${0.2 + Math.sin(t / 500 + i) * 0.18})`);
      }

      // eyelid blur when not awake
      if (wake < 1) {
        const closed = 1 - wake;
        ctx.fillStyle = `rgba(8,6,10,${0.55 * closed})`;
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = "#07060a";
        ctx.fillRect(0, 0, W, H * 0.42 * closed);
        ctx.fillRect(0, H - H * 0.42 * closed, W, H * 0.42 * closed);
      }

      // shake on the ominous line
      const since = performance.now() - shakeRef.current;
      if (since < 600) {
        const amp = (1 - since / 600) * 5;
        ctx.save();
        ctx.globalCompositeOperation = "source-over";
        ctx.fillStyle = `rgba(90,40,70,${0.1 * (1 - since / 600)})`;
        ctx.fillRect(Math.sin(since / 30) * amp, 0, W, H);
        ctx.restore();
      }

      // vignette
      const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.22, W / 2, H / 2, W * 0.78);
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(10,6,4,0.7)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="absolute inset-0 z-[60] select-none overflow-hidden bg-black" dir="rtl" onClick={() => (done ? onStart() : advance())}>
      <canvas ref={canvasRef} width={340} height={600} className="pixel absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/35" />

      {done ? (
        <div className="fade-in-slow relative flex h-full flex-col items-center justify-end gap-3 px-8 pb-20 text-center">
          <div className="text-3xl font-extrabold tracking-[0.2em] text-amber-100" style={{ textShadow: "0 3px 22px rgba(0,0,0,0.9)" }}>
            افسانهٔ گل لاله
          </div>
          <div className="h-px w-28 bg-gradient-to-l from-transparent via-amber-300/70 to-transparent" />
          <p className="max-w-xs text-[11px] leading-6 text-amber-50/70">
            غریبه‌ای بی‌نام، شمشیری سرد، و روستایی که چیزی از کوه ایکجا می‌ترساندش.
          </p>
          <button
            onClick={(e) => {
              e.stopPropagation();
              sfx.confirm();
              onStart();
            }}
            className="mt-3 rounded-xl border-2 border-amber-300/70 bg-amber-400/20 px-9 py-3 text-sm font-extrabold text-amber-50 shadow-lg shadow-black/50 active:scale-95"
          >
            ▶ برخاستن
          </button>
        </div>
      ) : (
        <div className="relative flex h-full flex-col justify-end p-4 pb-8">
          <div className="rounded-xl border-2 border-amber-200/25 bg-black/80 p-3 shadow-2xl backdrop-blur-sm">
            {current.speaker && (
              <div className="mb-1 inline-block rounded bg-amber-300/20 px-2 py-0.5 text-[11px] font-bold text-amber-200">
                {current.speaker}
              </div>
            )}
            <p className="min-h-12 text-[14px] leading-7 text-amber-50">
              {current.text.slice(0, shown)}
              {shown < current.text.length && <span className="animate-pulse text-amber-300">▌</span>}
            </p>
            {current.sub && shown >= current.text.length && (
              <p className="mt-1 text-[11px] italic leading-6 text-zinc-400">{current.sub}</p>
            )}
            <div className="mt-2 flex items-center justify-between text-[10px]">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onStart();
                }}
                className="text-zinc-500 underline decoration-dotted"
              >
                رد کردن
              </button>
              <span className="text-amber-200/80">لمس برای ادامه ▸</span>
            </div>
          </div>
          <div className="mt-2 flex justify-center gap-1">
            {BEATS.map((_, i) => (
              <span key={i} className={`h-1 w-3 rounded-full ${i <= beat ? "bg-amber-300/80" : "bg-white/15"}`} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
