import { useEffect, useState } from "react";
import type { DialogueState, NpcChoice } from "../game/types";
import { sfx } from "../game/audio";

interface Props {
  dialogue: DialogueState;
  onAdvance: () => void;
  onChoice: (c: NpcChoice) => void;
  onClose: () => void;
}

export default function DialogueBox({ dialogue, onAdvance, onChoice, onClose }: Props) {
  const line = dialogue.reply ?? dialogue.lines[dialogue.idx] ?? "";
  const [shown, setShown] = useState(0);

  useEffect(() => {
    setShown(0);
    const iv = setInterval(() => {
      setShown((s) => {
        if (s >= line.length) {
          clearInterval(iv);
          return s;
        }
        return s + 2;
      });
    }, 18);
    return () => clearInterval(iv);
  }, [line]);

  const done = shown >= line.length;
  const atEnd = dialogue.reply != null || dialogue.idx >= dialogue.lines.length - 1;
  const showChoices = done && atEnd && !dialogue.reply && dialogue.choices && dialogue.choices.length > 0;

  const handleTap = () => {
    if (!done) {
      setShown(line.length);
      return;
    }
    if (dialogue.reply != null) {
      onClose();
      return;
    }
    if (!atEnd) {
      sfx.blip();
      onAdvance();
    } else if (!dialogue.choices || dialogue.choices.length === 0) {
      onClose();
    }
  };

  return (
    <div className="absolute inset-x-2 bottom-2 z-20" dir="rtl">
      <div
        className="cursor-pointer rounded-xl border-2 border-amber-200/30 bg-zinc-950/92 p-3 shadow-xl backdrop-blur-sm"
        onClick={handleTap}
      >
        <div className="mb-1 inline-block rounded bg-amber-300/15 px-2 py-0.5 text-xs font-bold text-amber-200">
          {dialogue.name}
        </div>
        <p className="min-h-10 text-sm leading-6 text-zinc-100">{line.slice(0, shown)}</p>
        {showChoices ? (
          <div className="mt-2 flex flex-col gap-1.5">
            {dialogue.choices!.map((c, i) => (
              <button
                key={i}
                className="rounded-lg border border-amber-200/25 bg-zinc-800/80 px-3 py-1.5 text-right text-xs text-amber-100 transition hover:bg-zinc-700 active:scale-[0.98]"
                onClick={(e) => {
                  e.stopPropagation();
                  sfx.confirm();
                  onChoice(c);
                }}
              >
                {c.label}
              </button>
            ))}
          </div>
        ) : (
          done && <div className="mt-1 text-left text-xs text-zinc-500">▼ ادامه</div>
        )}
      </div>
    </div>
  );
}
