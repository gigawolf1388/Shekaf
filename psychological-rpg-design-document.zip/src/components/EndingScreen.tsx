import { useEffect, useState } from "react";
import type { EndingId } from "../game/types";
import { ENDINGS } from "../game/world";
import { sfx } from "../game/audio";

interface Props {
  ending: EndingId;
  onRestart: () => void;
}

export default function EndingScreen({ ending, onRestart }: Props) {
  const data = ENDINGS[ending];
  const [visible, setVisible] = useState(1);

  useEffect(() => {
    if (ending === "absorb") sfx.flatline();
    else if (ending === "accept") sfx.victory();
    const iv = setInterval(() => {
      setVisible((v) => {
        if (v >= data.lines.length) {
          clearInterval(iv);
          return v;
        }
        return v + 1;
      });
    }, 1700);
    return () => clearInterval(iv);
  }, [ending, data.lines.length]);

  const bg =
    ending === "accept"
      ? "from-[#1a1608] via-[#0e0c06] to-black"
      : ending === "escape"
        ? "from-[#0c1024] via-[#090b18] to-black"
        : "from-[#1c0808] via-[#100505] to-black";

  return (
    <div
      className={`fade-in-slow absolute inset-0 z-50 flex flex-col items-center overflow-y-auto bg-gradient-to-b ${bg} p-6`}
      dir="rtl"
      onClick={() => setVisible(data.lines.length)}
    >
      <h2 className="mb-6 mt-8 text-xl font-extrabold tracking-wide" style={{ color: data.color }}>
        {data.title}
      </h2>
      <div className="max-w-md space-y-4 text-center">
        {data.lines.slice(0, visible).map((l, i) => (
          <p
            key={i}
            className={`fade-in-slow leading-7 ${l === "— پایان —" ? "pt-4 text-lg font-extrabold" : "text-sm"} text-zinc-200`}
            style={l === "— پایان —" ? { color: data.color } : undefined}
          >
            {l}
          </p>
        ))}
      </div>
      {visible >= data.lines.length && (
        <button
          className="fade-in-slow mb-8 mt-10 rounded-xl border border-zinc-500 px-6 py-2.5 text-sm text-zinc-200 transition hover:bg-zinc-800 active:scale-[0.98]"
          onClick={(e) => {
            e.stopPropagation();
            onRestart();
          }}
        >
          ↺ شروع دوباره رؤیا
        </button>
      )}
    </div>
  );
}
