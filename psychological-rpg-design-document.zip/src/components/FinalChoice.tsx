import { useEffect } from "react";
import type { EndingId } from "../game/types";
import { sfx } from "../game/audio";

interface Props {
  memoriesCount: number;
  onChoose: (e: EndingId) => void;
}

export default function FinalChoice({ memoriesCount, onChoose }: Props) {
  const canAccept = memoriesCount >= 5;

  useEffect(() => {
    const iv = setInterval(() => sfx.monitorBeep(), 1200);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="scanlines fade-in-slow absolute inset-0 z-40 flex flex-col items-center justify-center gap-6 bg-[#06080c] p-6" dir="rtl">
      <div className="monitor-line font-mono text-[11px] text-emerald-400/90" dir="ltr">
        ROOM 317 — 03:17 — ❤ 104 bpm
      </div>
      <div className="max-w-md space-y-3 text-center">
        <h2 className="rift-glow text-lg font-extrabold text-fuchsia-300">لحظه انتخاب</h2>
        <p className="text-sm leading-7 text-zinc-300">
          شکاف کاملاً باز شده. از یک طرف، نور سفید اتاق ۳۱۷ و صدای مادر.
          از طرف دیگر، روستای گل لاله که صدات می‌زنه.
          <br />
          مسعود... چی‌کار می‌کنی؟
        </p>
      </div>

      <div className="flex w-full max-w-sm flex-col gap-3">
        <button
          disabled={!canAccept}
          onClick={() => {
            sfx.heal();
            onChoose("accept");
          }}
          className="rounded-xl border-2 border-amber-300/60 bg-amber-400/10 px-4 py-3 text-sm font-bold text-amber-200 transition hover:bg-amber-400/20 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-35"
        >
          ☀️ چشم‌هامو باز می‌کنم. می‌پذیرم.
          {!canAccept && (
            <span className="mt-1 block text-[10px] font-normal text-zinc-400">
              (برای پذیرش باید هر ۵ شکاف قبلی را دیده باشی — {memoriesCount}/۵)
            </span>
          )}
        </button>
        <button
          onClick={() => {
            sfx.blip();
            onChoose("escape");
          }}
          className="rounded-xl border-2 border-indigo-300/40 bg-indigo-400/10 px-4 py-3 text-sm font-bold text-indigo-200 transition hover:bg-indigo-400/20 active:scale-[0.98]"
        >
          🌙 برمی‌گردم. اون‌جا امنه.
        </button>
        <button
          onClick={() => {
            sfx.glitch();
            onChoose("absorb");
          }}
          className="rounded-xl border-2 border-red-400/40 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-300 transition hover:bg-red-500/20 active:scale-[0.98]"
        >
          🗡️ نه! هیچ‌کدوم از اینا واقعی نیست!
        </button>
      </div>
    </div>
  );
}
