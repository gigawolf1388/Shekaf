import type { PlayerState } from "../game/types";
import { maxHp, maxMp, playerAtk, playerDef, xpForLevel } from "../game/engine";
import { BOSSES, MEMORIES } from "../game/world";

interface Props {
  player: PlayerState;
  playtime?: number;
  onClose: () => void;
  onExitToTitle?: () => void;
}

export default function StatusOverlay({ player, playtime = 0, onClose, onExitToTitle }: Props) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/88 p-4 backdrop-blur-sm" dir="rtl" onClick={onClose}>
      <div className="w-full max-w-sm rounded-xl border border-zinc-700 bg-zinc-950 p-4" onClick={(e) => e.stopPropagation()}>
        <h3 className="mb-3 text-center text-sm font-bold text-amber-200">وضعیت قهرمان</h3>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs text-zinc-300">
          <span>سطح: <b className="text-white">{player.lvl}</b></span>
          <span>تجربه: <b className="text-white">{player.xp}/{xpForLevel(player.lvl)}</b></span>
          <span>جان: <b className="text-emerald-300">{player.hp}/{maxHp(player.lvl)}</b></span>
          <span>مانا: <b className="text-sky-300">{player.mp}/{maxMp(player.lvl)}</b></span>
          <span>حمله: <b className="text-red-300">{playerAtk(player)}</b></span>
          <span>دفاع: <b className="text-amber-300">{playerDef(player)}</b></span>
          <span>سکه: <b className="text-yellow-300">{player.gold}</b></span>
          <span>معجون: <b className="text-emerald-300">{player.potions}</b></span>
        </div>

        <div className="mt-4 border-t border-zinc-800 pt-3">
          <div className="mb-1.5 text-xs font-bold text-amber-200">سفرنامه</div>
          <div className="space-y-1 text-[11px] text-zinc-400">
            <div>مکان‌های دیده‌شده: {player.visited.length}</div>
            <div>صندوقچه‌های گشوده: {player.chests.length}</div>
            {player.smithDone.length > 0 && <div>ارتقای سلاح: {player.smithDone.length} بار</div>}
          </div>
        </div>

        {player.memories.length > 0 && (
          <div className="mt-3 border-t border-zinc-800 pt-3">
            <div className="mb-1.5 text-xs font-bold text-fuchsia-300">شکاف‌های گشوده ({player.memories.length}/۶)</div>
            <div className="space-y-1 text-[11px]">
              {player.memories.map((m) => (
                <div key={m} className="text-fuchsia-200/80">⟡ {MEMORIES[m]?.title}</div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-3 border-t border-zinc-800 pt-3">
          <div className="mb-1.5 text-xs font-bold text-red-300">هیولاهای بزرگ ({player.defeated.length}/۶)</div>
          <div className="grid grid-cols-2 gap-1 text-[11px]">
            {Object.values(BOSSES).map((b) => (
              <span key={b.id} className={player.defeated.includes(b.id) ? "text-emerald-300" : "text-zinc-600"}>
                {player.defeated.includes(b.id) ? "✔" : "✖"} {b.name}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between border-t border-zinc-800 pt-2 text-[10px] text-zinc-500">
          <span>زمان بازی: {Math.floor(playtime / 60)} دقیقه</span>
          <span className="text-emerald-400/80">✓ ذخیرهٔ خودکار فعال</span>
        </div>

        <button className="mt-3 w-full rounded-lg border border-zinc-600 py-1.5 text-xs text-zinc-300" onClick={onClose}>
          بستن (Q)
        </button>
        {onExitToTitle && (
          <button
            className="mt-2 w-full rounded-lg border border-amber-400/30 bg-amber-500/10 py-1.5 text-xs text-amber-200"
            onClick={onExitToTitle}
          >
            ذخیره و بازگشت به منوی اصلی
          </button>
        )}
      </div>
    </div>
  );
}
