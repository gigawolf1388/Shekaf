import type { PlayerState } from "../game/types";
import { BOSSES, REGIONS, WORLD } from "../game/world";
import { locKey } from "../game/types";

interface Props {
  player: PlayerState;
  onClose: () => void;
}

export default function MapOverlay({ player, onClose }: Props) {
  let minX = 99, maxX = -99, minY = 99, maxY = -99;
  WORLD.forEach((l) => {
    minX = Math.min(minX, l.x); maxX = Math.max(maxX, l.x);
    minY = Math.min(minY, l.y); maxY = Math.max(maxY, l.y);
  });
  const cols = maxX - minX + 1;
  const rows: number[] = [];
  for (let y = maxY; y >= minY; y--) rows.push(y);

  const visited = new Set(player.visited);
  const cur = WORLD.get(player.loc);
  const discovered = Array.from(WORLD.values()).filter((l) => visited.has(locKey(l.x, l.y)));
  const regionsSeen = new Set(discovered.map((l) => l.region));

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center overflow-y-auto bg-[#05050a]/95 p-4 backdrop-blur-sm" dir="rtl">
      <div className="w-full max-w-sm rounded-xl border border-zinc-700/70 bg-[#0b0b14] p-3 shadow-2xl">
        <div className="mb-2 flex items-start justify-between">
          <div>
            <h3 className="text-sm font-extrabold text-amber-200">نقشهٔ سرزمین</h3>
            <div className="mt-0.5 text-[10px] text-zinc-400">
              همین‌جا: <span className="text-amber-100">{cur?.name}</span>{" "}
              <span className="text-zinc-600">({player.loc})</span>
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-zinc-600 bg-zinc-800 text-sm font-bold text-zinc-200 active:scale-95"
            aria-label="بستن نقشه"
          >
            ✕
          </button>
        </div>

        <div dir="ltr" className="flex justify-center overflow-x-auto rounded-lg border border-zinc-800 bg-[#07070d] p-2">
          <div
            className="grid gap-[3px]"
            style={{ gridTemplateColumns: `repeat(${cols}, 15px)` }}
          >
            {rows.map((y) =>
              Array.from({ length: cols }, (_, i) => {
                const x = minX + i;
                const key = locKey(x, y);
                const l = WORLD.get(key);
                const isHere = key === player.loc;
                const seen = visited.has(key);
                let bg = "transparent";
                let extra: string | null = null;
                if (l && seen) {
                  bg = REGIONS[l.region].ground[0];
                  if (l.bossId) {
                    extra = player.defeated.includes(l.bossId)
                      ? BOSSES[l.bossId].isFinal ? "◈" : "★"
                      : "☠";
                  }
                } else if (l) {
                  bg = "#191922";
                }
                return (
                  <div
                    key={key}
                    className="relative flex h-[15px] w-[15px] items-center justify-center rounded-[2px] text-[9px] leading-none"
                    style={{
                      background: bg,
                      boxShadow: isHere
                        ? "0 0 0 2px #fbbf24, 0 0 10px #fbbf24"
                        : seen
                          ? "inset 0 0 0 1px rgba(255,255,255,0.08)"
                          : "inset 0 0 0 1px rgba(255,255,255,0.03)",
                      color: extra === "☠" ? "#f87171" : extra === "◈" ? "#f0abfc" : "#fde68a",
                    }}
                    title={l ? (seen ? l.name : "؟؟؟") : ""}
                  >
                    {isHere ? <span className="text-[9px] text-amber-300">●</span> : extra}
                  </div>
                );
              }),
            )}
          </div>
        </div>

        <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-zinc-400">
          <span><span className="text-amber-300">●</span> موقعیت تو</span>
          <span><span className="text-red-400">☠</span> هیولای بزرگ</span>
          <span><span className="text-amber-300">★</span> شکافِ بازشده</span>
          <span><span className="text-fuchsia-300">◈</span> معبد زیرآب</span>
          <span className="col-span-2 border-t border-zinc-800 pt-1.5 text-zinc-500">
            کشف‌شده: {discovered.length} از {WORLD.size} مکان — {regionsSeen.size} منطقه
          </span>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          className="mt-3 w-full rounded-lg border border-amber-300/40 bg-amber-400/10 py-2 text-xs font-bold text-amber-100 active:scale-[0.98]"
        >
          بازگشت به بازی (M)
        </button>
      </div>
    </div>
  );
}
