import { useState } from "react";
import { loadSettings, saveSettings } from "../game/save";
import { music } from "../game/music";

interface Props {
  onClose: () => void;
  onExitToTitle: () => void;
  playtime: number;
}

export default function SettingsPanel({ onClose, onExitToTitle, playtime }: Props) {
  const [sound, setSound] = useState(() => loadSettings().sound);

  const toggleSound = (v: boolean) => {
    setSound(v);
    saveSettings({ sound: v });
    music.setEnabled(v);
  };

  const hours = Math.floor(playtime / 3600);
  const mins = Math.floor((playtime % 3600) / 60);
  const secs = playtime % 60;

  return (
    <div
      className="absolute inset-0 z-40 flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
      onClick={onClose}
      dir="rtl"
    >
      <div
        className="w-full max-w-sm space-y-4 rounded-xl border border-zinc-700/70 bg-zinc-950/95 p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-base font-extrabold text-amber-200">تنظیمات</h3>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-600 bg-zinc-800 text-sm text-zinc-200 active:scale-95"
          >
            ✕
          </button>
        </div>

        {/* sound */}
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-3">
          <div className="mb-2 text-xs font-bold text-zinc-300">صدا و موسیقی</div>
          <label className="flex cursor-pointer items-center justify-between">
            <span className="text-[11px] text-zinc-400">موسیقی پس‌زمینه</span>
            <div
              className={`relative h-6 w-11 rounded-full transition-colors ${
                sound ? "bg-amber-500" : "bg-zinc-700"
              }`}
              onClick={() => toggleSound(!sound)}
            >
              <div
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${
                  sound ? "left-0.5" : "left-5"
                }`}
              />
            </div>
          </label>
          <p className="mt-1.5 text-[9px] leading-4 text-zinc-500">
            موسیقی برای هر منطقه متفاوت است و با تغییر مکان fade می‌شود.
          </p>
        </div>

        {/* save info */}
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-3">
          <div className="mb-2 text-xs font-bold text-zinc-300">داده‌ها</div>
          <div className="space-y-1 text-[11px] text-zinc-400">
            <div className="flex justify-between">
              <span>ذخیرهٔ خودکار</span>
              <span className="text-emerald-400">✓ فعال</span>
            </div>
            <div className="flex justify-between">
              <span>زمان بازی</span>
              <span className="text-amber-200">
                {hours > 0 && `${hours}س `}{mins}د {secs}ث
              </span>
            </div>
          </div>
        </div>

        {/* mobile controls */}
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-3">
          <div className="mb-2 text-xs font-bold text-zinc-300">کنترل‌ها</div>
          <div className="space-y-1 text-[10px] text-zinc-400">
            <div>⬅️ ➡️ ⬆️ ⬇️ — حرکت</div>
            <div>🅰️ — تعامل (گفتگو، صندوق، مبارزه، شکاف)</div>
            <div>🗺️ M — نقشه · 📋 Q — وضعیت</div>
          </div>
        </div>

        {/* exit button */}
        <button
          onClick={onExitToTitle}
          className="w-full rounded-lg border border-amber-400/30 bg-amber-500/10 py-2.5 text-xs font-bold text-amber-200 active:scale-[0.98]"
        >
          ذخیره و بازگشت به منوی اصلی
        </button>

        <button
          onClick={onClose}
          className="w-full rounded-lg border border-zinc-600 py-2 text-xs text-zinc-300 active:scale-[0.98]"
        >
          بازگشت به بازی
        </button>
      </div>
    </div>
  );
}
