import { useEffect, useReducer, useRef, useState } from "react";
import WorldCanvas from "./components/WorldCanvas";
import IntroCutscene from "./components/IntroCutscene";
import TitleScreen from "./components/TitleScreen";
import SettingsPanel from "./components/SettingsPanel";
import { readSave, writeSave, loadSettings } from "./game/save";
import { music } from "./game/music";
import DialogueBox from "./components/DialogueBox";
import BattleView from "./components/BattleView";
import HospitalScene from "./components/HospitalScene";
import FinalChoice from "./components/FinalChoice";
import EndingScreen from "./components/EndingScreen";
import MapOverlay from "./components/MapOverlay";
import StatusOverlay from "./components/StatusOverlay";
import { sfx } from "./game/audio";
import {
  COLS, ROWS, CX, CY, damage, getLayout, initialPlayer, maxHp, maxMp,
  mobTargetCount, playerAtk, playerDef, spawnMobs, xpForLevel,
} from "./game/engine";
import type {
  BattleState, DialogueState, EndingId, GameMode, Mob, NpcChoice, PlayerState,
} from "./game/types";
import { locKey } from "./game/types";
import { BOSSES, MEMORIES, REGIONS, WORLD } from "./game/world";

// ------------------------------------------------------------------ state
interface GameState {
  player: PlayerState;
  mode: GameMode;
  dialogue: DialogueState | null;
  battle: BattleState | null;
  memoryId: string | null;
  ending: EndingId | null;
  glitch: { text: string; id: number; real: boolean } | null;
  hint: { text: string; id: number } | null;
  mobs: Record<string, Mob[]>;
}

type Dir = "up" | "down" | "left" | "right";

type Action =
  | { type: "MOVE"; dir: Dir }
  | { type: "INTERACT" }
  | { type: "DIALOGUE_ADVANCE" }
  | { type: "DIALOGUE_CHOICE"; choice: NpcChoice }
  | { type: "DIALOGUE_CLOSE" }
  | { type: "BATTLE_ACTION"; action: "attack" | "skill" | "potion" | "flee" | "continue" }
  | { type: "ENEMY_TURN" }
  | { type: "MEMORY_DONE" }
  | { type: "CHOOSE_ENDING"; ending: EndingId }
  | { type: "TOGGLE_MAP" }
  | { type: "TOGGLE_SETTINGS" }
  | { type: "TOGGLE_STATUS" }
  | { type: "CLEAR_GLITCH" }
  | { type: "CLEAR_HINT" }
  | { type: "MOB_TICK" }
  | { type: "GAMEOVER_CONTINUE" }
  | { type: "LOAD"; player: PlayerState; mobs: Record<string, Mob[]> }
  | { type: "RESTART" };

const initialState = (): GameState => ({
  player: initialPlayer(),
  mode: "world",
  dialogue: null,
  battle: null,
  memoryId: null,
  ending: null,
  glitch: null,
  hint: { text: "جهت‌نما = حرکت | A = گفتگو/تعامل | هیولاها آزادند: جنگیدن با آن‌ها کاملاً انتخابی است", id: 1 },
  mobs: {},
});

/** Mobs live per location; they repopulate when the player comes back. */
function ensureMobs(mobs: Record<string, Mob[]>, loc: NonNullable<ReturnType<typeof WORLD.get>>): Record<string, Mob[]> {
  const key = locKey(loc.x, loc.y);
  const count = mobTargetCount(loc.region);
  if (count === 0) return mobs;
  if (!mobs[key] || mobs[key].length === 0) {
    return { ...mobs, [key]: spawnMobs(loc, count) };
  }
  return mobs;
}

let uid = 10;

const bossTiles = (tx: number, ty: number) => ty === CY - 1 && tx >= CX - 1 && tx <= CX + 1;

function facingTile(p: PlayerState): [number, number] {
  switch (p.dir) {
    case "up": return [p.tx, p.ty - 1];
    case "down": return [p.tx, p.ty + 1];
    case "left": return [p.tx - 1, p.ty];
    case "right": return [p.tx + 1, p.ty];
  }
}

function grantRewards(p: PlayerState, xp: number, gold: number, log: string[]): PlayerState {
  let np = { ...p, xp: p.xp + xp, gold: p.gold + gold };
  log.push(`+${xp} تجربه، +${gold} سکه`);
  while (np.xp >= xpForLevel(np.lvl)) {
    np.xp -= xpForLevel(np.lvl);
    np.lvl += 1;
    np.hp = maxHp(np.lvl);
    np.mp = maxMp(np.lvl);
    log.push(`✨ سطح ${np.lvl} شدی! جان و مانا کامل شد.`);
  }
  return np;
}

function openMemory(state: GameState, bossId: string): GameState {
  const boss = BOSSES[bossId];
  const memId = boss.memoryId;
  const p = state.player;
  const memories = p.memories.includes(memId) ? p.memories : [...p.memories, memId];
  const rifts = p.riftsEntered.includes(bossId) ? p.riftsEntered : [...p.riftsEntered, bossId];
  return {
    ...state,
    player: { ...p, memories, riftsEntered: rifts },
    mode: "memory",
    memoryId: memId,
  };
}

// ------------------------------------------------------------------ reducer
function reducer(state: GameState, action: Action): GameState {
  const { player } = state;

  switch (action.type) {
    case "MOVE": {
      if (state.mode !== "world") return state;
      const loc = WORLD.get(player.loc)!;
      const layout = getLayout(loc);
      let { tx, ty } = player;
      const dir = action.dir;
      if (dir === "up") ty -= 1;
      else if (dir === "down") ty += 1;
      else if (dir === "left") tx -= 1;
      else tx += 1;

      // screen transition through exit gaps
      if (tx < 0 || tx >= COLS || ty < 0 || ty >= ROWS) {
        let nx = loc.x, ny = loc.y, etx = tx, ety = ty;
        if (ty < 0) { ny += 1; ety = ROWS - 2; }
        else if (ty >= ROWS) { ny -= 1; ety = 1; }
        else if (tx < 0) { nx -= 1; etx = COLS - 2; }
        else { nx += 1; etx = 1; }
        const nkey = locKey(nx, ny);
        const nloc = WORLD.get(nkey);
        if (!nloc) return { ...state, player: { ...player, dir } };
        const nlayout = getLayout(nloc);
        if (ety < 0) ety = ROWS - 2;
        if (etx < 0) etx = COLS - 2;
        etx = Math.min(COLS - 2, Math.max(1, etx));
        ety = Math.min(ROWS - 2, Math.max(1, ety));
        if (nlayout.solid[ety][etx]) {
          if (dir === "up" || dir === "down") etx = CX;
          else ety = CY;
        }
        const visited = player.visited.includes(nkey) ? player.visited : [...player.visited, nkey];
        const firstTime = !player.visited.includes(nkey);
        // before the first rift the world only whispers innocent atmosphere;
        // afterwards the same places start leaking the truth.
        const awakened = player.memories.length > 0;
        let glitch = state.glitch;
        if (awakened && nloc.glitch) glitch = { text: nloc.glitch, id: ++uid, real: true };
        else if (firstTime && nloc.flavor) glitch = { text: nloc.flavor, id: ++uid, real: false };
        return {
          ...state,
          player: { ...player, loc: nkey, tx: etx, ty: ety, dir, visited },
          glitch,
          mobs: ensureMobs(state.mobs, nloc),
          hint: { text: `${nloc.name} — ${REGIONS[nloc.region].name}`, id: ++uid },
        };
      }

      // blocked?
      if (layout.solid[ty][tx]) return { ...state, player: { ...player, dir } };
      const npcHere = (loc.npcs ?? []).some((n) => n.tx === tx && n.ty === ty);
      if (npcHere) return { ...state, player: { ...player, dir } };
      // roaming monsters block the tile — battle is always optional
      if ((state.mobs[player.loc] ?? []).some((m) => m.tx === tx && m.ty === ty)) {
        return { ...state, player: { ...player, dir } };
      }

      const bossAlive = loc.bossId && !player.defeated.includes(loc.bossId);
      const bossRift = loc.bossId && player.defeated.includes(loc.bossId);
      if (loc.bossId && bossTiles(tx, ty)) {
        if (bossAlive) return { ...state, player: { ...player, dir } };
        if (bossRift && tx === CX) {
          // walk into the rift
          return openMemory({ ...state, player: { ...player, dir } }, loc.bossId);
        }
      }

      return { ...state, player: { ...player, tx, ty, dir } };
    }

    case "INTERACT": {
      if (state.mode !== "world") return state;
      const loc = WORLD.get(player.loc)!;
      const [fx, fy] = facingTile(player);
      // NPC?
      const npc = (loc.npcs ?? []).find(
        (n) => Math.abs(n.tx - player.tx) + Math.abs(n.ty - player.ty) === 1 && n.tx === fx && n.ty === fy,
      ) ?? (loc.npcs ?? []).find((n) => Math.abs(n.tx - player.tx) + Math.abs(n.ty - player.ty) === 1);
      if (npc) {
        return {
          ...state,
          mode: "dialogue",
          dialogue: { name: npc.name, lines: npc.lines, idx: 0, choices: npc.choices },
        };
      }

      // boss / rift? (highest priority inside boss chambers)
      if (loc.bossId) {
        const near = Math.abs(player.ty - (CY - 1)) <= 1 && Math.abs(player.tx - CX) <= 2;
        if (near) {
          if (!player.defeated.includes(loc.bossId)) {
            const boss = BOSSES[loc.bossId];
            if (boss.isFinal && player.defeated.length < 5) {
              return {
                ...state,
                mode: "dialogue",
                dialogue: {
                  name: "نگهبان حقیقت",
                  lines: [
                    "هنوز زوده، خواب‌بیننده...",
                    "پنج سایهٔ بزرگ هنوز در گوشه‌های ذهنت پرسه می‌زنند.",
                    "اول آن‌ها را رو‌به‌رو شو: وایورن، کاسپالوس، مادر جیغ، گریفیث و سایه شن‌ها.",
                    `(${player.defeated.length} از ۵ سایه سقوط کرده‌اند)`,
                  ],
                  idx: 0,
                },
              };
            }
            return {
              ...state,
              mode: "battle",
              battle: {
                enemy: boss.enemy, enemyHp: boss.enemy.hp, bossId: boss.id,
                log: [`${boss.name} راه را بسته است!`], phase: "player", shake: 0,
              },
            };
          }
          return openMemory(state, loc.bossId);
        }
      }

      // treasure chest?
      if (loc.chest && !player.chests.includes(loc.chest.id)) {
        const c = loc.chest;
        const near = Math.abs(c.tx - player.tx) + Math.abs(c.ty - player.ty) <= 1;
        if (near) {
          const gained: string[] = [];
          const np = { ...player, chests: [...player.chests, c.id] };
          if (c.gold) { np.gold += c.gold; gained.push(`${c.gold} سکه`); }
          if (c.potions) { np.potions += c.potions; gained.push(`${c.potions} معجون شفا`); }
          if (c.atk) { np.atkBonus += c.atk; gained.push(`+${c.atk} حمله`); }
          return {
            ...state,
            player: np,
            mode: "dialogue",
            dialogue: {
              name: "صندوقچه",
              lines: [c.text, `به دست آوردی: ${gained.join(" و ")}.`],
              idx: 0,
            },
          };
        }
      }

      // freely roaming monster — optional encounter card
      const mobsHere = state.mobs[player.loc] ?? [];
      const mob = mobsHere.find((m) => m.tx === fx && m.ty === fy)
        ?? mobsHere.find((m) => Math.abs(m.tx - player.tx) + Math.abs(m.ty - player.ty) === 1);
      if (mob) {
        return {
          ...state,
          mode: "dialogue",
          dialogue: {
            name: mob.name,
            lines: [
              `${mob.name} (سطح ${mob.level}) با چشمانی سرخ به تو خیره شده است...`,
              "این نبرد اجباری نیست. می‌توانی شمشیر بکشی یا از کنارش بگذری.",
            ],
            idx: 0,
            choices: [
              {
                label: `⚔️ مبارزه با ${mob.name}`,
                effect: { kind: "battle", locKey: player.loc, mobId: mob.id },
                reply: "شمشیرت را از غلاف می‌کشی...",
              },
              { label: "👣 رد شدن و ادامهٔ راه", effect: { kind: "none" }, reply: "بی‌صدا از کنارش می‌گذری. هنوز زنده است — شاید بعداً." },
            ],
          },
        };
      }
      return state;
    }

    case "DIALOGUE_ADVANCE": {
      if (!state.dialogue) return state;
      if (state.dialogue.idx < state.dialogue.lines.length - 1) {
        return { ...state, dialogue: { ...state.dialogue, idx: state.dialogue.idx + 1 } };
      }
      return state;
    }

    case "DIALOGUE_CHOICE": {
      if (!state.dialogue) return state;
      const c = action.choice;
      let p = { ...player };
      let reply = c.reply;
      if (c.effect.kind === "heal") {
        p.hp = maxHp(p.lvl);
        p.mp = maxMp(p.lvl);
      } else if (c.effect.kind === "buyPotion") {
        if (p.gold >= c.effect.price) {
          p.gold -= c.effect.price;
          p.potions += 1;
        } else reply = "سکه کافی نداری، قهرمان. برو چند تا هیولا شکار کن.";
      } else if (c.effect.kind === "smith") {
        if (p.smithDone.includes(c.effect.id)) reply = "قبلاً این کار رو برات کردم. بیشتر از این از دستم برنمیاد.";
        else if (p.gold >= c.effect.price) {
          p.gold -= c.effect.price;
          p.atkBonus += c.effect.atk;
          p.smithDone = [...p.smithDone, c.effect.id];
        } else reply = "با این سکه‌ها؟ نه جوون، کار من مفت نیست.";
      } else if (c.effect.kind === "battle") {
        const eff = c.effect;
        const mob = (state.mobs[eff.locKey] ?? []).find((m) => m.id === eff.mobId);
        if (!mob) return { ...state, mode: "world", dialogue: null };
        return {
          ...state,
          mode: "battle",
          dialogue: null,
          battle: {
            enemy: { name: mob.name, hp: mob.hp, atk: mob.atk, def: mob.def, xp: mob.xp, gold: mob.gold, color: mob.color },
            enemyHp: mob.hp,
            mobLoc: eff.locKey,
            mobId: mob.id,
            log: [`⚔️ تو حمله را آغاز کردی: ${mob.name} (سطح ${mob.level})`],
            phase: "player",
            shake: 0,
          },
        };
      } else if (c.effect.kind === "none") {
        return { ...state, mode: "world", dialogue: null };
      }
      return { ...state, player: p, dialogue: { ...state.dialogue, reply } };
    }

    case "DIALOGUE_CLOSE":
      return { ...state, mode: "world", dialogue: null };

    case "BATTLE_ACTION": {
      const b = state.battle;
      if (!b) return state;
      if (action.action === "continue") {
        if (b.phase === "won") {
          if (b.mobLoc && b.mobId) {
            const rest = (state.mobs[b.mobLoc] ?? []).filter((m) => m.id !== b.mobId);
            return {
              ...state,
              mode: "world",
              battle: null,
              mobs: { ...state.mobs, [b.mobLoc]: rest },
              hint: {
                text: rest.length
                  ? `هیولا نابود شد — ${rest.length} هیولای دیگر آزادانه در این منطقه می‌چرخند.`
                  : "منطقه پاک شد. با بازگشت دوباره، هیولاهای جدیدی پدیدار می‌شوند.",
                id: ++uid,
              },
            };
          }
          if (b.bossId) {
            const defeated = [...player.defeated, b.bossId];
            const isFinal = !!BOSSES[b.bossId].isFinal;
            return {
              ...state,
              player: { ...player, defeated },
              mode: "world",
              battle: null,
              hint: {
                text: isFinal
                  ? "شکاف نهایی باز شد... واردش شو."
                  : "⟡ شکافی بنفش در هوا باز شد... جلو برو و واردش شو.",
                id: ++uid,
              },
            };
          }
          return { ...state, mode: "world", battle: null };
        }
        if (b.phase === "fled") return { ...state, mode: "world", battle: null };
        if (b.phase === "lost") return { ...state, mode: "gameover", battle: null };
        return state;
      }

      if (b.phase !== "player") return state;
      const log = [...b.log];
      let p = { ...player };
      let enemyHp = b.enemyHp;

      if (action.action === "attack" || action.action === "skill") {
        let atk = playerAtk(p);
        if (action.action === "skill") {
          p.mp -= 8;
          atk = Math.floor(atk * 2);
          log.push("انرژی ذهنت را در تیغه جمع می‌کنی...");
        }
        const dmg = damage(atk, b.enemy.def);
        enemyHp -= dmg;
        log.push(`به ${b.enemy.name} ضربه زدی: ${dmg} آسیب!`);
        if (enemyHp <= 0) {
          log.push(`${b.enemy.name} نابود شد!`);
          p = grantRewards(p, b.enemy.xp, b.enemy.gold, log);
          return {
            ...state, player: p,
            battle: { ...b, enemyHp: 0, log, phase: "won", shake: b.shake + 1 },
          };
        }
        return { ...state, player: p, battle: { ...b, enemyHp, log, phase: "enemy", shake: b.shake + 1 } };
      }

      if (action.action === "potion") {
        if (p.potions <= 0) return state;
        p.potions -= 1;
        p.hp = Math.min(maxHp(p.lvl), p.hp + 45);
        log.push("معجون نوشیدی: +۴۵ جان.");
        return { ...state, player: p, battle: { ...b, log, phase: "enemy" } };
      }

      if (action.action === "flee") {
        if (Math.random() < 0.6) {
          log.push("فرار کردی!");
          return { ...state, battle: { ...b, log, phase: "fled" } };
        }
        log.push("راه فرار بسته شد!");
        return { ...state, battle: { ...b, log, phase: "enemy" } };
      }
      return state;
    }

    case "ENEMY_TURN": {
      const b = state.battle;
      if (!b || b.phase !== "enemy") return state;
      const log = [...b.log];
      const p = { ...player };
      const dmg = damage(b.enemy.atk, playerDef(p));
      p.hp -= dmg;
      log.push(`${b.enemy.name} حمله کرد: ${dmg} آسیب!`);
      if (p.hp <= 0) {
        p.hp = 0;
        log.push("زانوهایت خم می‌شود... همه‌جا تاریک می‌شود.");
        return { ...state, player: p, battle: { ...b, log, phase: "lost", shake: b.shake + 1 } };
      }
      p.mp = Math.min(maxMp(p.lvl), p.mp + 2);
      return { ...state, player: p, battle: { ...b, log, phase: "player", shake: b.shake + 1 } };
    }

    case "MEMORY_DONE": {
      if (state.memoryId === "mem_final") {
        return { ...state, mode: "finalChoice", memoryId: null };
      }
      return {
        ...state, mode: "world", memoryId: null,
        hint: { text: `خاطره‌ها: ${state.player.memories.length}/۶ — (Q برای وضعیت)`, id: ++uid },
      };
    }

    case "CHOOSE_ENDING":
      return { ...state, mode: "ending", ending: action.ending };

    case "TOGGLE_MAP":
      if (state.mode === "map") return { ...state, mode: "world" };
      if (state.mode === "world") return { ...state, mode: "map" };
      return state;

    case "TOGGLE_STATUS":
      if (state.mode === "status") return { ...state, mode: "world" };
      if (state.mode === "world") return { ...state, mode: "status" };
      return state;

    case "TOGGLE_SETTINGS":
      if (state.mode === "settings") return { ...state, mode: "world" };
      if (state.mode === "world") return { ...state, mode: "settings" };
      return state;

    case "CLEAR_GLITCH":
      return { ...state, glitch: null };

    case "CLEAR_HINT":
      return { ...state, hint: null };

    case "MOB_TICK": {
      if (state.mode !== "world") return state;
      const loc = WORLD.get(player.loc);
      const list = state.mobs[player.loc];
      if (!loc || !list || list.length === 0) return state;
      const layout = getLayout(loc);
      const npcTiles = new Set((loc.npcs ?? []).map((n) => `${n.tx},${n.ty}`));
      const occupied = new Set(list.map((m) => `${m.tx},${m.ty}`));
      const dirs = [{ dx: 1, dy: 0 }, { dx: -1, dy: 0 }, { dx: 0, dy: 1 }, { dx: 0, dy: -1 }];
      let changed = false;
      const next = list.map((m) => {
        if (Math.random() > 0.6) return m;
        const d = dirs[Math.floor(Math.random() * 4)];
        const tx = m.tx + d.dx, ty = m.ty + d.dy;
        const k = `${tx},${ty}`;
        if (tx < 1 || tx >= COLS - 1 || ty < 1 || ty >= ROWS - 1) return m;
        if (layout.solid[ty][tx] || npcTiles.has(k) || occupied.has(k)) return m;
        if (tx === player.tx && ty === player.ty) return m;
        const landing = (tx === CX && (ty === 1 || ty === ROWS - 2)) || (ty === CY && (tx === 1 || tx === COLS - 2));
        if (landing) return m;
        if (loc.bossId && ty === CY - 1 && tx >= CX - 1 && tx <= CX + 1) return m;
        occupied.delete(`${m.tx},${m.ty}`);
        occupied.add(k);
        changed = true;
        return { ...m, tx, ty };
      });
      return changed ? { ...state, mobs: { ...state.mobs, [player.loc]: next } } : state;
    }

    case "GAMEOVER_CONTINUE": {
      const p = { ...player };
      p.hp = Math.floor(maxHp(p.lvl) / 2);
      p.mp = maxMp(p.lvl);
      p.gold = Math.floor(p.gold * 0.6);
      p.loc = "0,0";
      p.tx = CX;
      p.ty = CY + 2;
      return {
        ...state, player: p, mode: "world",
        hint: { text: "از کابوس پریدی... دوباره در میدان روستا هستی.", id: ++uid },
      };
    }

    case "LOAD":
      return {
        ...initialState(),
        player: action.player,
        mobs: action.mobs,
        hint: { text: "سفرت ادامه دارد.", id: ++uid },
      };

    case "RESTART":
      return initialState();

    default:
      return state;
  }
}

// ------------------------------------------------------------------ component
export default function App() {
  const [state, dispatch] = useReducer(reducer, undefined, initialState);
  const [phase, setPhase] = useState<"title" | "intro" | "game">("title");
  const [savedFlash, setSavedFlash] = useState(0);
  const playtime = useRef(0);
  const lastMove = useRef(0);
  const holdRef = useRef<number | null>(null);
  const intro = phase !== "game";

  const { player, mode, battle, dialogue, memoryId, ending, glitch, hint } = state;
  const loc = WORLD.get(player.loc)!;
  const mobs = state.mobs[player.loc] ?? [];
  const bossState: "alive" | "rift" | "none" = loc.bossId
    ? player.defeated.includes(loc.bossId) ? "rift" : "alive"
    : "none";
  const [fx, fy] = facingTile(player);
  const nearbyMob = mobs.find((m) => m.tx === fx && m.ty === fy)
    ?? mobs.find((m) => Math.abs(m.tx - player.tx) + Math.abs(m.ty - player.ty) === 1);
  /** True once the player has seen the first rift — unlocks all "truth" UI. */
  const awakened = player.memories.length > 0;
  const nearChest = loc.chest && !player.chests.includes(loc.chest.id)
    && Math.abs(loc.chest.tx - player.tx) + Math.abs(loc.chest.ty - player.ty) <= 1;

  // keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(k)) e.preventDefault();
      if (intro) return;
      if (mode === "world") {
        const now = performance.now();
        const dirMap: Record<string, Dir> = {
          ArrowUp: "up", w: "up", ArrowDown: "down", s: "down",
          ArrowLeft: "left", a: "left", ArrowRight: "right", d: "right",
        };
        const dir = dirMap[k] ?? dirMap[k.toLowerCase?.() ?? ""];
        if (dir) {
          if (now - lastMove.current > 105) {
            lastMove.current = now;
            dispatch({ type: "MOVE", dir });
          }
          return;
        }
        if (k === "Enter" || k === " " || k.toLowerCase() === "e") {
          sfx.blip();
          dispatch({ type: "INTERACT" });
        }
        if (k.toLowerCase() === "m") dispatch({ type: "TOGGLE_MAP" });
        if (k.toLowerCase() === "q") dispatch({ type: "TOGGLE_STATUS" });
      } else if (mode === "dialogue") {
        if (k === "Enter" || k === " ") {
          if (dialogue?.reply != null) dispatch({ type: "DIALOGUE_CLOSE" });
          else if (dialogue && dialogue.idx < dialogue.lines.length - 1) dispatch({ type: "DIALOGUE_ADVANCE" });
          else if (dialogue && (!dialogue.choices || dialogue.choices.length === 0)) dispatch({ type: "DIALOGUE_CLOSE" });
        }
        if (k === "Escape") dispatch({ type: "DIALOGUE_CLOSE" });
      } else if (mode === "map" && (k === "Escape" || k.toLowerCase() === "m")) {
        dispatch({ type: "TOGGLE_MAP" });
      } else if (mode === "status" && (k === "Escape" || k.toLowerCase() === "q")) {
        dispatch({ type: "TOGGLE_STATUS" });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mode, dialogue, intro]);

  // enemy turn timer
  useEffect(() => {
    if (battle?.phase === "enemy") {
      const t = setTimeout(() => {
        sfx.hurt();
        dispatch({ type: "ENEMY_TURN" });
      }, 750);
      return () => clearTimeout(t);
    }
    if (battle?.phase === "won") sfx.victory();
  }, [battle?.phase, battle?.shake]);

  // glitch sfx + auto clear
  useEffect(() => {
    if (glitch) {
      sfx.glitch();
      const t = setTimeout(() => dispatch({ type: "CLEAR_GLITCH" }), 3000);
      return () => clearTimeout(t);
    }
  }, [glitch?.id]);

  // toast auto-hide (held back until the intro cutscene is over)
  useEffect(() => {
    if (!hint || intro) return;
    const t = setTimeout(() => dispatch({ type: "CLEAR_HINT" }), 5200);
    return () => clearTimeout(t);
  }, [hint?.id, intro]);

  // roaming monsters wander on their own
  useEffect(() => {
    if (mode !== "world" || intro) return;
    const iv = setInterval(() => dispatch({ type: "MOB_TICK" }), 1200);
    return () => clearInterval(iv);
  }, [mode, player.loc, intro]);

  // playtime clock
  useEffect(() => {
    if (phase !== "game") return;
    const iv = setInterval(() => { playtime.current += 1; }, 1000);
    return () => clearInterval(iv);
  }, [phase]);

  // ---- autosave: whenever meaningful progress changes
  useEffect(() => {
    if (phase !== "game" || mode === "ending") return;
    const t = setTimeout(() => {
      const ok = writeSave({
        player,
        mobs: state.mobs,
        chests: player.chests,
        playtime: playtime.current,
        locName: loc.name,
      });
      if (ok) setSavedFlash(Date.now());
    }, 700);
    return () => clearTimeout(t);
  }, [
    phase, mode, player.loc, player.lvl, player.xp, player.gold, player.potions,
    player.hp, player.atkBonus, player.defeated.length, player.memories.length,
    player.chests.length, player.visited.length,
  ]);

  // hide the "saved" badge after a moment
  useEffect(() => {
    if (!savedFlash) return;
    const t = setTimeout(() => setSavedFlash(0), 1600);
    return () => clearTimeout(t);
  }, [savedFlash]);

  // initialize music preferences from settings
  useEffect(() => {
    const s = loadSettings();
    music.setEnabled(s.sound);
  }, []);

  // play region-specific music while in world mode
  useEffect(() => {
    if (phase !== "game") {
      music.stop();
      return;
    }
    if (mode === "battle" || mode === "ending" || mode === "memory" || mode === "finalChoice") {
      music.stop();
      return;
    }
    music.play(loc.region);
    return () => music.stop();
  }, [phase, mode, loc.region]);

  // vibrate on battle hits (mobile)
  useEffect(() => {
    if (!battle) return;
    if (navigator.vibrate && battle.shake > 0) {
      navigator.vibrate([30, 20, 50]);
    }
  }, [battle?.shake]);

  // try to go fullscreen on first touch (mobile APK feel)
  useEffect(() => {
    const onFirst = () => {
      try {
        const el = document.documentElement as any;
        if (el.requestFullscreen && !document.fullscreenElement) {
          // only on mobile devices
          if (matchMedia("(max-width: 768px)").matches) el.requestFullscreen().catch(() => {});
        }
      } catch { /* noop */ }
      window.removeEventListener("touchstart", onFirst);
    };
    window.addEventListener("touchstart", onFirst);
    return () => window.removeEventListener("touchstart", onFirst);
  }, []);

  // touch D-pad hold
  const startHold = (dir: Dir) => {
    dispatch({ type: "MOVE", dir });
    stopHold();
    holdRef.current = window.setInterval(() => dispatch({ type: "MOVE", dir }), 160);
  };
  const stopHold = () => {
    if (holdRef.current != null) {
      clearInterval(holdRef.current);
      holdRef.current = null;
    }
  };

  const hpPct = (player.hp / maxHp(player.lvl)) * 100;
  const region = REGIONS[loc.region];

  return (
    <div className="flex h-full items-center justify-center bg-[#07070d]" dir="rtl">
      <div className="relative flex h-full w-full max-w-md flex-col overflow-hidden bg-[#0b0b14] sm:my-2 sm:h-[min(100%,860px)] sm:rounded-2xl sm:border sm:border-zinc-800">
        {/* ------------ HUD ------------ */}
        <div className="z-10 flex items-center justify-between gap-2 border-b border-zinc-800/80 bg-zinc-950/90 px-3 py-2">
          <button
            aria-label="تنظیمات"
            onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}
            className="dpad-btn flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-zinc-800 text-sm text-amber-200 active:bg-zinc-600"
          >
            ☰
          </button>
          <div className="min-w-0 flex-1 text-center">
            <div className="truncate text-[13px] font-bold text-amber-100">{loc.name}</div>
            <div className="text-[10px] text-zinc-500">{region.name} ({player.loc})</div>
          </div>
          <div className="flex items-center gap-2 text-[10px]">
            <div className="w-20">
              <div className="mb-0.5 flex justify-between text-[9px] text-zinc-400">
                <span>HP</span><span>{player.hp}</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded bg-zinc-800">
                <div className="h-full bg-emerald-400 transition-all" style={{ width: `${hpPct}%` }} />
              </div>
            </div>
            <span className="text-yellow-300">⛁ {player.gold}</span>
            <span className="text-emerald-300">🧪 {player.potions}</span>
            {mobs.length > 0 && (
              <span className="rounded bg-red-950/80 px-1.5 py-0.5 text-red-300">⚔ {mobs.length}</span>
            )}
            <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-zinc-300">س{player.lvl}</span>
            {savedFlash > 0 && (
              <span className="fade-in-slow rounded bg-emerald-900/70 px-1.5 py-0.5 text-[9px] text-emerald-300">
                ✓ ذخیره شد
              </span>
            )}
          </div>
        </div>

        {/* ------------ world ------------ */}
        <div className="relative flex flex-1 flex-col justify-start gap-2 overflow-y-auto bg-[radial-gradient(circle_at_50%_30%,#161226_0%,#08080f_70%)] p-2">
          <div className="pointer-events-none absolute inset-0 opacity-40" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.09) 1px, transparent 1px)", backgroundSize: "22px 22px" }} />
          <div key={player.loc} className="screen-swap">
            <WorldCanvas loc={loc} player={player} mobs={mobs} bossState={bossState} />
          </div>

          {/* hint toast */}
          {hint && mode === "world" && (
            <div key={hint.id} className="pointer-events-none absolute inset-x-6 top-4 z-10 rounded-lg bg-black/70 px-3 py-1.5 text-center text-[11px] text-amber-100 backdrop-blur-sm">
              {hint.text}
            </div>
          )}

          {/* region roster & progress */}
          <div className="relative z-10 rounded-xl border border-zinc-800/80 bg-zinc-950/80 p-2 backdrop-blur-sm">
            <div className="flex items-center justify-between text-[10px]">
              <span className="font-bold text-amber-100/90">
                ⚔ هیولاهای آزاد منطقه
                <span className="ms-1 font-normal text-zinc-500">(مبارزه اختیاری)</span>
              </span>
              <span className="text-zinc-500">
                سطح دشمنان ~{region.level} · مبارزه اختیاری
              </span>
            </div>
            <div className="mt-1.5 flex flex-wrap gap-1">
              {mobs.length > 0 ? (
                mobs.map((m) => {
                  const dist = Math.abs(m.tx - player.tx) + Math.abs(m.ty - player.ty);
                  return (
                    <span
                      key={m.id}
                      className={`rounded-md border px-1.5 py-0.5 text-[9px] ${
                        dist <= 1
                          ? "border-red-400/60 bg-red-950/70 text-red-100"
                          : "border-zinc-700 bg-zinc-900/80 text-zinc-400"
                      }`}
                    >
                      {m.name}
                      <span className="ms-1 text-[8px] opacity-70">{dist <= 1 ? "· کنارت" : `· ${dist} خانه`}</span>
                    </span>
                  );
                })
              ) : (
                <span className="rounded-md border border-emerald-800/40 bg-emerald-950/30 px-2 py-0.5 text-[9px] text-emerald-200/80">
                  {region.danger === 0
                    ? "این منطقه امن است — ساکنان فقط گفتگو می‌کنند."
                    : "منطقه پاک شده است؛ با بازگشت دوباره هیولاهای تازه می‌آیند."}
                </span>
              )}
            </div>
            <div className="mt-2 flex items-center gap-1 border-t border-zinc-800/80 pt-1.5">
              <span className="text-[9px] text-zinc-500">هیولاهای بزرگ:</span>
              {(["wyvern", "caspalus", "screamMother", "griffith", "sandShade"] as const).map((id) => (
                <span
                  key={id}
                  title={BOSSES[id].name}
                  className={`flex h-4 w-4 items-center justify-center rounded-full border text-[8px] ${
                    player.defeated.includes(id)
                      ? "border-amber-400/60 bg-amber-500/20 text-amber-200"
                      : "border-zinc-700 bg-zinc-900 text-zinc-600"
                  }`}
                >
                  {player.defeated.includes(id) ? "✦" : "·"}
                </span>
              ))}
              {awakened ? (
                <span className="ms-auto text-[9px] text-fuchsia-300/80">⟡ {player.memories.length}/۶ شکاف</span>
              ) : (
                <span className="ms-auto text-[9px] text-zinc-500">{player.defeated.length}/۵ شکار شده</span>
              )}
            </div>
          </div>

          {/* roaming monster prompt */}
          {mode === "world" && nearbyMob && (
            <div className="pointer-events-none absolute inset-x-8 bottom-14 z-10 flex items-center justify-center gap-2 rounded-lg border border-red-400/25 bg-red-950/80 px-3 py-1.5 text-center text-[11px] font-bold text-red-100 backdrop-blur-sm">
              <span className="text-red-400">⚔</span>
              {nearbyMob.name} (س{nearbyMob.level})
              <span className="rounded bg-amber-300/90 px-1.5 py-0.5 text-[9px] font-extrabold text-zinc-900">A = مبارزه</span>
              <span className="text-[9px] font-normal text-red-200/60">اختیاری</span>
            </div>
          )}

          {/* rift prompt */}
          {mode === "world" && bossState === "rift" && (
            <div className="rift-glow pointer-events-none absolute inset-x-8 bottom-4 z-10 rounded-lg bg-purple-950/70 px-3 py-1.5 text-center text-[11px] font-bold text-fuchsia-200">
              {awakened
                ? "⟡ شکاف واقعیت این‌جاست — به سمتش برو یا A بزن"
                : "⟡ شکافی بنفش در هوا می‌درخشد — به سمتش برو یا A بزن"}
            </div>
          )}
          {mode === "world" && bossState === "alive" && (
            <div className="pointer-events-none absolute inset-x-8 bottom-4 z-10 rounded-lg bg-red-950/70 px-3 py-1.5 text-center text-[11px] font-bold text-red-200">
              ☠ {BOSSES[loc.bossId!].name} — نزدیک شو و Enter بزن
            </div>
          )}

          {/* chest prompt */}
          {mode === "world" && nearChest && !nearbyMob && (
            <div className="pointer-events-none absolute inset-x-10 bottom-14 z-10 rounded-lg border border-amber-300/30 bg-amber-950/80 px-3 py-1.5 text-center text-[11px] font-bold text-amber-100 backdrop-blur-sm">
              ▣ صندوقچه‌ای این‌جاست — A برای باز کردن
            </div>
          )}

          {/* ambient line (innocent) / reality leak (after the first rift) */}
          {glitch && (
            glitch.real ? (
              <div key={glitch.id} className="glitch-overlay pointer-events-none absolute inset-0 z-20 flex items-center justify-center bg-cyan-50/5 p-8">
                <p className="max-w-xs text-center font-mono text-[13px] leading-6 text-cyan-200" style={{ textShadow: "2px 0 #e11d48, -2px 0 #3b82f6" }}>
                  {glitch.text}
                </p>
              </div>
            ) : (
              <div key={glitch.id} className="fade-in-slow pointer-events-none absolute inset-x-6 bottom-24 z-10 rounded-lg bg-black/70 px-3 py-2 text-center backdrop-blur-sm">
                <p className="text-[11px] italic leading-6 text-amber-50/85">{glitch.text}</p>
              </div>
            )
          )}
        </div>

        {/* ------------ touch controls ------------ */}
        <div className="z-10 flex items-center justify-between border-t border-zinc-800/80 bg-zinc-950/90 px-4 py-3" dir="ltr">
          <div className="grid grid-cols-3 gap-1">
            <div />
            <button className="dpad-btn h-11 w-11 rounded-lg bg-zinc-800 text-lg text-zinc-200 active:bg-zinc-600" onPointerDown={() => startHold("up")} onPointerUp={stopHold} onPointerLeave={stopHold}>▲</button>
            <div />
            <button className="dpad-btn h-11 w-11 rounded-lg bg-zinc-800 text-lg text-zinc-200 active:bg-zinc-600" onPointerDown={() => startHold("left")} onPointerUp={stopHold} onPointerLeave={stopHold}>◀</button>
            <button className="dpad-btn h-11 w-11 rounded-lg bg-zinc-800 text-lg text-zinc-200 active:bg-zinc-600" onPointerDown={() => startHold("down")} onPointerUp={stopHold} onPointerLeave={stopHold}>▼</button>
            <button className="dpad-btn h-11 w-11 rounded-lg bg-zinc-800 text-lg text-zinc-200 active:bg-zinc-600" onPointerDown={() => startHold("right")} onPointerUp={stopHold} onPointerLeave={stopHold}>▶</button>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex gap-2">
              <button className="dpad-btn rounded-lg bg-zinc-800 px-3 py-1.5 text-[11px] text-zinc-300 active:bg-zinc-600" onClick={() => dispatch({ type: "TOGGLE_STATUS" })}>وضعیت</button>
              <button className="dpad-btn rounded-lg bg-zinc-800 px-3 py-1.5 text-[11px] text-zinc-300 active:bg-zinc-600" onClick={() => dispatch({ type: "TOGGLE_MAP" })}>نقشه</button>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-left">
                <div className="text-[10px] font-bold text-amber-200">تعامل</div>
                <div className="text-[8px] text-zinc-500">{nearbyMob ? "مبارزه/رد" : "گفتگو/شکاف"}</div>
              </div>
              <button
                aria-label="تعامل"
                className="dpad-btn relative h-16 w-16 rounded-full border-2 border-amber-200/60 bg-gradient-to-b from-amber-300 to-amber-500 text-lg font-extrabold text-zinc-900 shadow-lg shadow-amber-900/40 active:scale-95"
                onClick={() => {
                  sfx.blip();
                  if (mode === "world") dispatch({ type: "INTERACT" });
                }}
              >
                A
                {nearbyMob && <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] text-white">!</span>}
              </button>
            </div>
          </div>
        </div>

        {/* ------------ overlays ------------ */}
        {mode === "dialogue" && dialogue && (
          <DialogueBox
            dialogue={dialogue}
            onAdvance={() => dispatch({ type: "DIALOGUE_ADVANCE" })}
            onChoice={(c) => {
              if (c.effect.kind === "heal") sfx.heal();
              dispatch({ type: "DIALOGUE_CHOICE", choice: c });
            }}
            onClose={() => dispatch({ type: "DIALOGUE_CLOSE" })}
          />
        )}

        {mode === "battle" && battle && (
          <BattleView
            battle={battle}
            player={player}
            onAction={(a) => {
              if (a === "attack" || a === "skill") sfx.hit();
              if (a === "potion") sfx.heal();
              if (a === "continue") sfx.confirm();
              dispatch({ type: "BATTLE_ACTION", action: a });
            }}
          />
        )}

        {mode === "memory" && memoryId && (
          <HospitalScene memory={MEMORIES[memoryId]} onDone={() => dispatch({ type: "MEMORY_DONE" })} />
        )}

        {mode === "finalChoice" && (
          <FinalChoice
            memoriesCount={player.memories.filter((m) => m !== "mem_final").length}
            onChoose={(e) => dispatch({ type: "CHOOSE_ENDING", ending: e })}
          />
        )}

        {mode === "ending" && ending && (
          <EndingScreen
            ending={ending}
            onRestart={() => {
              dispatch({ type: "RESTART" });
              playtime.current = 0;
              setPhase("title");
            }}
          />
        )}

        {mode === "map" && <MapOverlay player={player} onClose={() => dispatch({ type: "TOGGLE_MAP" })} />}
        {mode === "status" && (
          <StatusOverlay
            player={player}
            playtime={playtime.current}
            onClose={() => dispatch({ type: "TOGGLE_STATUS" })}
            onExitToTitle={() => {
              writeSave({
                player, mobs: state.mobs, chests: player.chests,
                playtime: playtime.current, locName: loc.name,
              });
              dispatch({ type: "TOGGLE_STATUS" });
              setPhase("title");
            }}
          />
        )}

        {mode === "settings" && (
          <SettingsPanel
            playtime={playtime.current}
            onClose={() => dispatch({ type: "TOGGLE_SETTINGS" })}
            onExitToTitle={() => {
              writeSave({
                player, mobs: state.mobs, chests: player.chests,
                playtime: playtime.current, locName: loc.name,
              });
              music.stop();
              dispatch({ type: "TOGGLE_SETTINGS" });
              setPhase("title");
            }}
          />
        )}

        {mode === "gameover" && (
          <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-5 bg-black/95 p-6" dir="rtl">
            <div className="text-lg font-extrabold text-red-400">تاریکی...</div>
            <p className="max-w-xs text-center text-sm leading-7 text-zinc-400">
              {awakened ? (
                <>
                  ...و در دوردست، صدای یکنواخت یک بوق.
                  <br />
                  «ضربانش برگشت. خدا رو شکر... مسعود، طاقت بیار.»
                  <br />
                  از کابوس می‌پری. دوباره در رؤیا هستی.
                </>
              ) : (
                <>
                  زانوهایت تا می‌شود و دنیا دور می‌شود...
                  <br />
                  صدای آشنایی می‌گوید: «پیداش کردم! نفس می‌کشه. ببریمش خونهٔ ننه گلی.»
                  <br />
                  وقتی چشم باز می‌کنی، دوباره در میدان روستایی.
                </>
              )}
            </p>
            <button
              className="rounded-xl bg-red-500/80 px-6 py-2.5 text-sm font-bold text-white active:scale-95"
              onClick={() => {
                sfx.confirm();
                dispatch({ type: "GAMEOVER_CONTINUE" });
              }}
            >
              بیدار شدن در میدان روستا
            </button>
          </div>
        )}

        {phase === "intro" && <IntroCutscene onStart={() => setPhase("game")} />}

        {phase === "title" && (
          <TitleScreen
            onContinue={() => {
              const data = readSave();
              if (data) {
                dispatch({ type: "LOAD", player: data.player, mobs: data.mobs ?? {} });
                playtime.current = data.playtime ?? 0;
                setPhase("game");
              } else {
                setPhase("intro");
              }
            }}
            onNewGame={() => {
              dispatch({ type: "RESTART" });
              playtime.current = 0;
              setPhase("intro");
            }}
          />
        )}
      </div>
    </div>
  );
}
