#!/usr/bin/env bash
# -------------------------------------------------------
#  افسانهٔ گل لاله — ساخت APK اندروید
#  نیازمندی‌ها: Node.js ≥ 18, Android Studio, Java 17
# -------------------------------------------------------
set -e

echo "🌷  افسانهٔ گل لاله — سازندهٔ APK"
echo "================================"

# 1. نصب وابستگی‌های npm
echo "📦  نصب وابستگی‌های پروژه..."
npm install

# 2. نصب Capacitor اگر نیست
if [ ! -d "node_modules/@capacitor/core" ]; then
  echo "📲  نصب Capacitor..."
  npm install @capacitor/core @capacitor/cli @capacitor/android
  npm install @capacitor/status-bar @capacitor/splash-screen @capacitor/keyboard
fi

# 3. ساخت پروژه وب
echo "🔨  ساخت نسخهٔ وب (vite build)..."
npm run build

# 4. آماده‌سازی Capacitor
echo "⚙️   آماده‌سازی Capacitor..."
npx cap sync android

# 5. بررسی وجود Android Studio
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo ""
  echo "⚠️   متغیر ANDROID_HOME تنظیم نیست."
  echo "    اندروید استودیو را باز کنید و مسیر SDK را ست کنید:"
  echo "      export ANDROID_HOME=\$HOME/Android/Sdk"
  echo "      export ANDROID_SDK_ROOT=\$HOME/Android/Sdk"
  echo ""
  echo "    سپس دوباره این اسکریپت را اجرا کنید."
  exit 1
fi

# 6. ساخت APK با Gradle
echo "📱  ساخت APK با Gradle..."
cd android
if [ -f "./gradlew" ]; then
  chmod +x ./gradlew
  ./gradlew assembleDebug
  APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
  if [ -f "$APK_PATH" ]; then
    cd ..
    cp android/$APK_PATH "./lale-saga.apk"
    echo ""
    echo "✅  APK ساخته شد: lale-saga.apk"
    echo "    می‌توانید آن را روی گوشی اندروید نصب کنید."
    echo ""
    echo "📤  برای ساخت نسخهٔ امضاشده (Release):"
    echo "    cd android && ./gradlew assembleRelease"
    echo "    سپس keystore بسازید:"
    echo "    keytool -genkey -v -keystore lale-saga.keystore -alias lale-saga -keyalg RSA -keysize 2048 -validity 10000"
  else
    echo "❌  APK ساخته نشد. خروجی بالا را بررسی کنید."
    exit 1
  fi
else
  echo "❌  gradlew پیدا نشد. آیا Android Studio نصب است؟"
  exit 1
fi
