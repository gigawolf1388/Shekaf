# 🌷 افسانهٔ گل لاله — راهنمای ساخت APK

این راهنما به شما کمک می‌کند پروژه را به یک **APK اندروید قابل نصب** تبدیل کنید.

---

## 📋 نیازمندی‌ها

1. **Node.js** نسخه ۱۸ یا بالاتر ([دانلود](https://nodejs.org/))
2. **Android Studio** (با SDK اندروید ۲۴+) ([دانلود](https://developer.android.com/studio))
3. **JDK 17** (در Android Studio نصب می‌شود)
4. **سیستم عامل**: ویندوز ۱۰+ / macOS 12+ / Ubuntu 20.04+

---

## 🚀 روش سریع (اسکریپت خودکار)

```bash
# در ریشه پروژه:
chmod +x scripts/build-apk.sh
./scripts/build-apk.sh
```

این اسکریپت همه‌چیز را خودکار انجام می‌دهد و در پایان فایل `lale-saga.apk` را در ریشه پروژه قرار می‌دهد.

---

## 🔧 روش دستی (گام به گام)

### گام ۱: نصب وابستگی‌های پروژه

```bash
npm install
```

### گام ۲: نصب Capacitor

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npm install @capacitor/status-bar @capacitor/splash-screen @capacitor/keyboard
```

### گام ۳: ساخت نسخهٔ وب

```bash
npm run build
```

فایل‌های ساخته‌شده در پوشهٔ `dist/` قرار می‌گیرند.

### گام ۴: مقداردهی اولیهٔ Capacitor

```bash
npx cap init "افسانهٔ گل لاله" "ir.masoud.lalesaga" --web-dir=dist
```

(اگر `capacitor.config.ts` وجود دارد، این گام را رد کنید.)

### گام ۵: اضافه‌کردن پلتفرم اندروید

```bash
npx cap add android
```

### گام ۶: همگام‌سازی

```bash
npx cap sync android
```

### گام ۷: تنظیم متغیر ANDROID_HOME

**ویندوز (PowerShell):**
```powershell
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"
```

**macOS / Linux:**
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
```

### گام ۸: ساخت APK

```bash
cd android
./gradlew assembleDebug
```

فایل APK در مسیر `android/app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

### گام ۹: کپی به بیرون

```bash
cp app/build/outputs/apk/debug/app-debug.apk ../../lale-saga.apk
```

---

## 📲 نصب روی گوشی

1. فایل `lale-saga.apk` را به گوشی منتقل کنید (از طریق USB، Telegram، Google Drive و غیره)
2. روی گوشی: **تنظیمات → امنیت → نصب از منابع ناشناخته** را فعال کنید
3. روی فایل APK ضربه بزنید و نصب کنید
4. بازی را باز کنید!

---

## 🔏 ساخت APK امضاشده (برای Play Store)

### ۱. ساخت keystore

```bash
keytool -genkey -v \
  -keystore lale-saga.keystore \
  -alias lale-saga \
  -keyalg RSA -keysize 2048 -validity 10000
```

### ۲. ساخت فایل `android/key.properties`

```
storePassword=YOUR_PASSWORD
keyPassword=YOUR_PASSWORD
keyAlias=lale-saga
storeFile=../lale-saga.keystore
```

### ۳. ویرایش `android/app/build.gradle`

بخش `android { ... }` را با موارد زیر اضافه کنید:

```gradle
def keystorePropertiesFile = rootProject.file("key.properties")
def keystoreProperties = new Properties()
keystoreProperties.load(new FileInputStream(keystorePropertiesFile))

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

### ۴. ساخت نسخهٔ امضاشده

```bash
cd android && ./gradlew assembleRelease
```

---

## 🌐 نصب به‌عنوان PWA (بدون Android Studio)

اگر نمی‌خواهید Android Studio نصب کنید، می‌توانید بازی را مستقیماً در Chrome اندروید به‌عنوان PWA نصب کنید:

1. پروژه را بسازید: `npm run build`
2. محتوای پوشهٔ `dist/` را روی یک سرور وب بگذارید (مانند Netlify، Vercel، یا GitHub Pages)
3. URL را در Chrome اندروید باز کنید
4. از منو گزینهٔ **«افزودن به صفحهٔ اصلی»** را انتخاب کنید

بازی به‌صورت آفلاین هم کار می‌کند (با کمک service worker).

---

## 🎨 سفارشی‌سازی آیکون

آیکون بازی در فایل `public/icon.svg` قرار دارد. می‌توانید آن را با هر ویرایشگر SVG (مانند Figma، Inkscape، یا Adobe Illustrator) تغییر دهید.

برای تبدیل به PNG جهت استفاده در Play Store:

```bash
# نیاز به imagemagick یا rsvg-convert
npx svg2png-cli public/icon.svg --output public/icon-512.png --width 512 --height 512
```

---

## 🐛 عیب‌یابی

### خطای `ANDROID_HOME not set`
مسیر Android SDK را به درستی تنظیم کنید (معمولاً `~/Android/Sdk` یا `C:\Users\YOU\AppData\Local\Android\Sdk`).

### خطای `Unable to locate Android SDK`
در Android Studio به **Tools → SDK Manager** بروید و حداقل Android API 24 را نصب کنید.

### خطای `Java version mismatch`
در `android/gradle.properties` اضافه کنید:
```
org.gradle.java.home=/path/to/jdk-17
```

### صدای بازی در موبایل کار نمی‌کند
WebAudio در iOS و اندروید نیاز به **اولین تعامل کاربر** (tap) دارد. این به‌طور خودکار در صفحهٔ عنوان مدیریت می‌شود.

### بازی در اندروید کوچک نشان داده می‌شود
در `android/app/src/main/AndroidManifest.xml` این attribute را چک کنید:
```xml
<supports-screens
    android:smallScreens="true"
    android:normalScreens="true"
    android:largeScreens="true"
    android:xlargeScreens="true" />
```

---

## 📦 ساختار خروجی

```
lale-saga/
├── lale-saga.apk          ← فایل نهایی برای نصب
├── android/               ← پروژهٔ اندروید (Capacitor)
├── dist/                  ← وب اپلیکیشن ساخته‌شده
├── public/                ← فایل‌های استاتیک (آیکون، manifest)
├── scripts/build-apk.sh   ← اسکریپت خودکار
└── APK_BUILD.md           ← همین راهنما
```

---

## 🎮 امکانات بازی

- 🗺️ **۶۵+ مکان قابل کاوش** در سراسر نقشه
- ⚔️ **سیستم مبارزات نوبتی** با هیولاهای آزاد اختیاری
- 🎵 **موسیقی procedural** منحصر به هر منطقه (بدون فایل صوتی)
- 💾 **ذخیرهٔ خودکار** و ادامهٔ بازی
- 📱 **کنترل لمسی بهینه** برای اندروید
- 🏆 **سه پایان متفاوت** بسته به انتخاب‌های بازیکن

---

موفق باشید! 🌷
